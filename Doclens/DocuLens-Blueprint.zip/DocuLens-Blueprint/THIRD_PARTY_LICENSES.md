# Third-Party License Inventory

Starter inventory only; update for exact pinned versions before release.

| Component | Purpose | Review |
|---|---|---|
| OpenDataLoader PDF | PDF extraction | Upstream currently says v2.0+ Apache-2.0; verify exact version and notices |
| FastAPI / Pydantic | Backend and schemas | Check installed package metadata |
| SQLAlchemy | Database | Check installed package metadata |
| React / Vite | Frontend | Check installed package metadata |
| Model API / model weights | Optional generation | Provider terms and model license are separate |
| Fonts/icons/fixtures | UI and tests | Verify each asset license and attribution |

This list may be incomplete. Generate and review a dependency/license report before distribution.
