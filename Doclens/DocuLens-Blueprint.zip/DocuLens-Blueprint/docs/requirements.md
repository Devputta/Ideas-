# Product Requirements — DocuLens

## Product
A local-first PDF workspace for researchers, students, analysts, and knowledge workers. It extracts structure, answers questions from document evidence, presents tables, and compares documents.

## Goals
1. Preserve page and element provenance during extraction.
2. Make answers auditable through citations.
3. Export extracted tables to CSV.
4. Compare documents while exposing uncertainty.
5. Keep parsing and lexical search useful without a model API.

## Non-goals
No multi-tenant SaaS, billing, enterprise SSO, autonomous actions, guaranteed legal/medical/financial correctness, or non-PDF formats in the MVP.

## Functional requirements
### FR-01 Library and upload
Accept PDF only; enforce configurable byte/page limits; validate content signature; generate UUID storage names; store checksum, filename, timestamps, and status; show queued/processing/ready/failed; delete owned derivatives with a document.

### FR-02 Parsing
Use a `PdfParser` interface and an OpenDataLoader adapter. Request Markdown and JSON where supported. Preserve page number, element type/ID, heading, and bounding box when available. Store parser version. Handle malformed, encrypted, empty, and unsupported PDFs safely.

### FR-03 Search
Chunk extracted content by section where possible. Every chunk retains document ID, page range, element IDs, and section title. Start with a deterministic lexical retriever. Search results show excerpts and provenance.

### FR-04 Chat with citations
Retrieve evidence before model generation. Scope requests to selected documents. Validate citations against retrieved chunk IDs on the server. If evidence is missing or conflicting, say so. Label AI-generated content. Provide a fake model provider for tests.

### FR-05 Tables
Detect table elements, normalize rows/columns when possible, show page/source and extraction warnings, preview data, and export CSV. Never silently invent missing values.

### FR-06 Comparison
Compare two ready documents. Match sections/paragraphs and classify added, removed, changed, or possibly equivalent content. Highlight changed figures where detectable. Show both source passages and page numbers. Label uncertain matches.

### FR-07 Privacy
Remote AI must be opt-in and disclosed. Keep provider keys in backend environment variables. Provide a local-only mode and document deletion behavior.

### FR-08 Quality
Show progress and recoverable errors; support keyboard navigation, visible focus, contrast, responsive layouts, and background processing.

## Non-functional requirements
Security: file validation, bounded processing, private storage, safe errors, prompt-injection resistance. Privacy: no telemetry by default. Maintainability: typed contracts and replaceable adapters. Testability: core tests run without network/API keys. Portability: Windows/macOS/Linux where dependencies permit.

## User stories
- Ask a question and open its cited source page.
- Preview a detected table and export CSV.
- Compare two reports and inspect evidence for each change.
- Search locally without remote AI.
- Delete a document and application-owned derivatives.

## Acceptance criteria
1. Invalid, oversized, and malformed uploads are rejected safely.
2. Parser failure is visible without exposing tracebacks or absolute paths.
3. Search results preserve document/page provenance.
4. Unknown citation IDs are rejected.
5. No-evidence questions do not get fabricated citations.
6. Tables preview and export correctly.
7. Comparison shows evidence from both sides and uncertainty.
8. Deletion removes metadata, chunks, tables, and owned files.
9. Tests run without an external API key.
