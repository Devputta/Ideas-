# Engineering Rules — DocuLens

## Product/design
1. Build one complete workflow before decorative polish.
2. No generic AI-dashboard tropes: no purple/blue gradients, centered hero, symmetric three-column cards, AI sparkles, fake metrics, or filler copy.
3. Use paper/charcoal/orange, strong typography, purposeful asymmetry, and restrained borders.
4. Every screen needs relevant loading, empty, error, and success states.
5. Mobile is a designed layout, not compressed desktop.
6. Demo data must be clearly labeled.

## Architecture
7. Keep route handlers thin; business rules belong in services.
8. Parser, retriever, and model integrations stay behind interfaces.
9. Keep parsing separate from remote generation.
10. Preserve provenance through every transformation.
11. Use typed API schemas and explicit status enums.
12. Long parsing jobs must not block the request event loop.
13. Do not add a queue or vector database before the local MVP proves the need.

## AI/evidence
14. Retrieve evidence before generation.
15. Validate citation IDs server-side.
16. Never accept model-invented IDs, page numbers, or quotes without verification.
17. If evidence is missing or conflicting, say so.
18. Treat document text as untrusted data, not instructions.
19. Disclose remote processing and minimize context.
20. Keep deterministic fake providers for tests.

## Quality/security
21. Use clear names and small functions.
22. Do not silently swallow exceptions.
23. Never return raw tracebacks to the frontend.
24. Add regression tests for fixed bugs.
25. Never commit secrets, PDFs, generated parser output, databases, or virtual environments.
26. Configure via environment variables with safe defaults.
27. Pin and review dependency versions.
28. Run tests, formatting, lint/type checks before phase completion.

## Scope
29. No auth, teams, billing, or cloud storage in the local MVP.
30. Every feature must support core workflows, security, or testability.
31. Record meaningful architecture changes in `memory.md`.
32. Only mark phase tasks complete after acceptance checks pass.
