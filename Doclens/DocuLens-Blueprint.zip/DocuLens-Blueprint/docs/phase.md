# Phases and Day-by-Day Plan

Target: 10 focused development days. This is a plan, not a guarantee; PDF edge cases may take longer. Every day ends with something testable.

## Day 1 — Repository and contracts
Build frontend/backend skeleton, Python environment, settings, health endpoint, README, `.gitignore`. Test clean startup and `/api/health`. Done when a fresh clone follows documented setup.

## Day 2 — Upload and library
Implement upload, signature/type checks, size limit, UUID path, checksum, SQLite metadata, library UI. Test invalid file, oversize, duplicate filename, traversal filename. Done when uploaded PDFs appear as queued.

## Day 3 — Parser adapter
Define `PdfParser`, implement OpenDataLoader adapter, parse Markdown/JSON, preserve provenance, add timeout and safe failures. Test fixture PDF and parser failure. Check Java 11+ and Python 3.10+ requirements.

## Day 4 — Chunking and search
Add section-aware chunks, local lexical retrieval, source excerpts, page navigation. Test provenance, document scoping, empty results.

## Day 5 — Chat and citations
Add fake model provider, optional remote adapter, evidence-grounded prompt, citation validation, chat UI. Test unknown citations, missing evidence, absent API key. All tests must run without paid services.

## Day 6 — Tables
Normalize table elements, add list/detail endpoints, preview, CSV export. Test CSV quoting, formula-injection mitigation, and source page.

## Day 7 — Comparison
Match sections/paragraphs; classify added/removed/changed; show both source passages. Test identical docs, changed numbers, added content, ambiguous matches.

## Day 8 — Security and deletion
Add deletion cascade, cleanup retry, parser timeout/output bounds, secret handling, remote-use disclosure, prompt-injection tests. Verify no path traversal and no false deletion-success message.

## Day 9 — UI and accessibility
Polish responsive workspace, keyboard navigation, focus states, statuses, table/comparison usability. Test mobile, long filenames, large tables, reduced motion.

## Day 10 — Release candidate
Review README, license notices, dependency versions, local-only mode, clean install, tests and limitations. Update `memory.md` and `phase.md` only with verified status.

## Phase gate
Do not advance just because code exists. Advance when tests pass and the workflow works from the interface.
