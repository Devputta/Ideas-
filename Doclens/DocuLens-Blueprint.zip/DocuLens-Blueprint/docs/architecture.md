# Architecture — DocuLens

## Principles
Local-first by default; remote AI is opt-in. Parsing, retrieval, generation, and UI remain separate. Every derived object retains provenance. Keep deterministic fallbacks. Treat PDFs and extracted content as untrusted.

## System flow
```mermaid
flowchart LR
  U[User] --> UI[React UI]
  UI --> API[FastAPI]
  API --> ING[Ingestion service]
  ING --> PARSER[PDF parser adapter]
  PARSER --> FILES[Private local storage]
  ING --> DB[(SQLite metadata)]
  ING --> CHUNK[Chunking and index]
  CHUNK --> DB
  UI --> CHAT[Chat endpoint]
  CHAT --> RET[Retriever]
  RET --> CHUNK
  CHAT --> LLM[Optional model provider]
  CHAT --> VALID[Citation validator]
  UI --> TABLE[Table preview / CSV]
  UI --> CMP[Document comparison]
```

## Pipeline
1. Validate PDF signature, size, and configured limits.
2. Generate UUID storage path and SHA-256.
3. Create metadata with `queued` status.
4. Parse in bounded worker/process with timeout where practical.
5. Store Markdown/JSON under a per-document derived directory.
6. Normalize elements with page and bounding-box metadata.
7. Build section-aware chunks and lexical index.
8. Normalize detected tables.
9. Mark ready; otherwise store a safe error code.
10. Delete metadata and all application-owned derivatives on user request.

## Backend modules
- `api/routes/`: health, documents, chat, tables, comparison.
- `api/schemas/`: typed request/response contracts.
- `services/ingestion.py`: orchestration and status transitions.
- `services/chunking.py`: chunks with provenance.
- `services/retrieval.py`: lexical baseline, optional vector search.
- `services/citations.py`: validate citations against retrieved chunks.
- `services/table_extraction.py`: normalize table candidates.
- `services/comparison.py`: matching and change classification.
- `adapters/pdf_parser/`: parser interface and OpenDataLoader adapter.
- `adapters/llm/`: provider interface, fake provider, optional remote provider.
- `db/`: SQLAlchemy models and session.
- `core/config.py`: typed environment configuration.

## Data model
**Document:** id, original_name, stored_path, sha256, size_bytes, page_count, status, parser_name/version, created_at, processed_at, error_code.  
**Element:** id, document_id, type, page_number, content, heading_level, bounding_box, source_element_id.  
**Chunk:** id, document_id, text, page_start/end, element_ids, section_path, search_text.  
**Table:** id, document_id, page_number, source_element_id, columns, rows, warnings.  
**Comparison:** id, left_document_id, right_document_id, status, created_at.  
**ComparisonChange:** id, comparison_id, type, left/right chunk IDs, summary, confidence, evidence.

## API outline
- `POST /api/documents` upload
- `GET /api/documents` list
- `GET /api/documents/{id}` status/details
- `DELETE /api/documents/{id}` delete owned data
- `POST /api/documents/{id}/reprocess`
- `POST /api/chat` question + document IDs → answer + citations + insufficient-evidence flag
- `GET /api/documents/{id}/tables`
- `GET /api/tables/{id}` preview
- `GET /api/tables/{id}/export.csv`
- `POST /api/comparisons`
- `GET /api/comparisons/{id}`
- `GET /api/health`

Use Pydantic schemas, consistent errors, and never expose absolute paths.

## Citation contract
Each citation includes document ID/name, 1-indexed page number, chunk ID, short quote from stored text, and optional reliable bounding box. The backend rejects citations not present in the retrieval result. The UI opens the source document/page. Do not trust the model to invent or validate citations.

## Retrieval and model adapter
Start with TF-IDF or another local lexical baseline; add sentence-transformers + FAISS only after evaluation. `retrieve(query, document_ids, limit)` returns ranked chunks with provenance. Use a `FakeLLMProvider` in tests. The optional provider receives only relevant excerpts, has timeouts/output limits, and must not follow instructions embedded in evidence.

## Processing modes
**Local:** parsing, metadata, lexical retrieval, tables, and comparison local; chat may be extractive or use a local model.  
**Hybrid:** local processing plus optional remote model generation. Disclose that excerpts leave the device.  
OpenDataLoader's own hybrid parser mode is not the same as DocuLens's remote-LLM mode.

## Failure handling
Parser timeout → failed status and safe error. Model unavailable → search/table/compare still work. Empty retrieval → no model call and insufficient-evidence response. Partial deletion → report failure and allow retry. Imperfect tables → retain preview and show warnings.

## Deployment boundary
Start locally. Before public deployment, add authentication, authorization, quotas, secure workers, rate limiting, private storage, backups, and retention policy.
