# Security Plan — DocuLens

## Threat model
Protect PDFs, extracted text, indexes, and API keys. Treat PDFs, filenames, extracted content, table cells, and model output as untrusted. Risks include malicious files, resource exhaustion, path traversal, prompt injection, remote data leakage, CSV formula injection, and false citations.

## Upload
- PDF-only; check extension, declared MIME type, and file signature.
- Enforce configurable byte/page limits.
- Generate UUID storage names; never use user filenames as paths.
- Store outside public frontend assets.
- Use private temporary directories and cleanup.
- Reject encrypted PDFs unless password support is deliberately implemented.
- Never automatically execute embedded scripts or follow links.

## Parser isolation
- Run in a separate worker/process where practical.
- Set timeouts, bounded concurrency, output size and temporary storage limits.
- Patch and review dependencies.
- Use an unprivileged account/restricted filesystem when hosted.
- Never expose absolute paths or raw parser tracebacks.

## AI and prompt injection
- Document text is evidence, never instructions.
- Delimit retrieved text and tell the model not to follow instructions inside it.
- Do not let document content invoke tools, access secrets, or trigger network actions.
- Validate structured output and citations server-side.
- Send only relevant excerpts to remote providers by default.
- Clearly disclose remote processing and provide a local-only path.

## API and secrets
- Restrict CORS; do not use wildcard origins with credentials.
- Validate UUIDs and schemas; set timeouts and request limits.
- Add rate limiting before public deployment.
- Keep API keys in backend environment variables; never expose through `VITE_` variables.
- Commit `.env.example`, never a real `.env`.
- Disable prompt/document-content logging by default.
- Do not expose an unauthenticated local service to the public internet.

## Output safety
- Escape CSV correctly and mitigate spreadsheet formula injection for values beginning with `=`, `+`, `-`, or `@` after relevant whitespace/control characters.
- Sanitize download filenames.
- Escape or sanitize extracted HTML; do not render arbitrary HTML as trusted.
- Treat model output as untrusted.

## Deletion
Delete document records, elements, chunks, tables, comparisons, and owned files. Handle partial failure and allow retry. Never claim full deletion if cleanup fails. Explain that external backups/provider logs may have separate retention rules.

## Security tests
- renamed non-PDF, malformed and zero-byte files
- oversized PDF and excessive page count
- traversal and duplicate filenames
- encrypted PDF and parser timeout
- hidden text/prompt injection
- unknown model citation IDs
- missing API key/provider outage
- CSV formulas and delimiters
- delete during processing and partial cleanup
- verify logs contain no secrets or document excerpts

This checklist is not a security certification. Reassess before public deployment or sensitive use.
