# Day-by-Day Implementation Prompts

## Shared instruction
Act as a senior full-stack engineer on DocuLens. Read the requirements, architecture, design, rules, security, and phase docs first. Make the smallest coherent change for today's phase. Review existing code before editing. Add tests, run relevant commands, and report changed files, actual test results, limitations, and exact verification commands. Never invent test success. Keep the warm paper/charcoal/burnt-orange visual system. Never expose secrets in frontend code.

## Day 1 — Foundation
Create frontend/backend skeleton, typed settings, health endpoint, `.env.example`, `.gitignore`, test setup, and setup docs. No upload/AI yet. Test health endpoint and startup.

## Day 2 — Upload/library
Add PDF signature checks, size limits, UUID paths, checksum, SQLite metadata, list/status endpoints, and library UI. Test invalid, oversized, duplicate, and traversal filenames.

## Day 3 — Parser
Define `PdfParser`, implement OpenDataLoader adapter, write Markdown/JSON to per-document directories, normalize provenance, and handle missing Java/parser errors safely. Test a small redistributable or generated fixture PDF.

## Day 4 — Search
Add section-aware chunks, local lexical retrieval, source excerpts, page references, and search UI. Test document scoping, provenance, and empty results.

## Day 5 — Chat/citations
Add fake provider, optional remote provider adapter, retrieval-grounded schema, server-side citation validation, and chat UI. Test invented citations, missing evidence, and no API key.

## Day 6 — Tables
Normalize table elements; add table list/detail, preview, and CSV export. Test CSV quoting and formula-injection mitigation.

## Day 7 — Comparison
Match paragraphs/sections and classify added/removed/changed content. Show evidence on both sides. Test identical docs, changed figures, added paragraphs, and ambiguous matches.

## Day 8 — Security
Add deletion cascade, cleanup retry, timeouts/output bounds, remote-use disclosure, secret handling, and prompt-injection fixtures. Test traversal and deletion.

## Day 9 — UI
Polish responsive workspace, keyboard access, focus states, statuses, and table/comparison usability. Test mobile, long filenames, large tables, reduced motion.

## Day 10 — Release
Review setup, licenses, dependencies, local-only mode, clean install, tests, and known limitations. Update memory/phase docs only with verified status.
