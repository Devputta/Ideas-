# Design System — DocuLens

## Premise
A working research desk: part printed journal, part precision instrument. Communicate evidence and control, not “AI magic.”

## Visual rules
- Base warm paper `#F4F1E9`; ink `#242520`; burnt orange `#B84B2F`.
- Use paper-white/stone surfaces and fine borders rather than stacks of cards.
- One expressive editorial heading face + a legible UI sans-serif; system fallbacks.
- Left-aligned typography and purposeful asymmetry.
- Mostly square or 4–8px corners.
- Motion only for feedback, loading, and explanatory transitions; respect reduced motion.
- Avoid purple/blue gradients, centered hero sections, symmetric three-card feature grids, AI sparkles, fake metrics, stock illustrations, and filler copy.

## Desktop workspace
A narrow library rail; a flexible document reader/table/comparison pane; a contextual evidence panel. Keep selected document context and source navigation visible.

## Mobile
Use one primary pane with Library / Read / Ask navigation. Open evidence as a sheet or dedicated screen; never squeeze three desktop columns into mobile. Make upload, delete, citation navigation, and export touch-friendly. Tables may scroll horizontally.

## Pages
1. Library: one primary upload action, recent files, honest status labels.
2. Document workspace: PDF preview, outline, source-aware chat.
3. Tables: table list, page reference, preview, export.
4. Compare: select left/right documents, change list, side-by-side evidence.
5. Settings: local/remote mode, provider status, limits, privacy and clear-data controls.

## Microcopy
- “Add a PDF,” not “Unlock your knowledge.”
- “Processing page 8 of 24,” not “AI is thinking.”
- “No supporting passage found,” not a confident guess.
- “Open source · page 12,” not “Magic citation.”
- “Comparison needs two ready documents,” not a vague error.

## States
Design empty, processing, ready, failed, no-evidence, partial-table, and uncertain-comparison states. Errors must not expose stack traces or paths.

## Components
`AppShell`, `LibraryRail`, `DocumentRow`, `ProcessingStatus`, `PdfPagePane`, `OutlineList`, `CitationMarker`, `EvidenceExcerpt`, `ChatComposer`, `TablePreview`, `ExportMenu`, `ComparisonDiff`, `ConfirmDeleteDialog`, `Toast`, `EmptyState`, `ErrorPanel`.

## Accessibility
Semantic landmarks; keyboard menus/dialogs; visible focus; WCAG AA contrast target; do not use color alone for diffs; announce status; meaningful table headers and link text.

## Quality gate
Does every element have a purpose? Is the next action obvious? Is source evidence easier to inspect than AI prose? Does mobile feel designed? Do long filenames, huge tables, empty states, and errors still work?
