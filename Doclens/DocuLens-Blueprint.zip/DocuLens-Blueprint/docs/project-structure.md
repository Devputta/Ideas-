# Project Folder Structure

```text
doculens/
├── README.md
├── LICENSE
├── NOTICE
├── THIRD_PARTY_LICENSES.md
├── SECURITY.md
├── .gitignore
├── .env.example
├── docs/
│   ├── requirements.md
│   ├── architecture.md
│   ├── design.md
│   ├── rules.md
│   ├── phase.md
│   ├── memory.md
│   ├── security.md
│   ├── license-guidance.md
│   ├── project-structure.md
│   └── implementation-prompts.md
├── backend/
│   ├── pyproject.toml
│   ├── app/
│   │   ├── main.py
│   │   ├── core/config.py
│   │   ├── api/routes/{health,documents,chat,tables,compare}.py
│   │   ├── api/schemas/
│   │   ├── db/{models,session}.py
│   │   ├── adapters/pdf_parser/{base,opendataloader}.py
│   │   ├── adapters/llm/{base,fake,remote_provider}.py
│   │   ├── services/{ingestion,chunking,retrieval,citations,table_extraction,comparison}.py
│   │   └── storage/local_files.py
│   └── tests/{unit,integration,fixtures}/
├── frontend/
│   ├── package.json
│   ├── vite.config.ts
│   └── src/
│       ├── app/
│       ├── components/
│       ├── features/{library,reader,chat,tables,compare}/
│       ├── lib/api.ts
│       ├── styles/
│       └── test/
└── data/                  # runtime only; gitignored
    ├── uploads/
    ├── processed/
    └── doculens.db
```

`frontend/public/` must never contain uploads. `data/` and parser outputs are runtime artifacts and must be ignored by Git. Route handlers validate/delegate; services own business rules.
