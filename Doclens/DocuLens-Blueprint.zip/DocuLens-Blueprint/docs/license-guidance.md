# License Guidance

This is guidance, not legal advice. Confirm the exact versions, license files, package metadata, notices, and model/data terms before distribution.

## License for original code
Choose MIT for simple permissive licensing, or Apache-2.0 if you prefer an explicit patent grant. Put the full canonical license text in the root `LICENSE`. Do not claim third-party code as original.

## OpenDataLoader PDF
The upstream repository currently states version 2.0+ is Apache-2.0 and versions before 2.0 were MPL-2.0. Verify the exact tag/package version used and preserve required notices:
https://github.com/opendataloader-project/opendataloader-pdf

## Checklist
1. Record direct dependencies and pinned versions.
2. Review package license metadata and bundled JVM/native components.
3. Preserve required LICENSE/NOTICE files.
4. Check fonts, icons, sample PDFs, and fixtures separately.
5. Review model weights/API terms separately from client library licenses.
6. Update `THIRD_PARTY_LICENSES.md` before release.
7. Do not redistribute copyrighted sample PDFs without permission.

Recommendation: MIT for your original portfolio code if you want permissive simplicity; keep OpenDataLoader as a dependency rather than copying its source. Verify exact notices before publishing. One dependency's license does not automatically license the entire application.
