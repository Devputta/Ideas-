# Project Memory and Decisions

## Current state
- Product: DocuLens Document Intelligence Platform.
- Scope: Advanced MVP.
- Processing: local parsing + optional remote LLM.
- Budget: ₹0 target for local development/testing.
- Priorities: cited AI chat, table extraction, document comparison.
- Status: blueprint only; implementation has not started.
- Current phase: Day 1 — repository and contracts.

## Fixed decisions
1. PDF-only input in MVP.
2. Local parsing, metadata, and lexical retrieval.
3. Remote calls are optional and disclosed.
4. Parser and model integrations are replaceable adapters.
5. Backend validates every citation.
6. No evidence means no confident factual answer.
7. No authentication/team features in local MVP.
8. Warm paper, charcoal, burnt-orange design; no generic AI aesthetic.

## ADR-001: FastAPI
Use FastAPI/Pydantic for typed contracts and Python parser integration. Revisit if deployment constraints change.

## ADR-002: OpenDataLoader adapter
Use OpenDataLoader behind `PdfParser`; structured Markdown/JSON and page/element metadata help retrieval and citations. Output quality varies; test representative PDFs and verify installed version licensing.

## ADR-003: SQLite
Use SQLite for local simplicity. Revisit for multi-user concurrency.

## ADR-004: Lexical retrieval first
Start with a deterministic local baseline. Add embeddings after evaluation shows a need.

## ADR-005: Fake model in tests
Critical flows must be repeatable without an API key.

## Risks
Complex tables/scans may parse imperfectly; coordinate mapping needs care; remote providers may receive sensitive excerpts; similarity can misclassify semantic changes; free quotas can change.

## Changelog
- 1.0: initial blueprint.
