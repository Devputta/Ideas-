# DocuLens — Document Intelligence Platform

**Blueprint v1.0 · Advanced MVP · Local-first + optional remote AI**

DocuLens lets users upload PDFs, ask evidence-grounded questions with page citations, extract tables, and compare documents.

## MVP
- PDF upload, validation, status, and deletion
- Structured extraction through an OpenDataLoader PDF adapter
- Search with document/page/element provenance
- AI chat with server-validated citations
- Table preview and CSV export
- Two-document comparison with evidence for each change
- Local-only operation remains useful without an AI API key

## Stack
- Frontend: React + TypeScript + Vite
- Backend: Python + FastAPI
- PDF parser: OpenDataLoader PDF
- Retrieval: local lexical baseline first; optional embeddings + FAISS later
- Metadata: SQLite
- Tests: pytest + HTTPX; Vitest + React Testing Library

## Setup plan
Read `docs/requirements.md`, `docs/architecture.md`, `docs/design.md`, `docs/rules.md`, `docs/security.md`, and follow `docs/phase.md`. Daily coding prompts are in `docs/implementation-prompts.md`.

## Design
A research desk, not a generic AI dashboard: warm paper, charcoal, one burnt-orange accent, left-aligned typography, purposeful asymmetry, restrained borders, functional interaction, and deliberately designed mobile layouts.

## Important
Treat the parser as a replaceable adapter. Upstream currently states OpenDataLoader PDF v2.0+ uses Apache-2.0; verify the exact installed release and notices. Its parser “hybrid mode” is distinct from DocuLens's optional remote-LLM architecture. Do not send documents to remote providers without explicit disclosure.

₹0 is a development target using local tools and optional free quotas, not a guarantee of free hosted production.
