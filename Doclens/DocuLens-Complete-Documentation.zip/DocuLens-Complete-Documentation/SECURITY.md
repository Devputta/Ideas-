# Security Policy

## Supported versions
This repository package is a documentation blueprint until maintained application releases are identified. Add supported versions when releases exist.

## Reporting a vulnerability
Do not publish exploit details, private PDFs, API keys, or sensitive data in a public issue. Before production release, configure a private reporting route such as the hosting provider's private vulnerability reporting feature or a verified private contact method.

Include affected version/commit, impact, reproducible steps, safe proof-of-concept details, and a suggested mitigation if known.

## Response
Acknowledge and investigate reports when practical, prioritize by impact, and coordinate disclosure after a fix. Do not promise response times until a process is staffed.

## Notes
Do not use confidential documents for tests. Never commit secrets or uploaded PDFs. Automated scans do not prove complete security. Review parser isolation, storage persistence, access controls, and remote AI handling before production.
