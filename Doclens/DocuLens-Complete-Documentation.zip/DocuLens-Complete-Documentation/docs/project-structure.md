# Suggested Project Structure

Adapt this to the existing repository; do not rewrite the project just to match a template.

```text
doculens/
├── README.md
├── LICENSE
├── NOTICE
├── THIRD_PARTY_LICENSES.md
├── SECURITY.md
├── .gitignore
├── .env.example
├── docs/
│   ├── requirements.md
│   ├── architecture.md
│   ├── design.md
│   ├── rules.md
│   ├── phase.md
│   ├── memory.md
│   ├── security.md
│   ├── license-guidance.md
│   ├── project-structure.md
│   ├── implementation-prompts.md
│   ├── testing.md
│   └── deployment.md
├── backend/
│   ├── pyproject.toml
│   ├── app/
│   │   ├── main.py
│   │   ├── core/config.py
│   │   ├── api/routes/
│   │   ├── api/schemas/
│   │   ├── db/
│   │   ├── adapters/pdf_parser/
│   │   ├── adapters/llm/
│   │   ├── services/
│   │   └── storage/
│   └── tests/
├── frontend/
│   ├── package.json
│   ├── vite.config.ts
│   └── src/
└── data/  # Runtime-only and gitignored
    ├── uploads/
    ├── processed/
    └── doculens.db
```

Runtime files must never live under `frontend/public/`; exclude runtime data from Git.
