# Security Design and Threat Model

## Objectives
Protect uploaded documents, prevent unsafe filesystem access, bound parser use, protect secrets, validate citations, and disclose external data transfers.

## Threats and mitigations
### Malicious PDFs
Validate extension, MIME, `%PDF-` signature, size, and page limits. Bound execution and output. Use restricted process/container isolation where practical, and never claim isolation unless it is configured and tested.

### Path traversal
Use generated UUID filenames; keep uploads outside the public web root; resolve paths against a fixed storage root; never join untrusted names directly into paths.

### Prompt injection
Treat extracted text as untrusted data. Do not give the model shell, filesystem, arbitrary network, or tool access. Keep secrets out of prompts and validate all citations server-side.

### Fabricated citations
Provide bounded evidence with stable IDs. Validate IDs, page numbers, and quotes against retrieved/stored evidence. Return a no-support response when appropriate.

### Secrets and logs
Keep keys on the backend in environment variables. Never commit `.env`. Avoid logging document text, excerpts, and secrets. Return safe client errors.

### CSV formula injection
Handle dangerous prefixes such as `=`, `+`, `-`, and `@`, including leading whitespace/control characters. Preserve legitimate numeric values where safe and test spreadsheet behavior.

### Deletion
Coordinate database and file cleanup. Track partial failures and support retries. Test related chunks, tables, and comparisons.

### Resource exhaustion
Bound upload size, page count, parser runtime, output, request sizes, and model responses. Add rate limiting if exposed to untrusted networks.

## Privacy
Local-only mode must work without a model key and make no remote model calls. Remote AI mode must be explicitly configured and disclose that selected excerpts may leave the device. Never promise provider retention guarantees without verifying terms.

## Verification checklist
- [ ] Invalid/oversized PDFs rejected
- [ ] Path traversal tests on supported OSes
- [ ] Parser timeout/crash tests
- [ ] No secrets in frontend bundle or Git
- [ ] Fabricated citation tests
- [ ] Prompt injection treated as data
- [ ] CSV formula injection tests
- [ ] Partial deletion/retry verified
- [ ] Safe error responses
- [ ] Remote provider disclosure tested
- [ ] Dependency/advisory review

A checklist or automated scan does not prove complete security. Production may require authentication, authorization, monitoring, backups, retention controls, stronger isolation, and professional review.
