# Project Memory and Decision Log

## Blueprint decisions
- Name: DocuLens.
- Goal: local-first PDF intelligence: search, cited chat, tables, comparison.
- Proposed frontend: React + TypeScript + Vite.
- Proposed backend: FastAPI.
- Local metadata: SQLite.
- PDF parsing: OpenDataLoader PDF behind a replaceable adapter.
- Retrieval: lexical first; evaluate embeddings later.
- LLM: deterministic fake provider for tests; optional backend-configured remote provider.
- Visual identity: warm paper `#F4F1E9`, charcoal `#242520`, burnt orange `#B84B2F`.
- Privacy: local-first; disclose when selected excerpts are sent to a remote provider.
- Testing proposal: pytest/HTTPX and Vitest/React Testing Library, subject to actual repo compatibility.

## Cautions
- Verify the installed OpenDataLoader version/API.
- Scanned PDFs may require OCR and may not yield text.
- Validate model citations server-side.
- Do not claim free production hosting or unlimited model use.
- Do not apply database changes without inspecting the existing schema.
- Do not mark phases complete without code and test evidence.

## Session log template
- Date:
- Phase:
- Files changed:
- Behavior verified:
- Commands run:
- Test/build results:
- Known failures:
- Next action:

## Current status
Documentation blueprint only. Source-code implementation, tests, and deployment status must be verified in the target repository.
