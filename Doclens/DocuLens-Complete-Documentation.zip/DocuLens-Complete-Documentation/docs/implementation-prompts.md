# Implementation Prompts — Days 1–15

## Shared instruction
Read relevant docs and inspect actual code/dependency versions. Preserve user changes, make the smallest coherent change, add tests, run actual checks, and report real outcomes. Do not invent APIs, credentials, test results, screenshots, or completed features. Preserve the established design and update phase status only after verification.

## Day 1 — Foundation
Create/inspect frontend and backend skeleton, config, `.env.example`, `.gitignore`, health endpoint, basic tests, and setup docs.

## Day 2 — Upload and library
Validate PDF extension/MIME/signature, empty and oversized files. Use UUID storage names, SHA-256, SQLite metadata, list/detail/delete endpoints, and library UI. Test traversal and duplicate filenames.

## Day 3 — Parser
Define `PdfParser` and normalized page/element output. Verify the actual OpenDataLoader version/API. Add processing states, provenance, bounded execution, safe errors, and tests.

## Day 4 — Search
Create provenance-aware chunks and local lexical retrieval. Search ready documents only; return evidence excerpts and page references. Test relevant and no-match queries.

## Day 5 — Chat/citations
Use a deterministic fake provider and optional backend-only remote provider. Retrieve evidence first; validate IDs, pages, and quotes server-side. Test no evidence and prompt injection.

## Day 6 — Tables
Inspect real parser table output, normalize rows/columns, add preview/export, and test CSV formula-injection protection.

## Day 7 — Comparison
Compare two ready documents; report additions/removals/modifications/uncertain matches and evidence from both sides. Test identical, reordered, added, removed, and changed content.

## Day 8 — Security
Review upload, parser, deletion, storage, citation, provider, logs, CSV, and privacy controls. Add security regression tests.

## Day 9 — UX/accessibility
Polish library, reader, chat, tables, and comparison without unnecessary API/schema changes. Test mobile widths, keyboard use, focus, contrast, reduced motion, and long content.

## Day 10 — Release verification
Run tests, lint/type checks, builds, clean setup, workflows, license review, docs, and limitation reporting.

## Day 11 — Audit
Audit real repository state, verify features, test contracts/privacy, list findings with evidence/severity, and assess deployment. Do not publish automatically.

## Day 12 — Blockers
Fix verified critical/high issues with minimal changes and regression tests. Preserve data and user changes.

## Day 13 — Deployment config
Choose deployment based on actual stack, persistent storage, parser needs, secrets, HTTPS, and privacy. Document exact commands; do not assume free hosts preserve files.

## Day 14 — Deployment verification
Test health, persistence across restarts, parsing limits, citations, deletion, logs, and remote provider configuration. Use no confidential PDFs.

## Day 15 — Release package
Review diffs, licenses, README, security policy, real screenshots, sample-data permissions, setup, tests, and release notes. Prepare a candidate for user review; do not push/publish without approval.
