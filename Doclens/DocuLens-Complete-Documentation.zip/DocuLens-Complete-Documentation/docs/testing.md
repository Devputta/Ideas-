# Testing Strategy

## Unit tests
File validation, safe path generation, checksums, parser normalization, chunking/provenance, lexical retrieval, citation validation, CSV sanitization, comparison matching, cleanup orchestration.

## API integration tests
Upload/list/detail/delete; processing success/failure; ready-document search; chat with fake provider/no key; invalid citations; table retrieval/export; comparison creation/retrieval; safe errors and health response.

## Frontend tests
Upload validation/errors; library empty/loading/ready/processing/failed states; chat no-evidence and citations; table preview/export; comparison states; keyboard-accessible dialogs and controls.

## Security tests
Malformed/oversized/misleading PDFs, Windows/Unix traversal, parser timeout/crash/excess output, prompt injection, fabricated citations, CSV formula values, partial deletion/retry, missing API keys/provider failure, secret/path leakage.

## End-to-end acceptance
Use synthetic or licensed PDFs for upload -> parse -> search -> cited chat -> tables -> comparison -> deletion.

## Reporting
Record exact commands, exit statuses, environment assumptions, and failures. Skipped tests are not passed tests. Mocks alone do not prove real parser or deployment integration works.
