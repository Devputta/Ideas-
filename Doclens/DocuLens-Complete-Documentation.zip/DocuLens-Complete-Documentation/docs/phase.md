# Implementation Phases

This is a plan, not evidence of implementation. Check a phase only after code changes and verification.

- [ ] Day 1 — Foundation
- [ ] Day 2 — Secure PDF upload and library
- [ ] Day 3 — Parser adapter and ingestion
- [ ] Day 4 — Chunking and lexical search
- [ ] Day 5 — Chat and verified citations
- [ ] Day 6 — Table extraction and CSV
- [ ] Day 7 — Document comparison
- [ ] Day 8 — Security hardening
- [ ] Day 9 — UI polish, mobile, accessibility
- [ ] Day 10 — Final testing and release preparation
- [ ] Day 11 — Release audit and deployment readiness
- [ ] Day 12 — Fix release blockers
- [ ] Day 13 — Deployment configuration
- [ ] Day 14 — Deployment and persistence testing
- [ ] Day 15 — Release packaging and demo

## Day summaries
1. Skeleton, config, environment example, health endpoint, tests, repository hygiene.
2. Validate PDF, size limits, UUID storage, checksum, metadata, list/detail/delete, library UI.
3. Parser interface, normalized output, actual installed parser API, provenance, timeouts, safe errors.
4. Provenance-aware chunks and local lexical retrieval scoped to ready documents.
5. Fake provider, optional remote provider, backend citation validation, no-evidence behavior.
6. Table normalization, preview, CSV endpoint, formula-injection protection.
7. Deterministic comparison and evidence from both documents.
8. Upload/parser/deletion/storage/citation/logging/provider/CSV/privacy security tests.
9. Library/reader/chat/tables/compare polish, mobile and accessibility.
10. Full test/build/clean-setup/license/docs review.
11. Audit actual code and deployment assumptions.
12. Fix verified blockers with regression tests.
13. Configure deployment based on real stack and persistent-storage requirements.
14. Verify deployment, persistence, privacy, and failure handling.
15. Prepare release candidate and demo documentation.

Update this file only with verified status, test commands, and blockers.
