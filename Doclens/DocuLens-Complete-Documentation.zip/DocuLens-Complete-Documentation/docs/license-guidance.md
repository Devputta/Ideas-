# License Guidance

Choose a project license intentionally before public release. MIT is permissive; Apache-2.0 includes an express patent license and additional terms. This is guidance, not legal advice.

Do not leave an ambiguous root `LICENSE`. If the choice is unresolved, treat the release as not ready rather than claiming a license.

For every dependency, record its exact version, verify authoritative package metadata and upstream LICENSE/NOTICE, include required notices, and recheck on upgrades. OpenDataLoader PDF licensing can depend on version; verify the installed release and official upstream information. A dependency license does not automatically determine the whole application's license.

Do not redistribute private/copyrighted PDFs, fonts, images, or sample data without permission. Use synthetic or appropriately licensed fixtures.

Checklist:
- [ ] Root license selected and canonical text included
- [ ] README matches selected license
- [ ] Direct/transitive dependencies reviewed as needed
- [ ] Required notices included
- [ ] Sample assets have redistribution rights
- [ ] OpenDataLoader version/license verified
- [ ] Unresolved questions documented

Seek qualified legal advice for complex distribution questions.
