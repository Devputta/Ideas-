# Architecture

## Principles
Local-first, modular adapters, explicit provenance, optional external services, bounded parsing, and evidence-grounded answers.

## Data flow
PDF upload -> validation and limits -> UUID private storage + SHA-256 -> SQLite metadata -> bounded parser adapter -> normalized pages/elements/tables -> provenance-aware chunks -> lexical retrieval -> evidence bundle -> optional LLM -> backend citation validation -> answer with source references.

## Suggested layers
- API routes: request validation, schemas, HTTP statuses.
- Services: ingestion, chunking, retrieval, citations, table extraction, comparison, deletion.
- Adapters: PDF parser and LLM providers.
- Storage: safe filesystem operations.
- Persistence: SQLite with a repository/ORM layer.
- Frontend: React features with a typed API client.

## Suggested entities
**Document:** id, original_name, stored_path, sha256, size_bytes, page_count, status, parser_name/version, created_at, processed_at, error_code.

**Element:** id, document_id, type, page_number, content, heading_level, bbox, source_element_id.

**Chunk:** id, document_id, text, page_start/end, element_ids, section_path, search_text.

**Table:** id, document_id, page_number, source_element_id, columns, rows, warnings.

**Comparison:** id, left_document_id, right_document_id, status, created_at.

**ComparisonChange:** id, comparison_id, type, left/right chunk IDs, summary, confidence, evidence.

Adapt to the actual repository; do not apply schema changes just because this blueprint proposes them.

## Proposed API
- `GET /api/health`
- `POST /api/documents`
- `GET /api/documents`
- `GET /api/documents/{id}`
- `DELETE /api/documents/{id}`
- `POST /api/documents/{id}/process`
- `POST /api/documents/{id}/reprocess`
- `POST /api/search`
- `GET /api/documents/{id}/chunks/{chunk_id}`
- `POST /api/chat`
- `GET /api/documents/{id}/tables`
- `GET /api/tables/{id}`
- `GET /api/tables/{id}/export.csv`
- `POST /api/comparisons`
- `GET /api/comparisons/{id}`

These are proposed contracts, not confirmation that routes exist.

## Citation contract
Each evidence item should contain evidence ID, document ID/name, 1-indexed page number, chunk ID, quote copied from stored content, and optional source-element IDs/bounding boxes. Validate IDs, pages, and quotes server-side. If evidence is insufficient, say so.

## Retrieval and parser
Start with lexical retrieval and evaluate relevance before adding embeddings. A proposed chunk target is about 1,800 characters with a maximum near 2,600, to be tuned on real documents. Define a `PdfParser` interface and inspect the installed OpenDataLoader version/API before implementing its adapter. Do not invent methods or output fields.

## Failures
Use stable internal error codes, safe client messages, bounded parser execution/output, and ensure processing reaches a terminal status.
