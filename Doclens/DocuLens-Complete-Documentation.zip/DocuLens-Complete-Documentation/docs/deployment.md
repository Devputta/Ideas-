# Deployment and Operations

## Local-first baseline
Start locally. Store uploads, extracted files, and SQLite outside the frontend public directory and exclude them from Git.

## Possible settings
Adapt names to actual code; do not add unused settings merely because listed:
- `DOCULENS_DATA_DIR`
- `DOCULENS_MAX_UPLOAD_MB`
- `DOCULENS_MAX_PAGES`
- `DOCULENS_PARSER_TIMEOUT_SECONDS`
- `DOCULENS_LLM_PROVIDER`
- `DOCULENS_LLM_API_KEY`
- `DOCULENS_LLM_MODEL`
- `DOCULENS_REMOTE_AI_ENABLED`

Keep real credentials on the backend. Validate settings at startup.

## Hosting checks
Verify persistent disk, SQLite suitability, CPU/memory, request and timeout limits, supported Python/Node versions, HTTPS, private storage, logs, secrets, background processing, and current free-tier limitations.

A stateless host with ephemeral storage is not suitable for persistent PDFs and SQLite unless a compatible persistent storage service is configured.

## Privacy and costs
Explain where documents are stored and what changes when remote AI is enabled. Local development may be free; hosting, persistent storage, domains, and remote model use may cost money. Verify current provider terms before deployment.

## Operational checks
Health endpoint, persistence across restart, upload/parser limits, safe errors, backup and deletion behavior, dependency updates, and security notices.
