# Design System and UX

## Intent
A deliberate editorial workspace for serious documents—not a generic AI dashboard.

## Palette
- Warm paper: `#F4F1E9`
- Charcoal: `#242520`
- Burnt orange: `#B84B2F`
- Neutral borders and secondary text; verify contrast.

Avoid purple-blue gradients, indigo/violet, generic dark-mode blue, random accent colors, and generic AI illustrations.

## Layout
Left-aligned typography, readable widths, asymmetric editorial hierarchy where useful, fine borders, restrained corner radii, and purposeful whitespace. Avoid centered marketing heroes, repetitive three-column cards, meaningless widgets, and excessive animation. Mobile should feel intentionally designed.

## Screens
- **Library:** upload, document list, truthful statuses, page counts where known, meaningful empty/error states.
- **Reader:** readable source content, page references, evidence excerpts.
- **Chat:** visible document scope, clear answer/evidence distinction, loading/error/no-evidence states.
- **Tables:** readable preview, explicit export action, horizontal scrolling within wide tables.
- **Compare:** additions/removals/modifications/uncertain changes with evidence from both sources.

## Interaction and accessibility
Confirm destructive actions. Use semantic HTML, associated labels, keyboard operation, visible focus, accessible names, sufficient contrast, async status announcements, and `prefers-reduced-motion`. Never communicate status with color alone.

## Responsive checks
Test approximately 360, 390, 768, 1024px and desktop. Check long filenames, long responses, wide tables, dialogs, navigation, and page overflow.
