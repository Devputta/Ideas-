# Product Requirements Document

## Product
DocuLens helps users inspect PDFs, search for evidence, ask questions with validated citations, extract tables, and compare document revisions.

## Users
Students, analysts, developers, and people reviewing reports or document revisions. Do not market it as legal, medical, financial, or compliance advice.

## MVP requirements
1. Upload and list PDFs with safe validation.
2. Store files under generated UUID names outside the public web root.
3. Parse PDFs through a replaceable adapter and preserve page provenance.
4. Search ready documents and return excerpts with page/chunk references.
5. Chat using retrieved evidence, with a fake provider for local tests.
6. Validate citation IDs, pages, and quotes server-side.
7. Normalize tables and export CSV safely.
8. Compare two ready documents with evidence from both sides.
9. Delete document records and related files/data reliably.
10. Provide meaningful loading, empty, success, and error states.
11. Run locally without a model API key.

## Functional details
- Upload: check extension, MIME, `%PDF-` signature, empty content, and configurable size/page limits.
- Statuses: `queued`, `processing`, `ready`, `failed`.
- Parser: normalize pages/elements, preserve source identifiers, handle timeout and failures.
- Search: only search ready documents and honor document scope.
- Chat: retrieve first; reject fabricated citations; return no-support response when evidence is insufficient.
- Tables: expose normalized rows/columns and safe CSV export.
- Comparison: additions, removals, modifications, uncertain matches, and source evidence.
- Deletion: coordinate database and filesystem cleanup; report/retry partial failures.

## Non-functional requirements
Security, privacy, reliability, accessibility, responsive design, maintainability, and measurable performance. Avoid unsupported performance claims.

## Out of scope initially
Multi-user collaboration, guaranteed OCR for all scanned PDFs, perfect semantic interpretation, cloud-scale distributed processing, or claims of complete security.

## Acceptance criteria
A synthetic/appropriately licensed PDF can be uploaded, parsed, searched, queried with verifiable citations, inspected for tables, compared where supported, and deleted. Invalid uploads are rejected. Clean setup instructions work. Test/build outcomes are reported truthfully.
