# DocuLens

A local-first PDF intelligence workspace for document ingestion, evidence-based search, citation-grounded chat, table extraction, and document comparison.

> This ZIP contains project documentation and implementation prompts. It is a blueprint, not proof that the application code or features have already been implemented.

## Proposed stack
- Frontend: React + TypeScript + Vite
- Backend: FastAPI
- Local metadata: SQLite
- PDF parsing: OpenDataLoader PDF behind a replaceable adapter
- Retrieval: lexical search first
- Tests: pytest + HTTPX; Vitest + React Testing Library
- LLM: deterministic fake provider by default; optional backend-configured remote provider

Verify actual installed dependency versions and upstream APIs before coding.

## Docs
See `docs/requirements.md`, `architecture.md`, `design.md`, `rules.md`, `phase.md`, `memory.md`, `security.md`, `license-guidance.md`, `project-structure.md`, `implementation-prompts.md`, `testing.md`, and `deployment.md`.

## Product principles
- Local-first by default; remote AI is optional and disclosed.
- Preserve page and element provenance for evidence.
- Validate citations on the backend.
- Treat PDFs and extracted text as untrusted.
- Use the warm-paper/charcoal/burnt-orange design system.
- Never invent features, test results, benchmarks, or release readiness.

## Cost note
Local development can be free. This does not guarantee free production hosting, persistent storage, unlimited PDF processing, or free remote model access.
