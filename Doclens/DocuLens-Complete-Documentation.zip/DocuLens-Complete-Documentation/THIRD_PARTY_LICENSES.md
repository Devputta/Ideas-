# Third-Party Licenses and Notices

This is a review template, not a completed license audit. Populate it from authoritative package metadata and upstream repositories before release.

| Dependency/asset | Exact version | License | Source checked | Notice included? |
|---|---|---|---|---|
| OpenDataLoader PDF | TODO | Verify exact release | TODO | TODO |
| FastAPI | TODO | Verify | TODO | TODO |
| React | TODO | Verify | TODO | TODO |
| Vite | TODO | Verify | TODO | TODO |
| Other direct/transitive dependencies | TODO | Verify | TODO | TODO |
| Fonts, icons, images, sample PDFs | TODO | Verify rights | TODO | TODO |

Record exact versions, inspect upstream LICENSE/NOTICE, include required notices, and recheck when dependencies change. Do not assume a dependency's license applies to the entire application.
