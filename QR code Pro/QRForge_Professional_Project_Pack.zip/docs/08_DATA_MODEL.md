# Data Model

This schema is a proposal for later account and dynamic-link phases. Do not create tables that the shipped application does not use.

## `users`
- `id` — provider-issued user identifier.
- `created_at`
- `updated_at`

Avoid duplicating authentication secrets managed by an identity provider.

## `qr_codes`
- `id` — UUID.
- `owner_id` — nullable only if anonymous persistence is deliberately supported.
- `name` — user-defined label.
- `destination_type` — allowlisted type such as `url`, `maps`, `youtube`, `social`, `file`, `email`, `phone`, `wifi`, `vcard`.
- `destination` — normalized payload or protected reference; avoid storing secrets unnecessarily.
- `render_options` — validated style settings.
- `is_dynamic` — explicit boolean.
- `created_at`
- `updated_at`
- `archived_at` — nullable.

## `media_assets` (optional)
- `id`
- `owner_id`
- `storage_key` — private storage identifier, not a filesystem path exposed to clients.
- `mime_type`
- `size_bytes`
- `access_mode`
- `created_at`
- `deleted_at`

## `redirect_links` (optional)
- `id`
- `qr_code_id`
- `slug` — unique, non-guessable enough for the threat model.
- `destination_url`
- `status`
- `created_at`
- `updated_at`

## `scan_events` (optional)
- `id`
- `redirect_link_id`
- `occurred_at`
- `user_agent_category` — only if needed and derived safely.
- `referrer_domain` — only if available, useful, and disclosed.
- `country_code` — only if derived through a documented provider and privacy reviewed.
- `deduplication_key` — short-lived or privacy-preserving if needed.

Do not store full IP addresses by default. Set retention limits and explain analytics limitations.

## Integrity and authorization
- Every saved record must be authorized against the current user.
- Apply database row-level security where supported.
- Validate all fields server-side.
- Use foreign keys and indexes for actual query patterns.
- Delete dependent records and storage objects according to documented retention rules.
