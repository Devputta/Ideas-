# Security and Privacy

## Destination safety
- Accept only supported schemes for link destinations, normally `https:` and `http:` where appropriate.
- Reject dangerous schemes such as `javascript:`, `data:`, and `file:` for ordinary web links.
- Do not fetch arbitrary user-provided URLs from the server unless required and protected against SSRF.
- Render destination text safely; do not inject it as HTML.
- Warn users that a QR code can direct scanners to an external website.

## Upload safety
- Enforce size limits and an allowlist of supported file types.
- Verify content server-side; do not trust file extensions alone.
- Use generated storage keys, not user-controlled paths.
- Prevent executable content from being served inline where possible.
- Keep private files private and use expiring signed links where appropriate.
- Add malware scanning where appropriate to the threat model.
- Apply rate limits and abuse reporting for public uploads.

## Authentication and authorization
- Never store passwords directly if a managed identity provider is used.
- Check record ownership on every server operation.
- Protect state-changing requests and configure CORS narrowly.
- Keep service-role keys and secrets on the server.
- Add rate limits to authentication, uploads, bulk jobs, and redirect creation.

## Dynamic redirects
- Validate destination updates.
- Do not create an open redirect endpoint that accepts arbitrary destinations without an owned record.
- Provide disable/delete controls and abuse response procedures.
- Consider phishing and malware abuse; include a reporting path if public links are supported.

## Analytics and privacy
- Explain what is collected and why.
- Collect the minimum useful event data.
- Set retention periods and deletion procedures.
- Avoid claiming exact unique-person counts from scan requests.
- Do not collect precise location unless necessary, lawful, disclosed, and genuinely supported.

## Secrets and repository hygiene
- Commit `.env.example` with placeholder names only.
- Ignore `.env`, keys, tokens, and local uploads.
- Rotate any secret accidentally committed.
- Keep dependencies maintained and review licenses.
- Publish a security contact appropriate to the project.
