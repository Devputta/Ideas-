# Test Plan

## Unit tests
- URL validation accepts supported valid URLs.
- Invalid and dangerous schemes are rejected.
- Google Maps query parameters are encoded correctly.
- Directions mode and destination are represented correctly.
- Email, phone, Wi-Fi, and contact payloads escape special characters.
- Style validation prevents unsupported values and unsafe logo dimensions.
- Filename sanitization blocks path traversal and invalid characters.

## Component tests
- Destination form changes with selected type.
- Validation errors are visible and associated with fields.
- Preview updates when input or style changes.
- Reset restores safe defaults.
- Download controls match formats actually supported.
- Keyboard navigation reaches all interactive controls.

## Integration tests
- Valid URL -> generated QR -> exported file.
- Google Maps URL -> QR -> decoded payload matches expected destination.
- Upload -> share URL -> QR, if media hosting is enabled.
- Authenticated save/edit/delete respects ownership, if accounts are enabled.
- Dynamic redirect resolves to current destination, if implemented.
- Scan event is recorded only when analytics is enabled and disclosed.

## Manual device tests
- Scan PNG from a phone screen.
- Scan printed or print-preview output.
- Test default and customized colors.
- Test codes with and without center logos.
- Test a long destination URL.
- Confirm Google Maps opens a sensible destination on Android and iOS where available.

## Release gates
- Production build passes.
- Lint and type checks pass where configured.
- No known critical security issue remains.
- No fake analytics or placeholder data is shipped.
- Main flows work at narrow mobile widths and desktop widths.
- Known limitations are documented.
