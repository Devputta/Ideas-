# Information Architecture

## Public pages
- `/` — Home and generator entry point.
- `/create` — QR creation workspace.
- `/privacy` — privacy policy appropriate to implemented data handling.
- `/terms` — terms appropriate to the actual service.
- `/help` — instructions and troubleshooting, if maintained.

## Authenticated pages (later phase)
- `/dashboard` — saved codes and recent items.
- `/codes/:id` — view/edit a saved QR code.
- `/analytics/:id` — real analytics for an eligible dynamic QR.
- `/settings` — account and privacy settings.

## Generator workspace
1. Select destination type.
2. Enter the URL or structured details.
3. Validate input and show the destination.
4. Generate the QR preview.
5. Customize appearance.
6. Run readability warnings.
7. Download supported output.
8. Optionally save, if authentication is implemented.

## Navigation rules
- Keep primary navigation short.
- Do not require sign-in for basic static generation.
- Keep the primary action visible on small screens.
- Avoid a dashboard shell on the public generator if it makes the main task harder.
- Mark unfinished features as unavailable or omit them entirely.
