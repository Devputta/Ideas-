# Accessibility and Responsive Requirements

## Accessibility
- Use semantic headings, labels, buttons, and form controls.
- Every input has a persistent accessible label; placeholders are supplementary only.
- Provide visible keyboard focus and logical tab order.
- Do not convey errors or status by color alone.
- Announce important generation, upload, and download results to assistive technology.
- Ensure dialogs can be operated and dismissed by keyboard.
- Respect reduced-motion preferences.
- Maintain readable contrast for text and controls.
- Provide an accessible textual representation of the encoded destination.

## Responsive behavior
- Start with the narrow-screen layout.
- On mobile, stack form controls and QR preview vertically.
- Keep download and generate actions reachable without excessive scrolling.
- Avoid horizontal overflow in the code preview and settings.
- On larger screens, use a balanced editor/preview layout.
- Do not shrink QR modules so much that preview scanning becomes difficult.
- Test at narrow phone widths, tablet widths, and desktop widths.

## Interaction quality
- Use consistent button labels.
- Distinguish primary and secondary actions.
- Disable actions only when there is a clear reason.
- Preserve form values after recoverable errors.
- Provide loading feedback for uploads and bulk processing.
