# Technical Architecture

## Recommended starting architecture
Choose the stack that best fits the repository. For a new implementation:
- Frontend: React + TypeScript + Vite.
- Styling: Tailwind CSS or a small documented CSS design system.
- QR rendering: a maintained QR library such as `qrcode` or `qr-code-styling`; verify current APIs and licenses.
- Optional backend: Node.js or Python FastAPI.
- Optional database/auth: PostgreSQL and a managed authentication provider.
- Optional media storage: S3-compatible object storage or Supabase Storage.

Do not add backend services to the static generator until a real requirement needs them.

## Core modules
- DestinationInput: destination-specific form and validation.
- DestinationBuilder: converts structured data into a destination/payload.
- QRRenderer: creates QR output and preview.
- StyleControls: supported appearance options.
- ExportService: supported file downloads.
- ReadabilityChecks: warnings for contrast, logo size, and density.
- StorageAdapter (optional): upload/download integration.
- RedirectService (optional): dynamic destinations.
- AnalyticsService (optional): disclosed event recording.
- Auth/Repository layer (optional): saved codes and user data.

## Data flow
Input -> Validation -> Destination construction -> QR rendering -> Readability checks -> Preview -> Export

For media:
File -> Server validation -> Storage -> Share URL -> Destination construction

For dynamic QR:
Create destination record -> Generate application redirect URL -> Scan request -> Minimal event logging -> Redirect

## Architecture rules
- Keep QR generation independent of account features.
- Keep destination builders separately testable.
- Do not put secrets in client bundles.
- Use environment variables for server-side configuration.
- Keep integrations behind adapters so providers can be changed.
- Add observability without logging sensitive payloads.
- Document deployment assumptions and failure modes.

## Deployment
The static generator can be hosted on a static frontend platform. Backend-dependent features require a backend and persistent storage. Configure CORS narrowly, enforce HTTPS in production, and document required environment variables without committing secret values.
