# Product Brief

## Product
**QRForge** — Universal QR Code Platform.

## Problem
People need QR codes for different destinations and often encounter separate tools, cluttered interfaces, confusing settings, or misleading claims about tracking and dynamic behavior.

## Product goal
Provide a dependable place to create and download readable QR codes, with helpful presets for common destination types and an upgrade path to code organization and dynamic links.

## Primary audiences
- Individuals sharing websites, portfolios, and contact details.
- Creators sharing YouTube videos, playlists, images, and social profiles.
- Shops, restaurants, educators, event organizers, and small businesses sharing locations, menus, documents, and promotions.

## Core value
Create a QR code quickly, understand exactly where it leads, customize it safely, and download a file that scans reliably.

## Success measures
Use real measured data only. Candidate measures:
- Successful generation rate.
- Time from opening the generator to download.
- Export failure rate.
- QR scan success in test devices.
- User-reported difficulty.
Do not fabricate numbers or show empty charts as if they contain real analytics.

## Out of scope for the first release
- Payment subscriptions.
- Unverified scan geolocation.
- AI-generated QR artwork that may not scan.
- Public directory of users' uploaded files.
- Promises that every external platform will open identically on every device.

## Product promise
QRForge helps users create useful QR codes. It does not guarantee availability of third-party destinations or the continued operation of externally hosted content.
