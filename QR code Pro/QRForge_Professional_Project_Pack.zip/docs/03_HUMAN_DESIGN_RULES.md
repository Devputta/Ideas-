# Human Design Rules

This document is mandatory for every page and component.

## Visual direction
- Build a practical software product, not a generic AI landing page.
- Use a restrained charcoal/near-black theme with one controlled lime accent; provide a complete light theme if theme switching is included.
- Use a consistent type scale, spacing system, border radius, and icon style.
- Prefer real interface hierarchy over decorative gradients, glows, floating orbs, and excessive glass effects.
- Use typography and spacing—not decoration—to create emphasis.
- Use icons only when they clarify meaning; pair unfamiliar icons with labels.
- Avoid unnecessary animation, oversized hero text, and empty dashboard cards.

## Human-centered behavior
- Every visible button must work or be visibly disabled with an explanation.
- Do not use placeholder charts, fake notifications, fake user counts, fake testimonials, invented ratings, or fake customer logos.
- Do not claim a feature is live until its end-to-end path works.
- Show meaningful empty states with a clear next action.
- Use specific error messages that explain how to recover.
- Preserve user input when validation fails.
- Keep the primary task easy to find on mobile and desktop.
- Never hide important limitations in tiny text.

## QR usability
- Use a safe default high-contrast design.
- Preserve a quiet zone.
- Do not allow a logo or decorative pattern to silently make a code unscannable.
- Provide a plain fallback style.
- Test actual downloads using multiple QR scanner apps and devices.

## Copy rules
- Write concise, literal interface language.
- Prefer “Download PNG” over “Unlock your creativity.”
- Avoid empty marketing language such as “revolutionary,” “seamless,” “next-generation,” and “magic.”
- Do not imply that a scan was recorded unless the relevant tracking feature actually recorded it.
- Do not describe a static QR as editable after printing.

## Review question
Would a careful human product designer ship this component because it helps the user, or is it present only to make the screen look impressive? Remove the latter.
