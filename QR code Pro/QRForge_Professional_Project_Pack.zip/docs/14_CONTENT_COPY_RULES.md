# Content and Interface Copy Rules

## Voice
Be direct, calm, precise, and helpful. Avoid exaggerated promises and vague marketing language.

## Good examples
- “Paste a website URL.”
- “Your QR code is ready.”
- “Download PNG.”
- “This code opens the Google Maps search for the address you entered.”
- “This file link may require permission to open.”
- “The logo may reduce scan reliability. Try a smaller logo or reset to the plain style.”
- “Scan analytics are available only for dynamic QR codes.”
- “Upload failed. Check the file type and size, then try again.”

## Avoid
- “Guaranteed to work everywhere.”
- “Track every person who scans.”
- “AI-powered magic.”
- “Your QR is permanently editable” for a static QR.
- “Location verified” when only a text search URL was created.
- Fake urgency, fake counters, invented customer logos, or fabricated reviews.

## Status messages
Only show success after the operation has actually completed. Distinguish:
- Input accepted.
- QR generated locally.
- File downloaded or download initiated.
- File uploaded.
- Record saved.
- Scan event recorded.

These are different events and must not be conflated.

## Third-party names
Use platform names only to describe compatibility. Do not imply official endorsement or partnership without permission.
