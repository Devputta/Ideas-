# Delivery Roadmap

## Phase 1 — Reliable core
- Website URL QR.
- Google Maps share URL, place/address search, and directions URL.
- YouTube and social links.
- High-contrast default design.
- Live preview and PNG export; SVG only after validation.
- Responsive UI, field validation, and tests.

**Exit criteria:** core QR codes scan and open the expected destinations on real devices.

## Phase 2 — Design controls
- Safe colors and selected patterns.
- Optional logo with readability warnings.
- Export quality improvements.
- Light theme if supported consistently.

**Exit criteria:** custom codes remain scannable in tested scenarios.

## Phase 3 — Content and media
- File upload and storage.
- Share links for images, videos, and documents.
- Access permissions, file limits, deletion, and retention.
- File validation and abuse controls.

**Exit criteria:** uploaded content can be reached according to the displayed access policy.

## Phase 4 — Accounts and organization
- Authentication.
- Saved QR codes.
- Search, folders, duplicate, rename, archive, and delete.
- Per-user authorization.

**Exit criteria:** user data isolation and deletion are tested.

## Phase 5 — Dynamic links and analytics
- Application-owned redirect records.
- Destination editing.
- Minimal disclosed event collection.
- Analytics UI based on real recorded events.
- Retention and abuse response.

**Exit criteria:** dynamic behavior and analytics are tested end to end.

## Phase 6 — Bulk generation and service hardening
- CSV validation and row-level feedback.
- ZIP export.
- Rate limits, operational monitoring, backups, and release procedures.

Do not start all phases at once. Release a useful, stable core before adding backend complexity.
