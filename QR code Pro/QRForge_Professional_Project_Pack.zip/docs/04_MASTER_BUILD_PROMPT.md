# Master Build Prompt

Use this prompt with your AI coding tool after adding this documentation folder to the project.

---

Act as a senior product engineer, UX designer, and security-conscious full-stack developer. Build **QRForge**, a reliable universal QR code web application. Treat the project documentation as requirements, not optional inspiration.

## Primary outcome
Deliver a working application that creates scannable QR codes for:
- Website URLs.
- Google Maps places, addresses, shared links, and directions.
- YouTube videos and playlists.
- Social profile and share links.
- Publicly accessible or appropriately shared image, video, and document URLs.
- Email, phone, Wi-Fi, and contact details where supported.

Users must be able to customize safe visual properties, preview the result, and download supported formats.

## Before coding
1. Inspect the existing repository, package manager, framework, and current behavior.
2. Preserve working code and follow existing conventions unless there is a clear reason to change them.
3. Identify missing requirements and state assumptions in a short implementation plan.
4. Do not replace a functioning project wholesale just to impose a preferred stack.
5. Create or update requirements, architecture, design, security, test, and phase documentation.

## Product quality
- Build real functionality end to end.
- Validate URLs and inputs; never treat arbitrary text as a trusted destination.
- Encode Google Maps URLs correctly and preserve valid shared links.
- Make the destination visible before download.
- Use high-contrast QR defaults and maintain the quiet zone.
- Test scanning after customization and export.
- Provide responsive layouts, keyboard access, clear focus states, loading states, empty states, and recoverable errors.
- Make static QR generation usable without account creation.
- Clearly distinguish static QR codes from dynamic redirect-based QR codes.
- Store uploads securely and explain access requirements.
- Never expose API keys, credentials, private storage paths, or server secrets in client code.

## Human design rules
Follow `03_HUMAN_DESIGN_RULES.md` strictly. Avoid generic AI-generated visual patterns: no gratuitous gradients, excessive glow, random floating decorations, fake dashboards, fabricated activity, fake testimonials, fake user counts, or meaningless animations. Use a consistent design system, restrained colors, real content, precise spacing, and purposeful interactions. Do not add a feature solely because it looks impressive.

## Honest delivery
- Do not fabricate integrations, scan analytics, authentication, storage, or payment flows.
- Do not show analytics without real events.
- Do not label a feature complete unless it is implemented and tested.
- Do not claim that a QR contains the actual media; it encodes a destination or payload.
- Do not invent test results. Report tests actually run and any known limitations.
- Do not silently discard existing user data or working features.

## Engineering process
1. Inspect repository and document the plan.
2. Build the core generator and validation.
3. Implement Google Maps and other destination presets.
4. Add customization and export.
5. Test QR readability on real devices.
6. Add optional accounts, media storage, dynamic redirects, analytics, and bulk generation only in planned phases.
7. Run lint, type checks, unit tests, build, and manual acceptance tests available in the repository.
8. Fix regressions before completion.
9. Update README and docs to match the shipped implementation.

## Completion report
At the end, list:
- Features implemented.
- Important files changed.
- Commands and tests actually run.
- Build/deployment instructions.
- Known limitations.
- Features intentionally deferred.

Start by inspecting the repository. Do not generate a mockup-only result when a functioning implementation is requested.
