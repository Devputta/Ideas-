# UX Flows

## Website QR
1. User chooses Website.
2. User enters a URL.
3. App validates scheme and format.
4. App displays the normalized destination.
5. App renders QR with safe defaults.
6. User optionally customizes appearance.
7. App updates preview and warns about risky contrast/logo settings.
8. User downloads and scans the file.

## Google Maps place
1. User chooses Google Maps.
2. User pastes a Maps share URL or enters a place/address.
3. For a pasted URL, validate the URL and preserve valid share links.
4. For a place/address, build a supported Google Maps search URL using proper URL encoding.
5. For directions, include the destination and selected supported travel mode.
6. Show the destination summary and preview.
7. User downloads and tests the QR.

## Media QR
1. User chooses an existing public/share URL or uploads a supported file.
2. If uploading, validate type and size on the server.
3. Upload to configured storage and obtain a share URL with the intended access model.
4. Encode the share URL, not a local file path.
5. Show the link and access note.
6. Generate and download the QR.

## Error recovery
- Invalid URL: preserve input and explain the expected format.
- Unsupported file: state accepted types.
- Upload failure: allow retry without losing form values.
- Export failure: offer retry and a plain QR fallback.
- QR readability warning: explain the specific risk and provide a safe reset.

## Dynamic QR (later)
1. Create a managed redirect record.
2. Generate a QR for the application's redirect URL.
3. Record eligible scan requests with privacy notice.
4. Redirect to the current destination.
5. Allow the owner to update or disable the destination.
6. Explain that the code depends on QRForge's service availability.
