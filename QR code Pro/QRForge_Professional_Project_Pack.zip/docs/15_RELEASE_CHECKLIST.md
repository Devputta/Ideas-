# Release Checklist

## Product
- [ ] Website QR generation works.
- [ ] Google Maps shared links and generated place/directions URLs work.
- [ ] YouTube and supported social URLs work.
- [ ] Destination is visible before download.
- [ ] Static generation works without an account.
- [ ] Every visible control has real behavior.
- [ ] Unsupported features are removed or clearly marked unavailable.

## QR quality
- [ ] Quiet zone preserved.
- [ ] Contrast warnings work.
- [ ] Logo size is limited or warned about.
- [ ] PNG export tested.
- [ ] SVG/PDF export tested if included.
- [ ] Downloaded output scanned on real devices.
- [ ] Plain fallback is available.

## Security and privacy
- [ ] No secrets committed.
- [ ] Server-side input validation implemented where needed.
- [ ] Upload limits and file type checks implemented if uploads exist.
- [ ] Authorization tests pass if accounts exist.
- [ ] Analytics collection is disclosed if enabled.
- [ ] Retention and deletion behavior documented.
- [ ] Privacy and terms pages reflect actual behavior.

## Engineering
- [ ] Build passes.
- [ ] Lint/type checks pass where configured.
- [ ] Unit and integration tests pass.
- [ ] No unresolved critical errors in the browser console.
- [ ] Mobile layout reviewed.
- [ ] Environment variables documented in `.env.example`.
- [ ] Deployment instructions are accurate.
- [ ] README reflects implemented features, not the future roadmap as completed.

## Release notes
Record version, date, changes, test commands actually run, known issues, and rollback steps. Do not claim tests passed unless they were executed.
