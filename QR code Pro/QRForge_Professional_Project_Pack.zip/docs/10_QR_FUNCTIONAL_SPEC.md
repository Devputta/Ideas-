# QR Functional Specification

## Payload types
Implement only payload types that have clear encoding and test coverage.

### URL
- Trim accidental surrounding whitespace.
- Parse with a standards-based URL parser.
- Require an allowed scheme.
- Preserve meaningful path, query, and fragment.
- Show the final encoded destination to the user.

### Google Maps
Support:
- Existing Google Maps share URLs.
- Place/address search URLs built with URL encoding.
- Directions URLs with a destination and optional origin/travel mode where supported.
Do not claim a place has been verified unless a real place lookup was performed. A text search URL is not proof that a particular business exists.

### YouTube and social platforms
- Accept valid URLs from supported platforms.
- Avoid brittle parsing of short links unless tested.
- Do not imply that the app is affiliated with or endorsed by third-party platforms.

### Email and phone
- Encode `mailto:` or `tel:` payloads only after validating and escaping structured values.
- Explain that scanner behavior depends on the user's device and installed apps.

### Wi-Fi and contact cards
- Use the library's documented payload format.
- Escape special characters correctly.
- Warn users that a QR containing a Wi-Fi password or personal contact details can be read by anyone who scans it.

## Visual settings
- Foreground/background contrast must be checked.
- Preserve a quiet zone.
- Restrict logo size to a tested safe range.
- Provide a plain high-contrast fallback.
- Avoid gradients or effects that make module boundaries unclear.

## Export
- PNG: confirm dimensions and file creation.
- SVG: sanitize/produce SVG through a trusted library; avoid unsafe string concatenation.
- PDF: implement only with tested libraries and confirm print dimensions.
- Filenames should be readable and sanitized.

## Readability acceptance
Scan downloaded files—not just the on-screen preview—using multiple scanner apps or devices. Test long URLs, dense payloads, custom styles, logos, and different export sizes.
