# Product Requirements

## Functional requirements

### QR generation
- Accept and validate a destination before encoding it.
- Generate a QR code for a valid website URL.
- Support Google Maps links and construct supported place/address/directions URLs from user input.
- Provide presets for YouTube, social profiles, email, phone, Wi-Fi, contact cards, and file links where applicable.
- Show the destination in readable text near the preview.
- Let users download the generated result in supported formats.
- Keep the code preview synchronized with customization settings.

### Customization
- Allow foreground and background color selection.
- Offer a small, tested set of dot and corner styles if the selected library supports them.
- Allow an optional center logo with a warning that large logos can reduce scan reliability.
- Preserve a quiet zone around the code.
- Warn about low contrast and risky styling.
- Provide a reset-to-safe-defaults action.

### Media links
- For uploaded media, upload the file to approved storage and encode its resulting share URL.
- Validate file type and size on the server.
- Explain whether the file is public or requires access permissions.
- Never encode a local computer path as if it were publicly accessible.

### Accounts and saved codes (later phase)
- Allow signed-in users to save, search, rename, organize, duplicate, and delete their codes.
- Keep each user's saved records isolated.
- Provide account deletion and data export processes where supported.

### Dynamic QR and analytics (later phase)
- Use an application-owned redirect URL.
- Permit the owner to update its destination without changing the printed QR code.
- Record only disclosed, necessary scan events.
- Distinguish total requests from estimated unique scans.
- Do not promise exact physical-world scan counts.

### Bulk generation (later phase)
- Parse CSV safely, validate each row, show row-level errors, and allow correction.
- Use predictable filenames and produce a ZIP only after successful generation.
- Set sensible limits for rows, file size, and processing time.

## Non-functional requirements
- Mobile-first responsive layout.
- Keyboard accessible controls and visible focus.
- Core generation should work without creating an account.
- No secrets in frontend code.
- Helpful loading, empty, success, and failure states.
- No dead buttons, fake data, or decorative controls presented as functional.
- Automated tests for critical validation and generation paths.
- Document browser and format support.

## Acceptance criteria
A release is acceptable only when a user can enter a valid destination, preview the code, download a supported file, scan it with a real device, and reach the expected destination.
