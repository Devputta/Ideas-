# QRForge — Universal QR Code Platform

QRForge is a web application for creating, customizing, organizing, and downloading QR codes for websites, Google Maps locations, videos, social profiles, files, and other supported destinations.

## Product principles

- Useful before impressive: prioritize fast, reliable QR generation.
- Honest functionality: never display metrics or integrations that are not implemented.
- Human-centered interface: clear hierarchy, restrained styling, predictable interactions.
- Accessible output: generated codes must remain scannable after customization.
- Privacy by design: collect only the data required for an explicitly enabled feature.

## Planned capabilities

1. Website and arbitrary URL QR codes.
2. Google Maps place, address, shared-link, and directions QR codes.
3. YouTube and social profile QR codes.
4. QR codes pointing to hosted images, videos, and documents.
5. Custom colors, shapes, optional center logo, and preview.
6. PNG and SVG export; PDF export if implemented and tested.
7. Saved codes, folders, and search for authenticated users.
8. Dynamic destinations and scan analytics as later, clearly documented features.
9. CSV bulk generation and ZIP export as a later feature.

## Documentation

- `docs/01_PRODUCT_BRIEF.md` — purpose, audience, boundaries.
- `docs/02_REQUIREMENTS.md` — functional and non-functional requirements.
- `docs/03_HUMAN_DESIGN_RULES.md` — visual and interaction rules.
- `docs/04_MASTER_BUILD_PROMPT.md` — implementation prompt for an AI coding tool.
- `docs/05_INFORMATION_ARCHITECTURE.md` — pages and navigation.
- `docs/06_UX_FLOWS.md` — primary user journeys.
- `docs/07_TECHNICAL_ARCHITECTURE.md` — proposed system structure.
- `docs/08_DATA_MODEL.md` — suggested entities and fields.
- `docs/09_SECURITY_PRIVACY.md` — security and privacy requirements.
- `docs/10_QR_FUNCTIONAL_SPEC.md` — QR encoding and validation rules.
- `docs/11_TEST_PLAN.md` — test cases and acceptance checks.
- `docs/12_ACCESSIBILITY_RESPONSIVE.md` — accessibility and responsive behavior.
- `docs/13_ROADMAP.md` — staged delivery plan.
- `docs/14_CONTENT_COPY_RULES.md` — trustworthy copy and error messages.
- `docs/15_RELEASE_CHECKLIST.md` — production readiness checklist.

## Suggested implementation order

Build the static QR generator first. Validate real scanning and exports. Add Google Maps and content-specific helpers. Add authentication and saved codes only after the core experience is stable. Dynamic QR redirects, analytics, media hosting, and bulk processing should be separate phases.

## Important limitation

A QR code encodes data, commonly a URL; it does not contain a full website, map, image, or video file. Media QR codes point to a publicly reachable or appropriately shared URL. Dynamic QR codes depend on a redirect service remaining online.
