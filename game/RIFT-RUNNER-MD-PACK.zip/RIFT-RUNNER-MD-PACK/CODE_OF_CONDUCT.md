# Code of Conduct

## Our commitment
We aim to make participation in RIFT RUNNER welcoming and respectful for everyone.

## Expected behavior
- Be respectful and constructive.
- Focus criticism on ideas and implementation, not people.
- Accept feedback graciously.
- Share relevant technical context.
- Respect privacy and intellectual property.
- Avoid harassment, discrimination, threats, and personal attacks.

## Unacceptable behavior
- Harassment or intimidation.
- Publishing private information without consent.
- Deliberate disruption of project collaboration.
- Knowingly submitting malicious code or unlicensed assets.
- Abusive or discriminatory language.

## Reporting
Contact the repository maintainer privately using the contact method listed in the repository profile. Reports will be reviewed as fairly and confidentially as practical.

## Enforcement
The maintainer may edit or remove contributions that violate this policy and may restrict participation for repeated or serious violations.
