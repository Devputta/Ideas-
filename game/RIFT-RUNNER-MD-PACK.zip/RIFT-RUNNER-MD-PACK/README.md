# RIFT RUNNER

**Tagline:** RUN BEFORE REALITY COLLAPSES.

RIFT RUNNER is an original, cinematic 3D sci-fi endless-runner concept for desktop and mobile browsers. Control the RIFT-07 survival robot as it races through collapsing worlds, dodges hazards, collects energy cores, and escapes through dimensional rifts.

## Project goals
- Real interactive 3D gameplay, not a static mockup.
- Responsive keyboard and touch controls.
- Third-person camera, running, lane switching, jumping, and sliding.
- Hybrid destruction: choreographed large-scale disasters plus selected physics-driven obstacles.
- Distinct environments with a polished first world before expanding.
- Performance-aware deployment as a static web application.

## Planned technology
- TypeScript, React, Vite
- Three.js and React Three Fiber
- Drei utilities
- Rapier physics for selected interactions
- Zustand or an equivalent lightweight state manager
- Vitest and Playwright where practical

Use compatible stable package versions and follow current APIs. Browser support and visual quality depend on device capabilities.

## Getting started
After the implementation is created:
```bash
npm install
npm run dev
```

Quality checks (provide these scripts in `package.json`):
```bash
npm run typecheck
npm run test
npm run build
npm run preview
```

Do not claim a command passed unless it was actually run.

## Controls
- **A / Left Arrow:** move left
- **D / Right Arrow:** move right
- **W / Up Arrow / Space:** jump
- **S / Down Arrow:** slide
- **Shift:** activate equipped ability
- **Escape:** pause/resume
- **R:** restart after game over
- **Mobile:** swipe left/right/up/down; optional visible touch controls

## Worlds
1. **Neon Collapse** — futuristic megacity and crumbling elevated highways.
2. **Planet Zero** — volcanic wasteland, lava, ash, and falling rocks.
3. **The Lost Eden** — alien jungle, waterfalls, unstable roots, and boulders.
4. **Machine Graveyard** — enormous factory, moving machinery, pistons, and conveyors.
5. **The End of Reality** — floating architecture, dimensional rifts, and disappearing platforms.

World 1 is the first release milestone. Do not label incomplete worlds as finished.

## Hosting
Recommended static hosting:
- Vercel
- Render Static Sites

Suggested Vite settings:
- Build command: `npm run build`
- Publish directory: `dist`

No backend is required for the initial game. Local records must be treated as editable client-side data, not verified online scores.

## Project status
This repository begins as a planning/documentation pack. It is not itself a playable game until the source code, assets, and tests are implemented.

## Asset and licensing policy
Use original assets or assets with licenses that permit the intended use. Record creator, source, license, attribution, and modifications in `ASSET_CREDITS.md`. Do not use ripped game assets or assume public availability means free commercial use.

## Documentation
- `MASTER-PROMPT.md` — full development prompt
- `PHASE-PROMPTS.md` — prompts for incremental implementation
- `GAME-DESIGN.md` — gameplay and world design
- `TECHNICAL-ARCHITECTURE.md` — proposed architecture
- `SECURITY.md` — security and privacy practices
- `PERFORMANCE.md` — graphics and performance targets
- `TEST-PLAN.md` — test strategy and acceptance checklist
- `DEPLOYMENT.md` — Vercel and Render deployment
- `ASSET-CREDITS.md` — asset provenance and licensing
- `CONTRIBUTING.md` — contribution guidance
- `CODE_OF_CONDUCT.md` — community expectations
- `CHANGELOG.md` — release history
- `LICENSE-CHOICE.md` — guidance for selecting a license

## License
See `LICENSE-CHOICE.md` before choosing a license for source code. Third-party assets may have separate terms.
