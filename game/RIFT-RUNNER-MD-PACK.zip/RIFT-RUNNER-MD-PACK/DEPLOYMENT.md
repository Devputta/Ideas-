# Deployment Guide

## Prerequisites
Install a maintained Node.js LTS version compatible with the selected Vite and React packages. Check the current project engine requirements before choosing a version.

## Local development
```bash
npm install
npm run dev
```
Open the local URL printed by Vite.

## Quality checks
Use the scripts actually configured by the project:
```bash
npm run typecheck
npm run test
npm run build
npm run preview
```
If a script does not exist, add it or update this guide. Do not claim commands pass without running them.

## Vercel
1. Push the project to a Git repository.
2. Import the repository into Vercel.
3. Select Vite if framework detection is offered.
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Deploy and test the generated production URL.
7. Configure a custom domain only after the default deployment works.

## Render Static Site
1. Push the project to Git.
2. Create a new Static Site in Render and connect the repository.
3. Build command: `npm install && npm run build` (or Render's standard install step plus `npm run build`).
4. Publish directory: `dist`.
5. Deploy and test the public URL.
6. Configure a custom domain if needed.

## SPA routing
If client-side routes are added, configure the host's rewrite rules to serve the application entry point for those routes. A single-screen game may not need custom rewrites.

## Security headers
Where supported, configure a suitable Content-Security-Policy and other security headers after testing the actual asset and development requirements. Do not apply an overly restrictive policy without verifying that it permits the intended resources. Production should use HTTPS.

## Production checklist
- [ ] Production build succeeds.
- [ ] No local-only asset paths.
- [ ] All required assets are included.
- [ ] Asset licenses are documented.
- [ ] Mobile controls work on the deployed URL.
- [ ] No secrets are present in bundled files.
- [ ] Loading and WebGL errors are handled.
- [ ] Keyboard and touch controls are tested.
- [ ] Pause, restart, and audio controls work.
- [ ] Performance is measured on representative devices.
- [ ] README and known limitations are current.

## Troubleshooting
- **Blank canvas:** check browser console, WebGL support, and asset URLs.
- **Model missing:** verify the asset path, filename case, loading response, and manifest.
- **Build fails:** check Node version and package compatibility; inspect the first meaningful error.
- **Mobile performance is poor:** lower pixel ratio, shadows, particles, physics-body count, and post-processing.
- **Swipe scrolls page:** verify touch event handling and CSS `touch-action` only on the active game surface.
- **Audio is silent:** start or resume the audio context after explicit user interaction.
