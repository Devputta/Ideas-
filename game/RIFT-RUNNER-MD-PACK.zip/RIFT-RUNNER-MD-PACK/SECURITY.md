# Security Policy

## Scope
RIFT RUNNER is intended to be a static browser game. The initial release should not need user accounts, a backend, or personal information.

## Reporting a vulnerability
Please report suspected vulnerabilities privately to the repository maintainer using a contact method published in the repository profile. Include:
- A concise description.
- Steps to reproduce.
- Browser and version.
- Expected and actual behavior.
- A proof of concept that does not harm other users.

Do not publish secrets or personal information in an issue.

## Security requirements
- Never commit API keys, passwords, private signing keys, or credentials.
- Do not execute downloaded or user-provided JavaScript.
- Avoid `eval`, `new Function`, and unsafe HTML injection.
- Validate URL parameters and data read from localStorage.
- Treat all client-side state and scores as user-controlled.
- Use maintained dependencies and review advisories.
- Keep third-party dependencies minimal.
- Use HTTPS for production.
- Configure appropriate security headers through the hosting platform where supported.
- Avoid unnecessary trackers, permissions, and external requests.
- Load external assets only from reviewed sources.
- Review asset licenses separately from code licenses.
- Do not claim that a client-only score or achievement is tamper-proof.

## Data and privacy
The initial version should store only non-sensitive preferences and local gameplay records. Explain any analytics or external services before adding them. Do not collect personal data without a clear purpose and appropriate notice.

## Dependency maintenance
Review dependency alerts regularly. Test updates in a branch before releasing. Do not suppress security warnings without understanding the impact.

## Supported versions
Security fixes should target the currently maintained release branch. Add explicit version support here when public releases begin.
