# Game Design Document — RIFT RUNNER

## High concept
A survival robot races through cinematic science-fiction environments as reality collapses. Players react quickly to readable hazards, use movement skill to survive, and collect energy cores to improve their score and unlock cosmetics.

## Design pillars
1. **Physical presence:** convincing scale, material response, animation, camera, sound, and environmental depth.
2. **Readable danger:** spectacular destruction must communicate where and when the player should react.
3. **Responsive controls:** lane changes, jumps, and slides must feel predictable.
4. **World variety:** every environment has a distinct palette, hazards, audio identity, and rhythm.
5. **Performance-aware spectacle:** prioritize important nearby events and fake distant destruction efficiently.

## Core loop
Run → read hazard → change lane/jump/slide → collect energy → survive a disaster → transition world → increase score and difficulty → fail → review result → retry.

## Player character
RIFT-07 is an original humanoid survival robot with layered gunmetal/titanium armor, a cyan energy core, optical sensors, and visible mechanical joints. The robot is the visual anchor; avoid excessive armor detail that becomes unreadable at gameplay distance.

## Controls
| Action | Desktop | Mobile |
|---|---|---|
| Lane left | A / Left Arrow | Swipe left |
| Lane right | D / Right Arrow | Swipe right |
| Jump | W / Up Arrow / Space | Swipe up |
| Slide | S / Down Arrow | Swipe down |
| Ability | Shift | Dedicated ability button or configured gesture |
| Pause | Escape / UI | Pause button |

## Gameplay rules
- The robot runs forward automatically.
- Track lanes and hazards are visible early enough to react.
- Jump and slide durations are tuned and tested.
- Obstacles use fair collision bounds.
- A collision ends the run or applies a clearly communicated consequence.
- Energy cores reward risk without forcing impossible routes.
- Difficulty rises gradually.
- Standard obstacle patterns always preserve a viable path.

## Destruction
Large disasters are choreographed and predictable enough to play around. Selected small objects use physics. Distant structures and debris use animation, instancing, or particles. A disaster should change the playable track or create a meaningful hazard, not merely decorate the background.

## Worlds
### Neon Collapse
Wet elevated roads, glass towers, steel structures, traffic, emergency lights, falling concrete, road gaps, and laser gates.

### Planet Zero
Volcanic rock, lava, ash, fissures, meteor impacts, and falling rocks.

### The Lost Eden
Alien forest, waterfalls, massive trees, mist, unstable roots, bridges, and boulders.

### Machine Graveyard
Factory interiors, conveyor belts, pistons, rotating machinery, steam, sparks, and falling machine parts.

### The End of Reality
Floating architecture, cosmic sky, dimensional rifts, disappearing platforms, and readable gravity-shift sequences.

## Modes and progression
The initial mode is endless survival. Score and distance are the main results. Energy cores unlock cosmetics and abilities. Keep local progress offline and clearly distinguish it from any future server-verified feature.

## UI screens
Main menu, world select, robot select, settings, controls guide, loading, gameplay HUD, pause, game over, results.

## Audio
Mechanical movement, impacts, collectibles, abilities, world ambience, destruction, portals, and adaptive music. Audio must be controllable and start only after user interaction.

## Accessibility
Readable contrast, large touch targets, keyboard alternatives, reduced-motion options, clear control instructions, pause/resume, and no essential hover-only controls.

## Success criteria
The first world must feel polished, be genuinely playable, have fair obstacle patterns, provide stable controls, and run acceptably on supported devices before expansion to all worlds.
