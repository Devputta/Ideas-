# RIFT RUNNER — Master Development Prompt

Copy this complete prompt into your AI coding tool.

## Role and mission
Act as a senior game director, TypeScript engineer, Three.js / React Three Fiber developer, physics engineer, 3D environment artist, audio designer, QA engineer, security reviewer, and performance specialist.

Build **RIFT RUNNER**, an original cinematic realistic 3D sci-fi endless-runner for desktop and mobile browsers. The player controls RIFT-07, a survival robot sprinting through worlds that collapse around it.

Deliver an actual playable application. Do not deliver only a design document, landing page, screenshots, or nonfunctional buttons. Inspect any existing repository first and preserve working functionality; do not create duplicate applications or remove existing features.

## Product identity
- Name: RIFT RUNNER
- Tagline: RUN BEFORE REALITY COLLAPSES.
- Genre: third-person 3D endless runner / sci-fi survival.
- Target: modern desktop and mobile browsers.
- Visual goal: AAA-inspired cinematic realism adapted to browser performance.
- Original identity: do not copy Temple Run, its characters, assets, branding, levels, or distinctive artwork.

## Technology
Use TypeScript, React, Vite, Three.js, React Three Fiber, Drei, Rapier through a compatible React integration, a lightweight state manager such as Zustand, Vitest, and Playwright where practical. Choose mutually compatible stable versions and use their current APIs. Keep WebGL 2 as the dependable baseline; WebGPU must not be mandatory.

The first release should be frontend-only and work without accounts, a database, or a paid API. Build static output to `dist`.

## Realistic visual direction
Use high-quality GLB/glTF models, physically based materials, appropriate metalness/roughness/normal maps, realistic concrete, glass, metal and terrain textures, carefully composed lighting, shadows, atmospheric fog, sky/environment lighting, restrained bloom and color grading, dust, sparks, smoke, debris, and impact effects. Keep obstacle visibility clear. Do not falsely claim ray tracing or advanced global illumination unless actually implemented.

Avoid a flat 2D presentation, cartoonish proportions, excessive neon outlines, generic placeholder scenery, and a scene made only from cubes. If premium assets are unavailable, create an articulated procedural fallback and document the limitation rather than showing broken models or missing-texture errors.

## Robot: RIFT-07
Create an original humanoid survival robot with human-scale proportions, layered titanium/gunmetal armor, ceramic panels, articulated joints, worn edges, scratches, dust, cyan energy core, and glowing optical sensors.

Required states/animations: idle, running, lane change, jump, landing, slide/crouch, hit reaction, recovery where feasible, failure, dash, and shield. Use a properly rigged animated GLB when available. Keep a documented fallback if not.

## Core gameplay
The robot automatically runs forward on a readable three-lane track.

Desktop:
- A / Left Arrow: lane left
- D / Right Arrow: lane right
- W / Up Arrow / Space: jump
- S / Down Arrow: slide
- Shift: equipped dash/shield
- Escape: pause/resume
- R: restart after failure

Mobile:
- Swipe left/right/up/down for lane change/jump/slide.
- Optional visible touch controls.
- Prevent unwanted page scrolling during active gameplay.
- Make touch targets large and accessible.

Implement responsive lane changes, tuned jump/slide timings, grounded checks, collision bounds, landing, cooldowns, input buffering or graceful input rejection, and recovery from invalid states. Do not allow held keys to trigger unlimited repeated jumps. Use a deterministic runner movement model for responsiveness; use physics selectively.

## Endless track and obstacle generation
Create reusable track segments with curves, elevation, ramps, gaps, broken bridges, safe stretches, obstacle sequences, and energy-core collectibles. Recycle track segments and obstacles. Increase difficulty gradually and fairly. Use deterministic seeds where useful for reproducible tests.

The generator must account for reaction time, lane switching, jump reach, slide duration, and player speed. Never produce ordinary obstacle patterns with no survivable route. Reward skill rather than random unavoidable failure.

## Hybrid destruction
### Scripted large-scale disasters
Choreograph skyscraper collapses, bridges breaking apart, road sections falling away, factory machinery tearing through structures, lava eruptions, and world-ending sequences. Synchronize track changes, dust, debris, sound, lighting, and controlled camera reactions. Give the player readable warnings and time to react.

### Selected physics-driven objects
Use Rapier for a limited number of barriers, crates, small debris, falling machinery parts, and movable objects. Large buildings and distant debris should use animation, particles, or instanced meshes. Recycle or remove completed effects. Do not simulate hundreds of independent bodies on mobile.

## Five worlds
1. **Neon Collapse:** glass-and-steel megacity, elevated wet highways, futuristic traffic, holograms, orange emergency lights, cyan energy, falling concrete, broken lanes, laser barriers.
2. **Planet Zero:** volcanic rock, lava, ash, smoke, fissures, eruptions, falling rocks, meteor hazards.
3. **The Lost Eden:** alien jungle, huge trees, realistic soil/rocks, waterfalls, bioluminescent plants, fog, roots, boulders, unstable bridges.
4. **Machine Graveyard:** huge factory, conveyors, robotic arms, pistons, steam, sparks, rotating machinery and moving barriers.
5. **The End of Reality:** floating architecture, cosmic clouds, rifts, disappearing platforms, spatial distortions, readable gravity/track changes.

Fully polish World 1 first. Build the other worlds through reusable environment definitions and shared gameplay systems. Clearly label unfinished worlds; do not fake completed content.

## World transitions
Create seamless-feeling transitions with warnings, cracks, track collapse, a visible rift, portal entry, controlled lighting/fog/sky/audio changes, and a playable arrival in the next world. Preload critical assets. Do not freeze gameplay for long loads. Provide fallback scenery if optional assets fail.

## Progression
Implement score, distance, energy cores, multiplier, local best score/distance, near-miss rewards if fair, unlockable cosmetics, abilities/cooldowns, and local achievements if practical. Store only suitable non-sensitive settings and records in versioned localStorage. Validate loaded data. Treat local scores as user-editable; do not invent an online leaderboard.

## UI
Build functional title/menu, world selection, robot selection, settings, controls guide, loading screen, gameplay HUD, pause menu, game-over screen, results, restart, and return-to-menu actions.

HUD: score, distance, energy, ability/cooldown, pause, and world indicator. Keep the interface premium, readable, responsive, and out of the hazard sightline. Every button must work. Respect reduced-motion preferences for nonessential effects.

## Camera
Third-person follow camera behind and above the robot. Keep player and upcoming hazards visible. Adapt framing for jump and slide, use subtle speed effects and restrained impact shake, and return smoothly after cinematic events. Avoid clipping and motion that harms playability.

## Audio
Use original or properly licensed sounds: mechanical footsteps, servos, landings, jump/slide, energy collection, shield/dash, metal and concrete impacts, distant collapses, explosions, portals, world ambience, adaptive music, and game-over cues.

Provide master/music/SFX volume and mute. Respect browser autoplay restrictions by starting audio only after user interaction. Avoid clipping and repetitive overlapping effects. Silent play must remain possible.

## Assets and licensing
Prefer original models, textures, animations, and audio. Use GLB/glTF where appropriate. Record asset source, creator, license, attribution, and modifications in `ASSET_CREDITS.md`. Do not use ripped game assets or assume public availability means commercial permission. No API keys or private credentials in client code. Create an asset manifest and gracefully handle missing files.

## Performance
Target 60 FPS on capable desktop hardware and stable performance on supported mobile devices; state clearly that this depends on hardware. Implement adaptive pixel ratio, graphics presets, frustum culling, instancing, object pooling, resource disposal, compressed textures where practical, sensible shadow/light budgets, level of detail where useful, controlled particle counts, delta-time-aware animation, tab visibility handling, and cleanup of event listeners.

Do not update React state on every animation frame. Use refs and efficient mutable transforms for high-frequency scene updates. Reduce expensive effects before sacrificing responsive gameplay.

## Compatibility and accessibility
Support desktop keyboard, mobile touch, portrait and landscape, safe areas, readable text, large touch targets, and pause/resume after tab switching. Recommend landscape for gameplay but remain usable in portrait. Show a useful WebGL-unavailable message. Allow graphics settings to change without a full reload where practical. Provide reduced-motion support and clear control instructions.

## Security and privacy
Keep the initial application static and frontend-only. No secrets, remote executable code, eval, unsafe HTML rendering, unnecessary trackers, or needless permissions. Validate URL parameters and local data. Restrict external asset origins where practical. Use HTTPS in production and suitable security headers where host configuration allows. Audit dependencies. Document any data collection honestly. No login is needed.

## Suggested architecture
Separate UI, game loop, player controller, camera, track generation, obstacle generation, world manager, destruction director, physics, collectibles, score/progression, audio, input, asset manifest, config, and tests. Keep components focused. Adapt the architecture if needed, but avoid giant files and duplicate systems.

## Acceptance criteria
- Dependencies install and production build succeeds.
- Type checking passes.
- No unresolved imports or unhandled missing assets.
- Robot runs; lanes, jump, slide, collisions, score, collectibles, pause, game over, and restart work.
- Track recycles without unbounded object growth.
- Destruction plays without blocking gameplay.
- Keyboard and touch controls work.
- Settings and all advertised buttons work.
- Save data is validated and corrupt data is handled.
- Missing assets and WebGL failures have useful fallbacks.
- Repeated runs do not produce obvious memory leaks.
- Test desktop and mobile layouts.
- Run and report actual test/build results; never claim unrun checks passed.

## Delivery and deployment
Provide runnable source, scripts, documentation, verified checks, asset credits, and limitations. Vite production output should be `dist`. Support Vercel and Render Static Sites with `npm run build` and publish directory `dist`. Include instructions for installation, development, tests, typecheck, build, preview, deployment, custom domain, and troubleshooting.

## Implementation order
1. Playable foundation: 3D scene, robot, camera, lanes, jump, slide, track, obstacles, collision, score, failure, restart.
2. Polish World 1: production assets, materials, lighting, sound, HUD, menu.
3. Hybrid destruction: scripted collapses, interactive obstacles, debris and performance tuning.
4. Progression: energy cores, abilities, cosmetics, local settings and records.
5. Add worlds 2–5 and transitions using reusable systems.
6. QA, accessibility, performance, licensing, documentation, deployment.

If modifying an existing repository, inspect it first, preserve working features, and extend its architecture. Do not silently remove features or create a duplicate app.

Final objective: a genuinely playable, visually impressive, maintainable realistic 3D browser game in which a survival robot races through living science-fiction worlds while reality collapses behind it.
