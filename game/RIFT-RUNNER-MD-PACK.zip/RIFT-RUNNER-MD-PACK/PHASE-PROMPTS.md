# RIFT RUNNER — Incremental Build Prompts

Use these prompts one at a time. After each phase, run the checks and confirm the result before proceeding.

## Prompt 0 — Inspect before changing
Inspect the entire existing repository and report the framework, package versions, entry points, scripts, current features, assets, and errors. Do not edit files yet. Identify the smallest safe implementation plan. Preserve existing functionality, avoid duplicate pages and duplicate systems, and check package compatibility.

## Prompt 1 — Playable 3D foundation
Implement the smallest genuinely playable RIFT RUNNER slice using TypeScript, React, Vite, Three.js, and React Three Fiber. Render a real 3D track, an articulated temporary robot, and a third-person camera. Add three lanes, smooth lane switching, jump, slide, obstacles, collision detection, distance, score, game over, pause, and restart. Add keyboard input and mobile swipe input. Make every UI action work. Use clean modules, avoid per-frame React state updates, and include tests for movement, scoring, and restart. Run typecheck, tests, and production build; report actual results.

## Prompt 2 — Realistic World 1
Polish Neon Collapse. Integrate legally usable GLB assets and high-quality PBR materials. Add realistic road surfaces, glass/steel buildings, fog, atmospheric lighting, shadows, environmental scale, and a readable third-person composition. Add proper robot animation or document the fallback. Create an asset manifest and record asset licenses. Do not reference missing files without fallbacks. Keep the game playable while assets load.

## Prompt 3 — Hybrid destruction
Add a DestructionDirector for scripted large-scale collapses and Rapier-based interactions for selected obstacles. Create one dramatic bridge-collapse sequence with warnings, track changes, debris, dust, sparks, sound, and controlled camera shake. Recycle physics bodies and particles. Keep obstacle readability and a survivable path. Test pause/restart during and after destruction.

## Prompt 4 — Audio and polish
Add properly licensed robot movement sounds, impacts, energy pickups, ambient world audio, portal transitions, and music. Respect browser audio activation rules. Add master/music/SFX controls and mute. Improve menus, HUD, loading, pause, results, and game-over screens. Verify all controls and buttons.

## Prompt 5 — Progression and settings
Add energy cores, abilities/cooldowns, cosmetic unlocks, best score/distance, settings, and local achievements where practical. Version and validate localStorage data; recover safely from invalid or corrupt data. Do not present local scores as online rankings.

## Prompt 6 — Additional worlds
Create Planet Zero, The Lost Eden, Machine Graveyard, and The End of Reality using reusable environment configuration and shared track/obstacle systems. Give each world distinct materials, hazards, ambience, and lighting. Implement readable transitions and preload assets. Do not mark a world complete until it is playable and tested.

## Prompt 7 — Mobile and performance
Test touch input, portrait and landscape, safe areas, keyboard controls, background-tab behavior, and WebGL failures. Add quality presets, adaptive pixel ratio, instancing, pooling, resource cleanup, and particle limits. Test repeated runs and restarts. Optimize the worst bottlenecks first.

## Prompt 8 — Security, QA, and release
Audit dependencies, remove secrets, validate external data, review asset licensing, test corrupt saves and missing assets, run typecheck/tests/build, and test the production preview. Prepare README, SECURITY, asset credits, deployment instructions, and release notes. Report only checks actually performed and list remaining limitations.

## Required response after each phase
1. Files changed.
2. Features implemented.
3. Commands actually run and results.
4. Known limitations.
5. Exact next step.
Do not proceed to the next phase if the current build is broken.
