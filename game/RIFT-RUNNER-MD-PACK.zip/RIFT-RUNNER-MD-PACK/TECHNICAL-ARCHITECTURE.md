# Technical Architecture

## Runtime
Use Vite + React + TypeScript. Three.js renders the 3D scene through React Three Fiber. Use Rapier only for interactions that benefit from physics.

## Suggested module boundaries
- `app/`: application bootstrap and top-level composition.
- `components/ui/`: menus, HUD, settings, pause, results.
- `game/`: scene composition, game loop, state, configuration.
- `player/`: robot model, movement controller, animation state, collision.
- `camera/`: follow camera and bounded cinematic camera events.
- `track/`: segment definitions, generation, recycling.
- `obstacles/`: obstacle definitions, patterns, collision responses.
- `world/`: world manager, environment configuration, transitions.
- `destruction/`: scripted event director, debris, particles.
- `physics/`: physics setup, collision groups, body lifecycle.
- `collectibles/`: energy-core behavior and pooling.
- `progression/`: score, unlocks, local save schema.
- `input/`: keyboard, touch, input arbitration.
- `audio/`: audio lifecycle, effects, settings.
- `assets/`: manifest, loading, fallbacks.
- `tests/`: unit and browser tests.

## State ownership
Use a state manager for low-frequency UI/game state: menu, paused, playing, game-over, score, settings, and selected world. Use refs and mutable Three.js objects for high-frequency transforms and animation. Avoid React rerenders on every frame.

## Frame loop
1. Read normalized input.
2. Update runner movement.
3. Update track and obstacle pools.
4. Update collision checks/physics.
5. Resolve player interactions.
6. Update score and collectibles.
7. Advance scripted destruction events.
8. Update camera and visual effects.
9. Emit UI state changes only when values meaningfully change.

Use delta time and handle tab visibility changes to prevent giant simulation steps after the tab resumes.

## Track and obstacle generation
Use seeded randomness for reproducible cases. Generate a short look-ahead window and recycle old segments. Keep a record of reachable lanes and action timing to reject impossible patterns.

## Destruction
Use scripted animation for large buildings and bridge sections. Use Rapier for selected near-field objects. Use instancing and particles for distant debris. Pool transient effects and cap their count.

## Assets
Load GLB assets through a central manifest. Define fallback assets and loading errors. Reuse materials and geometries. Dispose of GPU resources when truly no longer used. Record license metadata in `ASSET_CREDITS.md`.

## Save data
Use a versioned localStorage schema for settings and local best results. Parse defensively, validate types and ranges, and recover from corrupt data. Never treat local data as secure or authoritative.

## Error handling
Provide clear UI for WebGL unavailable, asset load failure, audio unavailable, and unsupported device capabilities. Log actionable development errors without exposing secrets.

## Testing
Unit-test movement constraints, scoring, obstacle pattern validity, save migration, and configuration. Browser-test menus, gameplay, pause/restart, keyboard, and responsive layout where tooling supports it.

## Architecture rule
Do not introduce a backend until a real requirement exists, such as verified leaderboards or cloud saves. Keep the first game deployable as static files.
