# Contributing to RIFT RUNNER

Thanks for your interest in improving RIFT RUNNER.

## Before making changes
- Read `README.md`, `GAME-DESIGN.md`, and `TECHNICAL-ARCHITECTURE.md`.
- Check existing issues and avoid duplicating work.
- Preserve working gameplay and existing architecture.
- Keep changes focused and explain trade-offs.

## Development workflow
1. Create a branch for your change.
2. Install dependencies using the documented Node.js version.
3. Implement a focused change.
4. Add or update tests.
5. Run typecheck, tests, and production build.
6. Test the relevant gameplay in a browser.
7. Update documentation and asset credits where needed.
8. Submit a pull request with a clear summary and test results.

## Code expectations
- Use TypeScript types rather than broad `any` types.
- Keep game logic separate from UI where practical.
- Avoid React state updates every animation frame.
- Clean up event listeners and GPU resources.
- Keep obstacle patterns fair.
- Consider mobile performance.
- Do not add unlicensed assets or secrets.
- Do not claim tests passed unless they were run.

## Pull request checklist
- [ ] Change is described.
- [ ] Existing functionality is preserved.
- [ ] Tests added/updated where useful.
- [ ] Typecheck and build run.
- [ ] Browser behavior verified.
- [ ] Asset licenses documented.
- [ ] Known limitations stated.
