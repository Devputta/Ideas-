# Choosing a License

This documentation pack does not silently choose a license for all future game code and assets.

## Source code
Choose a license that matches the intended project:
- **MIT:** permissive reuse with attribution and license notice.
- **Apache-2.0:** permissive reuse with explicit patent-related terms.
- **GPL-3.0:** requires covered derivative distributions to remain under the same license.
- **Proprietary:** restricts reuse according to terms you publish and enforce.

Read the full license text and consider your distribution goals before selecting one. If you choose MIT, Apache-2.0, or GPL-3.0, include the complete official license text in a file named `LICENSE`; do not use this guide as a substitute for the license.

## 3D models, textures, animation, and audio
These assets can have separate licenses from the source code. Verify each asset's permissions and attribution requirements and list them in `ASSET_CREDITS.md`.

## Fonts and logos
Check their licenses separately. Do not assume that a font or asset packaged with a tool is automatically licensed for every use.

## Before release
- [ ] Source-code license selected and full text included.
- [ ] Third-party assets reviewed.
- [ ] Attribution requirements met.
- [ ] No assets copied from commercial games without permission.
- [ ] README accurately explains the license and exceptions.
