# Test Plan — RIFT RUNNER

## 1. Installation and build
- [ ] Dependencies install with the documented Node.js version.
- [ ] TypeScript typecheck passes.
- [ ] Unit tests pass.
- [ ] Production build succeeds.
- [ ] Production preview starts.
- [ ] No unresolved imports.
- [ ] No missing required assets or unhandled load failures.

## 2. Player movement
- [ ] Robot runs automatically during gameplay.
- [ ] Left/right lane changes are responsive.
- [ ] Robot cannot move beyond allowed lanes.
- [ ] Jump starts only when allowed.
- [ ] Landing returns to grounded state.
- [ ] Slide starts and ends correctly.
- [ ] Repeated inputs do not lock the character.
- [ ] Collision bounds match the visible robot reasonably well.

## 3. Controls
- [ ] Keyboard controls work.
- [ ] Escape pauses/resumes.
- [ ] Restart works after game over.
- [ ] Mobile swipe directions are recognized.
- [ ] Touch controls do not accidentally scroll the page during play.
- [ ] UI buttons have working actions.
- [ ] Controls remain usable at different viewport sizes.

## 4. Obstacles and track
- [ ] Obstacles spawn in valid positions.
- [ ] The generator preserves a survivable route.
- [ ] Collectibles can be collected.
- [ ] Collision response is consistent.
- [ ] Track segments recycle.
- [ ] Object counts do not grow without bound.
- [ ] Difficulty increases gradually.
- [ ] Pausing and restarting does not leave stale obstacles.

## 5. Destruction
- [ ] Scripted collapse warning is visible.
- [ ] Track changes match the disaster sequence.
- [ ] Physics objects collide as expected.
- [ ] Debris and particles are capped/recycled.
- [ ] Destruction does not permanently block the player.
- [ ] Camera effects remain readable.
- [ ] Pause/restart during a collapse is safe.

## 6. UI and audio
- [ ] Main menu starts a run.
- [ ] Pause and resume work.
- [ ] Game-over screen shows results.
- [ ] Restart returns to a clean run.
- [ ] Settings persist where intended.
- [ ] Audio begins only after user interaction.
- [ ] Master/music/SFX volume controls work.
- [ ] Mute works.
- [ ] Silent play remains possible.

## 7. Persistence and security
- [ ] Invalid localStorage JSON is handled.
- [ ] Out-of-range saved values are rejected or normalized.
- [ ] Version migrations are tested if used.
- [ ] No secrets are bundled.
- [ ] No unsafe HTML rendering or dynamic code execution.
- [ ] Dependency audit is reviewed.
- [ ] Asset licenses are recorded.

## 8. Browser/device coverage
- [ ] Desktop Chrome or Chromium.
- [ ] Desktop Firefox where supported.
- [ ] Safari/WebKit where available.
- [ ] Android browser on a real device.
- [ ] iOS Safari on a real device where available.
- [ ] Portrait and landscape layouts.
- [ ] Tab hide/show behavior.
- [ ] WebGL unavailable/error state.

## 9. Performance
- [ ] Low/medium/high quality settings work.
- [ ] Repeated runs do not show obvious memory leaks.
- [ ] GPU resources are cleaned up appropriately.
- [ ] Loading errors use fallbacks.
- [ ] Mobile frame pacing is measured.
- [ ] Production build is tested, not only the development server.

## Reporting
For each test run, record environment, steps, expected result, actual result, status, and defect reference. Never mark a test passed without running it.
