# Changelog

All notable project changes should be documented here.

The project follows a simple versioning approach once releases begin.

## Unreleased
- Created initial game design and development documentation pack.
- Defined the RIFT-07 robot concept and five planned worlds.
- Specified responsive controls and hybrid destruction.
- Defined security, performance, testing, asset licensing, and deployment guidance.

## Release format
For each release, include:
- Added features.
- Changed behavior.
- Fixed bugs.
- Security changes.
- Known limitations.
