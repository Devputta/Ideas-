# Asset Credits and Licenses

Keep this file updated for every external or commissioned asset included in the game.

## Asset register

| Asset / file | Creator | Source URL | License | Attribution required? | Modifications | Intended use |
|---|---|---|---|---|---|---|
| RIFT-07 robot | TBD | TBD | TBD | TBD | TBD | Player character |
| Neon city environment | TBD | TBD | TBD | TBD | TBD | World 1 |
| Robot running animation | TBD | TBD | TBD | TBD | TBD | Player animation |
| Road and concrete textures | TBD | TBD | TBD | TBD | TBD | Environment |
| Sound effects | TBD | TBD | TBD | TBD | TBD | Gameplay audio |
| Music | TBD | TBD | TBD | TBD | TBD | Background music |

## Rules
- Do not mark an asset as licensed until the license has been checked.
- Confirm commercial-use permissions before a commercial release.
- Record required attribution exactly as required by the license.
- Preserve license copies or links when appropriate.
- Do not use ripped assets from commercial games.
- A free download does not automatically grant commercial rights.
- Source-code licensing and asset licensing may be different.
- Remove assets whose permissions cannot be established.

Replace every TBD entry before a public release.
