# Performance and Graphics Strategy

## Targets
Aim for 60 FPS on capable desktop hardware and stable performance on supported mobile devices. These are targets, not guarantees. Test real devices before publishing performance claims.

## Quality tiers
### High
- Higher pixel ratio, shadows, selected post-processing, more particles, higher-resolution textures.
### Medium
- Moderate pixel ratio, reduced shadow map sizes, fewer particles, fewer expensive lights.
### Low / Mobile
- Lower pixel ratio, minimal post-processing, limited dynamic shadows, reduced debris count, simpler distant scenery.

## Rendering
- Cap device pixel ratio rather than blindly using full native resolution.
- Keep real-time shadow casters limited.
- Use instanced meshes for repeated architecture and debris.
- Reuse geometries and materials.
- Use frustum culling and sensible draw-call budgets.
- Use compressed textures where supported by the asset pipeline.
- Use mipmaps and appropriate texture sizes.
- Consider LOD for distant assets.
- Keep post-processing restrained and optional.
- Do not use costly screen-space effects without measuring them.

## Simulation
- Keep only nearby gameplay objects fully interactive.
- Script large environmental collapses.
- Use particles or instanced meshes for distant debris.
- Pool obstacles, collectible effects, and transient particles.
- Cap active rigid bodies.
- Recycle track segments.
- Avoid creating new arrays, objects, or React state updates unnecessarily in every frame.

## Lifecycle
- Pause or reduce simulation when the tab is hidden.
- Handle visibility restoration safely.
- Dispose of GPU resources when no longer needed.
- Clean up event listeners and animation loops.
- Test repeated restarts and world transitions for memory growth.

## Measurement
Record frame rate and loading time on representative desktop and mobile devices. Use browser performance tools and a development-only FPS display. Remove or gate diagnostic UI from production if it is not intended for players.

## Prioritization
1. Responsive movement and collision.
2. Clear hazards.
3. Stable frame pacing.
4. High-value lighting and materials.
5. Additional particles and optional post-processing.

Never sacrifice readable gameplay to make screenshots look more dramatic.
