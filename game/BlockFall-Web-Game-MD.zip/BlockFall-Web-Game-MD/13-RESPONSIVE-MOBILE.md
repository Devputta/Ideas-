# Responsive Mobile
Desktop: board with side panels for hold/next and score.

Tablet: keep board prominent and rearrange secondary information.

Mobile priority:
1. board
2. score/level
3. next/hold
4. controls
5. pause/restart

Do not shrink the board until cells are unreadable.

Support portrait and optimize landscape where useful. Respect mobile safe-area insets.
