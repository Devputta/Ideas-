# Testing
## Unit
Test pieces, rotation, collision, movement, boundaries, row clearing, scoring, levels, 7-bag and hold rules.

## Integration
Test start, movement, hard drop, line clear, game over, pause/resume, restart and persistence.

## E2E
Open → Start → move → rotate → drop → clear → pause → resume → game over → restart.

## Regression
Verify pieces cannot pass through blocks or boundaries; multiple rows clear correctly; hold cannot be abused; pause stops gravity; corrupt localStorage does not crash the app.
