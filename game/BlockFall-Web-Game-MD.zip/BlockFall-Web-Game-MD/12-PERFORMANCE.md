# Performance
Use requestAnimationFrame for the game loop.

Avoid multiple competing gravity timers.

Do not rerender the whole application for every frame.

Keep rapidly changing game state close to the board.

Reuse audio resources.

Test input latency and battery impact on mobile.
