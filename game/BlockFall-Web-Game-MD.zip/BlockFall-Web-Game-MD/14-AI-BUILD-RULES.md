# AI / Vibe Coding Rules
1. Build a real game engine, not CSS-only fake gameplay.
2. Keep engine logic separate from React.
3. Do not put the entire game in one component.
4. Scores, lines and levels must come from real state.
5. Do not add unnecessary dependencies.
6. Preserve working gameplay when changing UI.
7. Test before declaring a phase complete.
8. Avoid excessive gradients, glass cards and generic AI dashboard styling.
9. Keep keyboard and touch controls accessible.
10. Do not invent a backend for MVP.
11. Explain important architecture decisions.
12. Never replace working rules with hardcoded demo behavior.
