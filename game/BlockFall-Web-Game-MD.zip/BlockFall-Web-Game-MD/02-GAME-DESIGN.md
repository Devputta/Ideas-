# Game Design
Board: 10 columns x 20 visible rows, with optional hidden spawn rows.

Pieces: I, O, T, S, Z, J, L.

Use a 7-bag piece randomizer rather than naive random selection.

Ghost piece shows the legal landing position but never changes game state.

Hold, if enabled, allows one stored piece and one hold action per active piece.

Game over occurs when a new piece cannot spawn legally.

Pause stops gravity and gameplay updates. Restart resets the complete game state.

Keep gameplay rules deterministic and testable.
