# BlockFall — Web Puzzle Game
A polished browser-based falling-block puzzle game inspired by classic tetromino gameplay.

## Stack
Next.js, React, TypeScript, CSS/Tailwind, HTML Canvas or CSS Grid, Web Audio API, localStorage.

## Documentation
01-PRD.md
02-GAME-DESIGN.md
03-ARCHITECTURE.md
04-GAME-ENGINE.md
05-UI-UX.md
06-CONTROLS.md
07-SCORING.md
08-DATA-PERSISTENCE.md
09-ACCESSIBILITY.md
10-SECURITY.md
11-TESTING.md
12-PERFORMANCE.md
13-RESPONSIVE-MOBILE.md
14-AI-BUILD-RULES.md
15-PHASES.md
16-BUILD-PROMPTS.md
17-DEFINITION-OF-DONE.md
18-DEPLOYMENT.md
19-ROADMAP.md

The game must be genuinely playable; never replace gameplay with visual-only animations.
