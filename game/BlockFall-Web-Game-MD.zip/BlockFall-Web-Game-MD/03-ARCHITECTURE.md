# Architecture
Keep game engine logic independent from React.

Suggested structure:
```text
src/
  app/
  components/
  game/
    types.ts
    constants.ts
    pieces.ts
    board.ts
    collision.ts
    rotation.ts
    bag.ts
    scoring.ts
    level.ts
    gameLoop.ts
    reducer.ts
    input.ts
  hooks/
  lib/
    storage.ts
    audio.ts
  tests/
```

React renders state and UI. The game engine owns movement, collision, gravity, locking, line clears, scoring and state transitions.

The UI must never directly mutate the board.
