# Deployment
Deploy the Next.js application to Vercel or another modern web host.

Verify:
- production build
- HTTPS
- no committed secrets
- security headers
- keyboard controls
- touch controls
- sound toggle
- localStorage
- game over
- restart
- refresh behavior

Suggested repository: `blockfall-web`.

Suggested product name: BlockFall.
