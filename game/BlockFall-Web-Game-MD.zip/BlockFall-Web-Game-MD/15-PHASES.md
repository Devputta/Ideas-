# Build Phases
## 0 Foundation
Next.js, TypeScript, styling, linting, tests, project structure.

## 1 Board
10x20 state and renderer.

## 2 Pieces
Seven tetrominoes, spawn and 7-bag.

## 3 Movement
Left, right, down and collision.

## 4 Rotation
Rotation states and boundary/collision handling.

## 5 Lock/Clear
Locking, row detection, removal and spawning.

## 6 Scoring
Score, lines, level and gravity.

## 7 Gameplay
Next, ghost, hold, pause, restart, game over.

## 8 Controls
Keyboard and touch.

## 9 Audio/Polish
Sound, mute and restrained feedback.

## 10 Persistence
High scores, settings and statistics.

## 11 Responsive
Desktop/tablet/mobile.

## 12 Testing
Unit, integration, E2E and accessibility.

## 13 Performance
Rendering, input and bundle optimization.

## 14 Production
Deployment, HTTPS, headers and smoke tests.
