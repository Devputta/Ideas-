# Build Prompts
## Global instruction
Read README and relevant docs before each phase. Inspect existing code. Do not invent requirements. Preserve working gameplay. Do not fake core functionality. Separate engine and UI. Follow accessibility/performance rules. Run tests.

## Phase 0
Create the Next.js TypeScript foundation, testing, linting and modular game-engine structure.

## Phase 1
Implement the real 10x20 board and renderer with board unit tests.

## Phase 2
Implement seven tetrominoes, spawn and deterministic 7-bag generation.

## Phase 3
Implement collision and movement with boundary tests.

## Phase 4
Implement collision-aware rotation and deterministic wall handling.

## Phase 5
Implement locking, row clearing and next-piece spawning.

## Phase 6
Implement score, lines, levels and gravity using the scoring specification.

## Phase 7
Implement next, ghost, hold, pause, restart and game over.

## Phase 8
Implement keyboard and touch controls and prevent unwanted browser scrolling.

## Phase 9
Add restrained sound effects, mute and reduced-motion support.

## Phase 10
Add validated localStorage persistence.

## Phase 11
Make the interface genuinely responsive and mobile-friendly.

## Phase 12
Add unit, integration and browser tests.

## Phase 13
Profile and remove unnecessary rerenders/timers.

## Phase 14
Prepare production build, HTTPS, security headers and final smoke tests.

Final rule: do not declare completion because the UI looks polished. Gameplay, controls, persistence, accessibility and tests must work.
