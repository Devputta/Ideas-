# Definition of Done
## Gameplay
Board, seven pieces, movement, rotation, collision, line clearing, score, level, gravity and game over all work.

## Features
Next, ghost, hold, pause, restart, high score and sound toggle work.

## Input
Keyboard and touch work without unwanted browser behavior.

## Quality
No fake gameplay, fake statistics, major console errors or giant component.

## Accessibility
Keyboard navigation, focus, labels, screen-reader status and reduced motion.

## Testing
Unit, integration and E2E tests pass.

## Production
Production build passes; HTTPS and security headers are configured; desktop and mobile smoke tests pass.
