# Game Engine
State should include board, activePiece, nextQueue, heldPiece, canHold, score, level, lines and status.

Use requestAnimationFrame and elapsed time for gravity rather than assuming a fixed render rate.

A placement is invalid if a block is outside the board or overlaps an occupied cell.

Lock flow:
1. lock active piece
2. clear complete rows
3. update lines/score/level
4. spawn next piece
5. check game over

Rotation must validate the resulting placement before applying it. Wall-kick behavior, if used, must be deterministic.

Allow an injected piece sequence/randomizer for tests.
