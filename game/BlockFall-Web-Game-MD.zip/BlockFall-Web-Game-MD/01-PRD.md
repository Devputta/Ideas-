# Product Requirements
## Product
BlockFall — responsive browser falling-block puzzle game.

## MVP
10x20 board; seven tetrominoes; movement; rotation; soft/hard drop; collision; line clearing; score; level; increasing speed; next piece; ghost piece; pause; restart; game over; keyboard and mobile controls; sound toggle; local high score.

## Optional
Hold piece, statistics, achievements, daily challenge, game history, themes.

## Non-goals
No multiplayer, accounts, ads, payments, chat or online leaderboard in MVP.

## Success
A user can open the site, play with keyboard/touch, clear lines, progress, pause/resume, and receive a correct final score.
