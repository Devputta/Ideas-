# Accessibility
Requirements:
- keyboard playable
- visible focus
- semantic buttons
- accessible labels
- screen-reader status announcements
- sufficient contrast
- reduced-motion support
- never rely on color alone

Announce meaningful events such as game start, line clear, level increase, pause and game over, but not every animation frame.
