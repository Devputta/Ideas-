# Security
MVP has no authentication or backend.

Treat localStorage as user-controlled. Never trust it for permissions, paid features or competitive scores.

If an online leaderboard is later added, scores must be validated server-side and protected with rate limits and anti-cheat measures.

Do not add unnecessary third-party scripts.

Deploy over HTTPS with appropriate security headers.

Do not collect personal information for the MVP.
