# Data Persistence
MVP uses localStorage only.

Store:
- high score
- best lines
- best level
- total games
- total lines
- settings
- sound preference
- theme
- optional achievements/history

Use a namespaced key such as `blockfall:v1`.

Treat stored data as untrusted. Parse and validate it. Corrupt data must fall back to safe defaults.

Do not store personal information.
