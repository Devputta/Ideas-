# Controls
Keyboard:
- Left/A: move left
- Right/D: move right
- Down/S: soft drop
- Up/W: rotate
- Space: hard drop
- C: hold
- P/Escape: pause
- R: restart

Prevent browser scrolling for game keys.

Mobile must have visible, large touch controls for left, right, rotate, soft drop, hard drop, hold and pause.

Buttons require accessible labels.
