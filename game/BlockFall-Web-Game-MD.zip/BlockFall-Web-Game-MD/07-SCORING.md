# Scoring
Suggested baseline:
- Single: 100 x level
- Double: 300 x level
- Triple: 500 x level
- Four lines: 800 x level

Optional small score for soft/hard drop distance.

Level:
`floor(lines / 10) + 1`

Keep score and gravity formulas in dedicated game modules, not UI components.
