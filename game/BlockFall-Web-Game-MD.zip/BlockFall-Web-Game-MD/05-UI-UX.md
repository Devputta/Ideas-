# UI/UX Rules
The product should feel like a polished arcade game, not an AI-generated SaaS dashboard.

Prioritize the game board.

Avoid excessive gradients, glassmorphism, glowing borders, dashboard cards, fake statistics, decorative badges, giant marketing copy and unnecessary animations.

Suggested desktop layout:
```text
          BLOCKFALL

    HOLD    BOARD    NEXT

          SCORE
          LEVEL
          LINES

        controls/help
```

Use simple typography and restrained panels. The board is the visual focus.

Game-over screen should clearly show score, lines and level with Play Again and Main Menu.

Do not autoplay sound before user interaction.

Use concise copy: Play, Pause, Resume, Hold, Next, Score, Level, Lines, Game Over.
