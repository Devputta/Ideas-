# Roadmap
## v1.0
Complete single-player game.

## v1.1
Achievements, detailed statistics, history and daily challenge.

## v2.0
Optional accounts, cloud saves, leaderboard and challenges.

Online competitive features require real backend validation and anti-cheat controls.

## v3.0
Optional multiplayer, replays and tournaments.

Do not build online infrastructure until the local game is stable.
