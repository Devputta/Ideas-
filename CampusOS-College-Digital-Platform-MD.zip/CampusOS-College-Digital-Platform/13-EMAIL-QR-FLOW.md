# CampusOS Email and QR Flow

## Event registration

```text
Student
  ↓
Register
  ↓
Server validates
  ↓
Database transaction
  ↓
Ticket created
  ↓
Email job created
  ↓
Transactional email provider
  ↓
Student receives confirmation
```

## Ticket

Ticket contains:
- event information
- attendee name
- permitted student information
- ticket status
- QR

QR contains:
- opaque ticket reference or signed non-sensitive value

QR does NOT contain:
- password
- auth token
- student private information
- database ID if avoidable
- database credentials

## Check-in

```text
Camera
  ↓
QR decoded
  ↓
POST /api/checkins
  ↓
Authenticate organizer
  ↓
Verify event assignment
  ↓
Verify ticket
  ↓
Verify registration
  ↓
Verify ticket state
  ↓
Atomic check-in
  ↓
Success
```

## Race condition

Two scanners may scan the same QR at nearly the same time.

Database transaction + unique check-in constraint must guarantee only one succeeds.

One request:
`SUCCESS`

Other:
`ALREADY_CHECKED_IN`

## Email safety

Do not allow arbitrary user-controlled recipient addresses in privileged server-side email APIs without authorization.

Avoid sending sensitive information unnecessarily.

## Retry

Email retries must be idempotent.

Do not send unlimited duplicate emails.
