# CampusOS Roles and Permissions

## Student

Can:
- view own profile
- edit permitted profile fields
- view published events
- register/cancel where allowed
- view own ticket
- view own registration history
- view notices intended for them
- submit permitted requests

Cannot:
- scan tickets
- access other students' profiles
- access admin reports
- modify event capacity
- publish events

## Faculty

Can access faculty-authorized academic and department data.

Cannot automatically access college-wide admin controls.

## Organizer

Can:
- manage assigned events
- view assigned event attendees
- scan tickets for assigned events
- view permitted student fields
- export assigned attendance

Cannot:
- modify global roles
- access unrelated event attendee data

## Department Admin

Can manage department-scoped users, events, notices and reports.

## College Admin

Can manage college-wide:
- users
- departments
- events
- notices
- reports
- configuration

## Super Admin

Can manage:
- roles
- security configuration
- platform settings
- audit access

Super Admin actions must be strongly audited.

## Permission rule

Permissions are checked against the actual resource.

Example:

An organizer role alone is insufficient to scan an arbitrary event. The organizer must also be assigned to that event.
