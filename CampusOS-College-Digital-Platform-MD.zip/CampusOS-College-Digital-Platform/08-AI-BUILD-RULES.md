# AI / Vibe Coding Rules for CampusOS

These rules must be supplied to any coding AI before implementation.

## Rule 1 — Do not invent requirements

Follow the PRD and phase documents.

If a feature is not required, do not silently add it.

## Rule 2 — No fake functionality

Do not create:
- fake login
- fake QR scanner
- fake email
- fake database
- fake analytics
- fake API responses
- hardcoded attendance
- simulated success messages

If infrastructure is not configured, clearly mark the integration boundary instead of pretending it works.

## Rule 3 — Security before convenience

Never bypass authorization to make a demo work.

Never move sensitive logic to the browser.

Never expose service credentials.

## Rule 4 — Build end-to-end

A feature is incomplete if only its UI exists.

Example:

Event registration must connect:

```text
UI
→ validation
→ server action/API
→ authorization
→ database
→ ticket creation
→ email job
→ ticket page
```

## Rule 5 — Preserve existing behavior

Before changing code:
- inspect related modules
- understand dependencies
- avoid unnecessary rewrites
- run tests

## Rule 6 — No giant files

Separate domain logic.

Do not create one 2,000-line component containing the entire application.

## Rule 7 — Realistic UI

No excessive:
- gradients
- animations
- cards
- icons
- rounded containers

## Rule 8 — Never hardcode secrets

Use environment variables.

## Rule 9 — Validate twice

Client validation improves UX.

Server validation provides security.

Both are required.

## Rule 10 — Database constraints matter

Do not rely only on application code for uniqueness or critical integrity.

## Rule 11 — Explain destructive actions

Delete/cancel/role-change operations require confirmation and authorization.

## Rule 12 — Tests are part of implementation

Each critical feature requires tests for:
- success
- unauthorized access
- invalid input
- duplicate request
- edge cases

## Rule 13 — Do not rewrite unrelated code

Small targeted changes are preferred.

## Rule 14 — No placeholder TODOs in completed phases

A phase cannot be marked complete when core functionality is still mocked.

## Rule 15 — Human review

Every generated screen must pass the UI human-quality gate in `07-UI-UX-RULES.md`.
