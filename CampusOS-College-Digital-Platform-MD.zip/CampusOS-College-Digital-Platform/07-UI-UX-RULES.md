# CampusOS UI/UX Rules

## Goal

The interface should look like a real college product designed by a product team.

## Avoid

- excessive gradients
- glassmorphism everywhere
- giant hero sections
- random floating cards
- fake statistics
- meaningless charts
- excessive rounded rectangles
- unnecessary animations
- emoji-heavy interfaces
- generic AI dashboard layouts
- invented testimonials
- fake activity feeds
- fake users
- placeholder metrics presented as real

## Use

- clear typography hierarchy
- practical tables
- useful filters
- predictable navigation
- strong empty states
- meaningful confirmations
- restrained color system
- accessible contrast
- responsive layouts
- useful mobile actions

## Mobile

Mobile is not a shrunk desktop.

Examples:
- QR scanner should prioritize camera view and scan result.
- Student ticket should be easy to open at an event entrance.
- Attendance list should remain usable with one hand.
- Navigation should expose the most common actions first.

## Content

Use natural copy.

Bad:
"Unlock the power of your campus journey."

Better:
"Register for upcoming events and keep your tickets in one place."

## Loading

Use skeletons or focused loading states only where useful.

Never show fake content while loading.

## Errors

Errors should explain:
- what happened
- what the user can do next

Never show raw exceptions.

## Forms

- label every field
- show required status
- validate close to the field
- preserve safe user input after recoverable errors
- prevent accidental duplicate submissions

## Accessibility

Support:
- keyboard navigation
- visible focus
- semantic HTML
- accessible labels
- screen reader-friendly status updates
- sufficient contrast
- reduced-motion preference

## Human-quality gate

Before accepting a screen, ask:

1. Would a real student understand this immediately?
2. Is every element useful?
3. Is anything visually decorative without purpose?
4. Does the copy sound human?
5. Are errors actionable?
6. Does mobile behavior make sense?
7. Are loading and empty states realistic?
8. Does this look like a college product rather than an AI template?
