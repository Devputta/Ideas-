# CampusOS Deployment

## Recommended production model

Frontend/application:
- Vercel or equivalent

Database/auth/storage:
- Supabase/PostgreSQL or equivalent managed services

Email:
- Transactional email provider

## Environments

Maintain:
- development
- staging
- production

Do not share production secrets with local development.

## Production checklist

### Application
- production build succeeds
- no debug mode
- no test accounts exposed
- error pages configured
- security headers configured

### Database
- migrations reviewed
- backups enabled
- indexes verified
- least-privilege access
- RLS/policies tested where used

### Authentication
- redirect URLs correct
- production domain configured
- password reset tested
- Google OAuth configured if enabled

### Email
- sender domain configured
- templates reviewed
- failure handling tested

### QR
- scanner camera permissions tested
- QR validation server-side
- duplicate protection tested

### Monitoring
Track:
- application errors
- failed logins
- check-in failures
- email failures
- API latency
- database errors

Do not monitor by collecting unnecessary personal data.

## Rollback

Every production database migration must have a documented recovery strategy.

Never deploy an irreversible schema change casually.
