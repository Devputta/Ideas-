# CampusOS Phase-by-Phase Build Prompts

Use one phase at a time. Do not ask the coding AI to build the entire application in one generation.

## Global instruction

Before every phase:

> Read README.md and all relevant project documentation. Preserve existing functionality. Do not invent requirements. Do not use mock implementations for core functionality. Follow SECURITY, UI/UX and AI BUILD rules. Inspect the existing code before changing it. Implement server-side authorization and validation. Run tests and fix regressions before declaring the phase complete.

## Phase 0 prompt

> Build the CampusOS foundation: Next.js/React/TypeScript structure, database integration, environment handling, linting, formatting, testing, error boundaries, logging and a clean application shell. Do not create fake product data. Establish modular feature boundaries.

## Phase 1 prompt

> Implement authentication with secure sessions, email/password authentication and Google authentication if configured. Add protected routes, logout, password reset and role-aware server authorization. Do not trust client-side roles.

## Phase 2 prompt

> Implement student/faculty profiles and departments. Add secure profile editing and department relationships. Enforce authorization on every server operation.

## Phase 3 prompt

> Implement RBAC and the admin foundation. Add role assignment, department-scoped permissions and audit logging. Prevent privilege escalation and test unauthorized access.

## Phase 4 prompt

> Implement notices with draft/publish lifecycle, audience targeting, department targeting and expiration. Add safe rendering and server-side authorization.

## Phase 5 prompt

> Implement the event system: creation, editing, lifecycle, registration window, capacity, organizer assignment, event discovery and filtering. Use real database persistence and authorization.

## Phase 6 prompt

> Implement event registration end-to-end. Prevent duplicate registration using both application logic and a database uniqueness constraint. Add cancellation and attendee management.

## Phase 7 prompt

> Implement secure QR ticket generation and ticket display. QR must contain only an opaque/signed non-sensitive value. Add transactional email confirmation and do not fake delivery.

## Phase 8 prompt

> Implement camera QR scanning and server-side check-in. Verify organizer authorization, event assignment, ticket validity and registration status. Prevent duplicate check-in atomically. Show clear scan results.

## Phase 9 prompt

> Implement authorized attendance reports and CSV export. Use real data only. Protect exports and create audit records.

## Phase 10 prompt

> Implement production email workflows, delivery status tracking, retry handling and safe templates. Avoid duplicate email sends.

## Phase 11 prompt

> Implement assignments and academic resources with department/course-level authorization. Do not expose resources outside their intended audience.

## Phase 12 prompt

> Implement campus service requests with submission, assignment, status, internal notes and resolution workflow.

## Phase 13 prompt

> Implement document/certificate requests, approvals and secure PDF generation. Protect document access and audit sensitive actions.

## Phase 14 prompt

> Implement analytics using actual persisted data. Avoid fake metrics and unnecessary charts. Restrict analytics according to role.

## Phase 15 prompt

> Refine mobile experience and PWA behavior. Prioritize student ticket access, QR scanning, notices and event registration.

## Phase 16 prompt

> Perform a security audit across authentication, authorization, IDOR, XSS, CSRF, rate limits, uploads, secrets, database policies, QR replay/duplication and audit logs. Add tests for discovered vulnerabilities.

## Phase 17 prompt

> Prepare CampusOS for production deployment. Configure production environment, database migrations, authentication redirects, email, storage, monitoring, backups and final smoke tests. Do not expose secrets.

## Final instruction to coding AI

> Do not declare CampusOS complete because the UI looks finished. Completion requires working end-to-end flows, security tests, database integrity, authorization, responsive UX, tests and the Definition of Done checklist.
