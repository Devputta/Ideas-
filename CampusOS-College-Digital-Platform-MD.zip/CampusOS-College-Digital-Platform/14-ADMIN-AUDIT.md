# CampusOS Administration and Audit

## Admin dashboard

The dashboard should prioritize operational work:

- pending approvals
- active events
- registration totals
- check-in status
- notices
- system issues

Do not fill the page with decorative charts.

## Audit events

Record actions such as:
- role assigned/removed
- event published
- event cancelled
- registration manually changed
- ticket checked in
- attendee export
- user suspended
- security setting changed

## Audit record

```text
actor
action
entity
entity_id
timestamp
result
safe metadata
```

## Audit privacy

Do not store secrets in audit metadata.

Avoid full request bodies when they contain personal information.

## Admin actions

Sensitive actions should have:
- authorization
- confirmation
- audit event
- clear success/failure result

## Role changes

Role changes are high-risk.

Recommended:
- require strong authentication
- show exact new role
- record actor
- record target
- record timestamp

## Suspensions

A suspended account must not retain effective access merely because an old browser session remains valid.

Session revocation strategy must be considered.
