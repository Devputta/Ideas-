# CampusOS Data Privacy

CampusOS handles student and staff information, so data minimization is mandatory.

## Collect only what is needed

For an event, do not collect unrelated information simply because it is available.

## Visibility

A student's phone/email should not automatically appear to every organizer.

Organizers should see only the fields required for event operations.

Example attendee view:

- Name
- Student ID
- Department
- Year
- Registration status
- Check-in status

Phone/email should require a legitimate operational reason.

## Retention

Define retention periods for:
- registrations
- attendance
- email logs
- audit logs
- document requests

Do not keep data forever by default.

## Exports

Exports are privileged operations.

- authorize
- audit
- minimize fields
- protect downloaded files

## Deletion

Support deletion/anonymization according to institutional policy and applicable legal requirements.

Do not delete records required for legitimate audit/accounting purposes without a defined retention policy.

## Privacy by design

Before creating a new field ask:

1. Why is it needed?
2. Who can see it?
3. How long is it retained?
4. What happens if it leaks?

## Security vs privacy

Security protects data from unauthorized access.

Privacy also asks whether the platform should collect or expose the data in the first place.
