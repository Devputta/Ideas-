# CampusOS Environment and Secrets

## Example variables

```env
DATABASE_URL=
DIRECT_DATABASE_URL=

AUTH_URL=
AUTH_SECRET=

GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=

STORAGE_URL=
STORAGE_SERVICE_KEY=

EMAIL_API_KEY=
EMAIL_FROM=

APP_URL=
```

Use the exact variables required by the selected providers.

## Rules

Never commit `.env`.

Commit:
`.env.example`

Do not put:
- service keys
- database passwords
- private OAuth secrets
- email API keys

into client-side variables.

## Public vs private

Only variables explicitly intended for browser use may be exposed to the browser.

Never expose:
- database connection strings
- service-role keys
- admin API keys
- OAuth client secrets

## Rotation

Document how to rotate:
- database credentials
- auth secrets
- email keys
- storage keys
- OAuth secrets

## Local development

Use separate development resources where possible.

Never point a new developer environment directly at production data.
