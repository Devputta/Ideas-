# CampusOS — College Digital Platform

CampusOS is a production-minded digital platform for colleges. It connects students, faculty, departments, organizers and administrators through one system.

## Core modules

- Authentication and role-based access
- Student profiles and department information
- Faculty and department management
- Notices and announcements
- Events and workshops
- Event registration and secure QR tickets
- Organizer camera-based QR check-in
- Attendance and attendee management
- Email confirmations and notifications
- Assignments and academic resources
- Complaints / campus service requests
- Certificates and document requests
- Dashboards and reporting
- Audit logs and security controls

## Product principle

CampusOS must feel like a real college product, not an AI-generated dashboard template.

Do not add features merely because they are technically interesting. Every screen must answer a real campus need.

## Documentation

1. `01-PRD.md` — product requirements
2. `02-ARCHITECTURE.md` — technical architecture
3. `03-DATABASE.md` — database model and data rules
4. `04-API.md` — API conventions and endpoint contracts
5. `05-SECURITY.md` — security requirements
6. `06-ROLES-PERMISSIONS.md` — authorization matrix
7. `07-UI-UX-RULES.md` — realistic human-designed UI rules
8. `08-AI-BUILD-RULES.md` — rules for AI/vibe coding
9. `09-PHASES.md` — complete implementation phases
10. `10-TESTING.md` — testing and acceptance criteria
11. `11-DEPLOYMENT.md` — deployment and production checklist
12. `12-DATA-PRIVACY.md` — privacy, retention and responsible data handling
13. `13-EMAIL-QR-FLOW.md` — email, tickets, QR generation and check-in
14. `14-ADMIN-AUDIT.md` — administration and audit logging
15. `15-ENVIRONMENT.md` — environment variables and secrets
16. `16-DEFINITION-OF-DONE.md` — completion gate
17. `17-BUILD-PROMPTS.md` — phase-by-phase coding prompts

## Recommended stack

- Frontend: Next.js + React + TypeScript
- Styling: Tailwind CSS with restrained custom design
- Backend: Next.js server/API layer or Node.js service
- Database: PostgreSQL
- ORM: Prisma
- Authentication: Supabase Auth or equivalent managed auth
- Storage: Supabase Storage or S3-compatible storage
- Email: transactional email provider
- QR: standards-compliant QR generation/scanning library
- Validation: Zod
- Testing: Vitest/Jest + Playwright
- Deployment: Vercel for web + managed PostgreSQL/Supabase

The exact provider can change, but security boundaries and product behavior must not.

## Non-negotiable

No fake APIs, fake authentication, fake QR validation, fake email success, hardcoded production data, or UI-only security.
