# CampusOS Architecture

## 1. Architecture style

Use a modular web architecture with strict separation between:

- Presentation
- Authentication
- Authorization
- Business logic
- Data access
- External services
- Audit/security logging

Do not put business-critical rules directly into UI components.

## 2. High-level flow

Browser
→ Next.js application
→ server-side route/action
→ authentication check
→ authorization check
→ input validation
→ service/business rule
→ database transaction
→ audit event
→ external notification where required

## 3. Suggested project structure

```text
src/
  app/
  components/
  features/
    auth/
    students/
    departments/
    notices/
    events/
    registrations/
    checkin/
    reports/
    admin/
  lib/
    auth/
    db/
    validation/
    security/
    email/
    qr/
    audit/
  server/
    services/
    repositories/
  types/
tests/
prisma/
```

## 4. Rules

- Server is authoritative for permissions.
- Database is authoritative for persistent state.
- Client state is never trusted for security.
- QR contents are never trusted without server verification.
- Email sending is asynchronous where appropriate.
- Critical state changes use database transactions.

## 5. QR architecture

QR should contain an opaque ticket identifier or signed ticket reference, not sensitive student data.

Scanner sends the ticket reference to the server.

Server verifies:
- ticket exists
- ticket belongs to correct event
- ticket is valid
- registration is confirmed
- event is currently check-in eligible
- scanner user has permission
- ticket has not already been checked in

Then the server atomically records check-in.

## 6. Reliability

Critical operations must be idempotent.

Examples:
- duplicate registration
- duplicate check-in request
- repeated email job
- repeated webhook

Use unique constraints and transaction logic rather than frontend checks alone.
