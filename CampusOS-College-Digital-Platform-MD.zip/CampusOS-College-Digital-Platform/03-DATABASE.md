# CampusOS Database Design

## Core tables

### users / auth identities
Managed by the authentication provider where possible.

### profiles
- id
- auth_user_id
- full_name
- email
- phone
- student_id
- department_id
- year
- semester
- role
- status
- created_at
- updated_at

### departments
- id
- name
- code
- status

### notices
- id
- title
- body
- audience
- department_id nullable
- published_at
- expires_at
- created_by

### events
- id
- title
- description
- location
- start_at
- end_at
- registration_open_at
- registration_close_at
- capacity
- status
- organizer_id
- department_id nullable
- created_at
- updated_at

### event_registrations
- id
- event_id
- student_id
- status
- registered_at
- cancelled_at
- checked_in_at
- checked_in_by

Unique constraint:
`event_id + student_id`

### tickets
- id
- registration_id
- public_ticket_id
- status
- issued_at

Unique:
`public_ticket_id`
`registration_id`

### checkins
- id
- ticket_id
- event_id
- registration_id
- checked_in_by
- checked_in_at
- scanner_device_reference where appropriate

Unique constraint:
`ticket_id`

### audit_logs
- id
- actor_user_id
- action
- entity_type
- entity_id
- metadata
- ip_hash/reference as appropriate
- created_at

### email_events
- id
- recipient reference
- template
- related_entity_id
- provider_message_id
- status
- created_at

## Data rules

- Never store passwords.
- Never store raw QR secrets in logs.
- Never store unnecessary sensitive data.
- Use foreign keys.
- Use indexes for event/date/status and registration lookups.
- Use timestamps in UTC.
- Enforce uniqueness at database level.
- Use soft deletion only where business/legal requirements justify it.

## Transaction-critical operation

Check-in must be atomic:

1. Lock/recheck ticket registration.
2. Verify valid state.
3. Insert check-in.
4. Update registration.
5. Commit.

If any step fails, the whole operation fails.
