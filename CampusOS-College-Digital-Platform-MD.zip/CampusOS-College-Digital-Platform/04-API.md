# CampusOS API Contract

## General rules

- HTTPS only in production.
- JSON request/response format.
- Validate every input server-side.
- Use consistent error responses.
- Never return secrets.
- Do not expose internal database errors.

## Authentication

`GET /api/me`

Returns the authenticated user's safe profile.

## Events

`GET /api/events`
`POST /api/events`
`GET /api/events/:id`
`PATCH /api/events/:id`
`POST /api/events/:id/publish`
`POST /api/events/:id/close`

Authorization is required for write operations.

## Registration

`POST /api/events/:id/register`
`GET /api/events/:id/registration`
`POST /api/registrations/:id/cancel`

Registration endpoint must enforce the database uniqueness constraint.

## Ticket

`GET /api/registrations/:id/ticket`

Only the owner or authorized organizer can access appropriate ticket information.

## Check-in

`POST /api/checkins`

Example request:

```json
{
  "ticketId": "opaque-public-ticket-id",
  "eventId": "event-id"
}
```

Server must independently derive/verify registration details.

Possible responses:

- `200` checked in
- `400` invalid request
- `401` unauthenticated
- `403` unauthorized
- `404` ticket not found
- `409` already checked in
- `422` ticket/event state invalid

## Attendees

`GET /api/events/:id/attendees`

Return only fields the organizer is authorized to see.

## Reports

`GET /api/events/:id/attendance/export`

Export access must be logged.

## Error shape

```json
{
  "error": {
    "code": "ALREADY_CHECKED_IN",
    "message": "This ticket has already been checked in."
  }
}
```

Do not expose stack traces, SQL, tokens or internal identifiers.
