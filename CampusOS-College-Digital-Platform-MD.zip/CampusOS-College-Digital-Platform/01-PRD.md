# CampusOS Product Requirements Document

## 1. Product vision

CampusOS gives a college a single place to manage everyday student-facing digital workflows.

The first release should focus on reliable identity, events, registrations, QR tickets, attendance, notices and administration.

## 2. Users

### Student
Can:
- Create/sign in to account
- Maintain profile
- View department/year information
- Browse notices
- Discover events
- Register for events
- Receive ticket confirmation
- View QR ticket
- Present QR at entry
- View registration/check-in history
- Access allowed academic resources
- Submit service requests

### Faculty
Can:
- Publish permitted academic information
- View department/student information within scope
- Manage assigned events or academic resources
- View reports they are authorized to see

### Organizer
Can:
- Create/manage assigned events
- Configure capacity and registration windows
- View attendee list
- Scan QR tickets using device camera
- Check attendees in
- See department/year/student details allowed by policy
- Export permitted attendance reports

### Department Admin
Can manage department-level records and workflows within assigned scope.

### College Admin
Can manage college-wide configuration, users, events, notices and reports.

### Super Admin
Can manage platform configuration, roles, security policies and audit access.

## 3. MVP

MVP includes:

1. Authentication
2. Student profile
3. Role-based access
4. Departments
5. Notices
6. Events
7. Event registration
8. Secure QR ticket
9. QR scanner
10. Check-in
11. Attendee list
12. Email confirmation
13. Admin dashboard
14. Audit log
15. Basic reports

## 4. Registration data

At minimum:
- Full name
- College email
- Phone where required
- Student ID
- Department
- Year/semester
- Event
- Registration timestamp
- Ticket status
- Check-in status
- Check-in timestamp

Only collect fields that are actually needed.

## 5. Event lifecycle

Draft → Review → Published → Registration Open → Registration Closed → Event Completed → Archived

Only authorized roles can transition an event.

## 6. Registration lifecycle

Pending → Confirmed → Cancelled → Checked In

A checked-in registration cannot be checked in again.

## 7. Later modules

After the event/identity foundation is stable:

- Assignments
- Resources
- Complaints
- Certificate generation
- Document requests
- Clubs
- Library integration
- Analytics
- PWA/mobile enhancements

## 8. Success criteria

A student can register for an event, receive a real confirmation, open a real QR ticket, and an authorized organizer can scan it once and see the correct attendee information.

The same QR cannot produce a second successful check-in.

## 9. Out of scope for MVP

- Full ERP replacement
- Payroll
- Fee collection
- Complex examination management
- Medical records
- Unnecessary social-network features
