# CampusOS Threat Model

## Assets

- Student identity
- Student ID
- Email/phone
- Event registrations
- Tickets
- Attendance records
- Admin accounts
- Department data
- Audit records
- Email credentials
- Database credentials

## Threats and controls

| Threat | Control |
|---|---|
| Stolen student account | secure auth, session management, MFA where available |
| Organizer scans unrelated event | server-side event assignment check |
| QR screenshot replay | ticket state + atomic one-time check-in |
| Duplicate registration | DB unique constraint |
| ID enumeration | authorization + opaque identifiers |
| Admin privilege escalation | server RBAC + audit |
| XSS in notices | escaping/sanitization |
| Malicious uploads | MIME/signature/size validation |
| Email abuse | authorization + rate limiting |
| API abuse | rate limiting + validation |
| Data leakage | least privilege + data minimization |
| Secret leakage | environment secret management |
| Race condition | database transactions and constraints |

## Security review questions

- Can a student read another student's ticket?
- Can an organizer check in an attendee for an unrelated event?
- Can a client modify its own role?
- Can a user call admin APIs directly?
- Can the same QR be checked in twice concurrently?
- Can an event registration exceed capacity under concurrent requests?
- Can a user enumerate IDs and retrieve records?
- Can an uploaded file execute?
- Can a malicious notice execute JavaScript?
- Can password reset/email endpoints be abused?
