# CampusOS Testing Strategy

## Unit tests

Test:
- validation schemas
- permission functions
- registration rules
- event state transitions
- ticket validation
- check-in rules

## Integration tests

Test:
- registration + database
- ticket generation
- check-in transaction
- email job creation
- role restrictions

## End-to-end tests

### Student flow

```text
Sign in
→ Find event
→ Register
→ Open ticket
```

### Organizer flow

```text
Sign in
→ Open assigned event
→ Scan QR
→ Server validates
→ Check-in succeeds
```

### Duplicate flow

```text
Scan same QR again
→ Server rejects
→ No second attendance record
```

## Security tests

Verify:
- student cannot access another student's private data
- organizer cannot scan unrelated events
- student cannot call admin APIs
- manipulated role values do not elevate permissions
- event IDs cannot bypass authorization
- duplicate registration is blocked
- duplicate check-in is blocked
- expired/invalid tickets fail

## Acceptance test

A feature is not complete until its critical success and failure paths are tested.

## Regression

Run the full suite before:
- merging major changes
- production deployment
- changing authentication
- changing database schema
