# CampusOS Product Roadmap

## Release 1 — Campus Events Core

Authentication
Profiles
Departments
Events
Registration
QR tickets
Scanner
Attendance
Email
Admin
Audit

## Release 2 — Academic Campus

Assignments
Resources
Faculty workflows
Department announcements
Academic calendar

## Release 3 — Campus Services

Complaints
Requests
Documents
Certificates
Service tracking

## Release 4 — Insights

Attendance analytics
Event analytics
Department participation
Operational dashboards

## Release 5 — Mobile-first CampusOS

PWA
Install experience
Mobile scanner
Offline-safe limited experiences
Push notifications where appropriate

## Product principle

Expand only after the current release is stable.

Do not add ten modules while authentication, authorization and event check-in are unreliable.
