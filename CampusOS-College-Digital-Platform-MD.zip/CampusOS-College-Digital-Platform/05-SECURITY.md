# CampusOS Security Requirements

Security is part of the architecture, not a final polish step.

## 1. Authentication

- Use a trusted authentication provider.
- Support secure email/password and/or Google login where configured.
- Verify email where policy requires it.
- Use secure session cookies.
- Never store passwords in CampusOS tables.
- Provide secure password reset through the auth provider.
- Revoke sessions after sensitive account events when appropriate.

## 2. Authorization

Use server-side RBAC.

Roles:
- STUDENT
- FACULTY
- ORGANIZER
- DEPARTMENT_ADMIN
- COLLEGE_ADMIN
- SUPER_ADMIN

Never rely on:
- hidden buttons
- route obscurity
- client-side role state
- URL parameters
- localStorage role values

Every protected server action checks authorization.

## 3. IDOR prevention

Never assume that knowing an ID grants access.

Bad:
`GET /api/students/123`

Good:
Server checks whether the current user may access student 123.

Use opaque public identifiers where useful, but authorization remains mandatory.

## 4. QR security

Never put:
- password
- auth token
- private profile data
- raw database credentials
- sensitive student information

inside the QR.

QR should contain a non-sensitive opaque reference or signed value.

Server validation is mandatory.

## 5. Duplicate check-in protection

Frontend:

```text
Scan → show result
```

is not security.

Backend must prevent duplicate check-ins using transaction + unique database constraint.

## 6. Input security

Validate all external input with a schema validator.

Protect against:
- SQL injection
- XSS
- CSRF where applicable
- command injection
- path traversal
- malicious file uploads
- oversized payloads

## 7. XSS

- Escape user-generated content.
- Avoid raw HTML rendering.
- Sanitize rich text if rich text is genuinely required.
- Never inject untrusted content into scripts.

## 8. CSRF

For cookie-authenticated state-changing requests, use the framework's recommended CSRF protections and/or same-site cookie strategy.

## 9. Rate limiting

Rate-limit:
- login
- password reset requests
- registration endpoints
- QR validation/check-in
- public event search
- email-triggering endpoints

## 10. File uploads

For future uploads:
- allow only required MIME types
- verify file signatures where possible
- enforce size limits
- generate safe storage names
- never execute uploaded files
- store outside executable paths
- scan files where appropriate
- never trust original filenames

## 11. Secrets

Secrets must exist only in environment/secret management.

Never commit:
- API keys
- database passwords
- auth secrets
- service-role keys
- email credentials

## 12. Logging

Log security-relevant actions:
- sign-in/security changes
- role changes
- event publishing
- registration management
- check-in
- exports
- admin actions

Do not log:
- passwords
- access tokens
- full QR secrets
- unnecessary personal data

## 13. Database security

Use least-privilege database access.

If using Supabase/Postgres RLS:
- enable RLS for exposed tables
- write explicit policies
- test policies
- never use a service-role key in the browser

## 14. Transport

Production traffic must use HTTPS.

## 15. Dependency security

- Pin/review important dependency versions.
- Run audit checks.
- Remove unused packages.
- Do not blindly install packages suggested by generated code.

## 16. Security headers

Configure appropriate:
- Content-Security-Policy
- HSTS
- X-Content-Type-Options
- Referrer-Policy
- frame protections

Use a CSP compatible with actual app requirements rather than blindly copying a permissive policy.

## 17. Admin security

Super Admin access should receive stronger controls:
- MFA where available
- short session policy
- audit logging
- role-change confirmation
- no shared admin accounts

## 18. Threat model

Consider:
- stolen student account
- compromised organizer account
- malicious QR
- duplicated QR
- screenshot/replay of QR
- unauthorized attendee export
- ID enumeration
- malicious file upload
- email abuse
- database leakage
- XSS through notices/events

## 19. Security principle

Assume the browser can be modified by an attacker.

The server must remain correct.
