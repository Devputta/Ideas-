# CampusOS Definition of Done

A feature is DONE only when all relevant items are true.

## Product

- Requirement exists in PRD.
- User flow is understandable.
- Empty state exists.
- Error state exists.
- Mobile behavior is considered.

## Engineering

- TypeScript passes.
- Lint passes.
- Build passes.
- No unexplained console errors.
- No dead/mock implementation for core behavior.

## Security

- Authentication checked.
- Authorization checked.
- Input validated server-side.
- Sensitive data minimized.
- No secret in client.
- Critical database constraints exist.
- Audit event exists where required.

## Testing

- Unit tests for business rules.
- Integration tests for critical persistence.
- E2E test for critical user flow.
- Unauthorized access test.

## Accessibility

- Keyboard usable.
- Labels present.
- Focus visible.
- Status messages accessible.
- Contrast acceptable.

## Production

- Environment variables documented.
- Migration documented.
- Monitoring considered.
- Failure behavior defined.

## Human UI gate

Reject the feature if it:
- looks like a generic AI dashboard
- uses decorative elements without purpose
- contains fake statistics
- uses unnatural copy
- breaks on mobile
- hides important information behind unnecessary interactions
