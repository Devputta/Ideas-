# 01 - Project Overview: Smart OCR Bill-to-Excel (Lao + English)

## Vision
A web app where users upload bills, receipts, invoices (and later posters), and get clean structured data exported to Excel. Special focus on **Lao-language** documents.

## Problem
- Small businesses in Laos process paper bills manually.
- Mainstream OCR tools handle Lao poorly.
- Raw OCR text is not structured (no columns, no fields).

## Solution
Upload -> Preprocess -> OCR -> Structured extraction -> Human review -> Excel export.

## Target Users
- Small shops, restaurants, accountants
- Freelancers tracking expenses
- Students / researchers digitizing posters

## Core Features (MVP)
1. Upload image/PDF (JPG, PNG, PDF)
2. Image preprocessing (deskew, denoise, contrast)
3. OCR for Lao + English
4. Field extraction: vendor, date, items, qty, price, tax, total, currency
5. Review/edit screen
6. Excel (.xlsx) and CSV export

## Later Features
- Batch upload, history dashboard
- Poster/flyer text extraction
- Expense categories and charts
- User accounts, teams
- API access, mobile app

## Success Metrics
- Field accuracy >= 90% on clean bills, >= 80% on phone photos
- Processing time < 10 seconds per page
- User correction rate < 20% of fields

## Document Index
| File | Topic |
|---|---|
| 01 | Overview |
| 02 | Requirements (SRS) |
| 03 | SDLC plan |
| 04 | Architecture |
| 05 | Tech stack and setup |
| 06 | Database and API |
| 07 | OCR pipeline |
| 08 | Lao language guide |
| 09 | STLC / test plan |
| 10 | Test cases |
| 11 | Security guide |
| 12 | AI prompts |
| 13 | DevOps and deployment |
| 14 | Roadmap and business |
| 15 | Quickstart and starter code |
