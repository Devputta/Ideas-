# 08 - Lao Language Handling Guide

## Why Lao Is Hard
- Script has stacked vowels and tone marks above/below consonants
- **No spaces between words** (spaces separate phrases)
- Similar-looking characters (e.g. ບ / ປ / ຢ, ວ / ຣ, ຕ / ຫ)
- Lao numerals (໐-໙) mixed with Arabic digits
- Fonts vary widely on shop bills; many receipts are thermal-printed and faded

## Unicode
- Lao block: U+0E80-U+0EFF
- Always store as UTF-8; use NFC normalization
```python
import unicodedata
clean = unicodedata.normalize("NFC", text)
```
- Convert Lao digits:
```python
LAO_DIGITS = str.maketrans("໐໑໒໓໔໕໖໗໘໙", "0123456789")
text = text.translate(LAO_DIGITS)
```

## Currency and Number Patterns
- Currency: ກີບ, LAK, ₭, THB, USD
- Total keywords: ລວມ, ລວມທັງໝົດ, ຍອດລວມ, Total
- Date keywords: ວັນທີ, Date
- Keep a keyword dictionary and verify with a native speaker

## Dataset Collection Plan
1. Collect 200+ real bills (with owner permission; remove personal data)
2. Label vendor, date, total, items (tools: Label Studio, CVAT)
3. Split 70/15/15 train/val/test
4. Include variety: thermal receipts, printed invoices, handwritten, phone photos in poor light

## Improving Accuracy
- Upscale to ~300 DPI equivalent
- Remove shadows (background subtraction)
- Use Lao-friendly fonts for any rendered text
- Post-correct with a Lao dictionary / word list
- Fine-tune Tesseract (tesstrain) or PaddleOCR recognition model on your labeled data
- Use vision LLM fallback for hard cases

## UI Localization
- Provide Lao + English UI (i18next)
- Use Noto Sans Lao font in web UI and Excel output

## Excel Notes
- Set a Lao-capable font (e.g., Noto Sans Lao, Phetsarath OT) so text renders correctly
- Save with UTF-8 BOM for CSV so Excel reads Lao properly
