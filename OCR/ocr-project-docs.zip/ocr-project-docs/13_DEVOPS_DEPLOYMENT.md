# 13 - DevOps, CI/CD and Deployment

## docker-compose.yml (dev/staging)
```yaml
services:
  api:
    build: ./backend
    env_file: .env
    ports: ["8000:8000"]
    depends_on: [db, redis, minio]
  worker:
    build: ./backend
    command: celery -A app.workers.tasks worker -l info -c 2
    env_file: .env
    depends_on: [redis, db]
  db:
    image: postgres:16
    environment: {POSTGRES_USER: user, POSTGRES_PASSWORD: pass, POSTGRES_DB: ocr}
    volumes: [pgdata:/var/lib/postgresql/data]
  redis:
    image: redis:7
  minio:
    image: minio/minio
    command: server /data --console-address ":9001"
    volumes: [miniodata:/data]
  web:
    build: ./frontend
    ports: ["5173:80"]
volumes: {pgdata: {}, miniodata: {}}
```

## Backend Dockerfile
```dockerfile
FROM python:3.11-slim
RUN apt-get update && apt-get install -y tesseract-ocr tesseract-ocr-lao tesseract-ocr-eng \
    poppler-utils libgl1 && rm -rf /var/lib/apt/lists/*
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
RUN useradd -m appuser
USER appuser
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## GitHub Actions CI (.github/workflows/ci.yml)
```yaml
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: {python-version: "3.11"}
      - run: sudo apt-get install -y tesseract-ocr tesseract-ocr-lao poppler-utils
      - run: pip install -r backend/requirements.txt bandit pip-audit pytest-cov
      - run: bandit -r backend/app
      - run: pip-audit -r backend/requirements.txt
      - run: pytest backend/tests --cov=backend/app --cov-fail-under=80
```

## Environments
| Env | Purpose | Data |
|---|---|---|
| Dev | Local | Synthetic |
| Staging | QA/UAT | Anonymized samples |
| Production | Users | Real, encrypted |

## Hosting Options
| Option | Cost | Notes |
|---|---|---|
| Single VPS (Hetzner, DigitalOcean) + Docker | Low | Good MVP |
| Render / Railway / Fly.io | Low-Med | Easy deploy |
| AWS/GCP/Azure | Med-High | Managed services, scale |

## Production Checklist
- [ ] HTTPS via Let's Encrypt (Caddy/Nginx)
- [ ] Env secrets set, debug off
- [ ] DB backups daily + restore tested
- [ ] Rate limiting and security headers on
- [ ] Monitoring: Sentry (errors), Prometheus/Grafana or Uptime Kuma
- [ ] Log rotation, no PII in logs
- [ ] Autoscale workers by queue length
- [ ] Rollback plan (previous image tag)

## Release Process
1. Merge to `develop` -> auto-deploy staging
2. Run E2E + UAT
3. Tag `vX.Y.Z` -> deploy production (blue/green or rolling)
4. Smoke test, monitor 30 min

## Cost Control
Cache results by file hash, use local OCR first, LLM only as fallback, set monthly budget alerts.
