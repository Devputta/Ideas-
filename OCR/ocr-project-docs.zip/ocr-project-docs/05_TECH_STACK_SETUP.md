# 05 - Tech Stack and Setup

## Recommended Stack
| Layer | Choice | Why |
|---|---|---|
| Frontend | React + Vite + Tailwind | Fast, popular |
| Backend | Python FastAPI | Best OCR/ML ecosystem |
| OCR | PaddleOCR, Tesseract (lao+eng) | Free; benchmark both |
| Vision LLM (optional) | Claude / Gemini / GPT vision | Strong on messy layouts and Lao |
| Preprocessing | OpenCV, Pillow | Standard |
| PDF handling | pdf2image / PyMuPDF | PDF to image |
| Excel | openpyxl, pandas | Reliable |
| DB | PostgreSQL (SQLite for dev) | Robust |
| Queue | Redis + Celery | Simple async |
| Storage | MinIO (S3 compatible) | Self-hostable |
| Auth | JWT + bcrypt/argon2 | Standard |
| Container | Docker + docker-compose | Reproducible |

## Folder Structure
```
ocr-bill-app/
  backend/
    app/
      main.py
      api/ (routes)
      core/ (config, security)
      models/ (SQLAlchemy)
      schemas/ (Pydantic)
      services/
        preprocess.py
        ocr_engine.py
        extractor.py
        excel_export.py
      workers/tasks.py
    tests/
    requirements.txt
  frontend/
    src/ (components, pages, api)
  docs/
  docker-compose.yml
  .env.example
```

## Local Setup
```bash
# system deps (Ubuntu)
sudo apt install tesseract-ocr tesseract-ocr-lao tesseract-ocr-eng poppler-utils

# backend
cd backend
python -m venv venv && source venv/bin/activate
pip install fastapi uvicorn[standard] python-multipart sqlalchemy psycopg2-binary \
  celery redis opencv-python pillow pytesseract paddleocr paddlepaddle \
  pdf2image openpyxl pandas pydantic-settings passlib[argon2] python-jose pytest
uvicorn app.main:app --reload

# frontend
cd frontend && npm create vite@latest . -- --template react && npm install && npm run dev
```

## Environment Variables (.env.example)
```
DATABASE_URL=postgresql://user:pass@db:5432/ocr
REDIS_URL=redis://redis:6379/0
SECRET_KEY=change-me-use-long-random-value
S3_ENDPOINT=http://minio:9000
S3_ACCESS_KEY=...
S3_SECRET_KEY=...
LLM_API_KEY=...
MAX_UPLOAD_MB=10
ALLOWED_ORIGINS=http://localhost:5173
```

## Hardware Notes
- CPU-only is fine for Tesseract and PaddleOCR on low volume.
- GPU recommended only for heavy PaddleOCR / local VLM usage.
