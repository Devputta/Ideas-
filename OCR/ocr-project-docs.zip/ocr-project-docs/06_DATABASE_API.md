# 06 - Database Schema and API Design

## Tables
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY, email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL, role TEXT DEFAULT 'user',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE documents (
  id UUID PRIMARY KEY, user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  original_filename TEXT, storage_key TEXT NOT NULL, mime_type TEXT,
  doc_type TEXT DEFAULT 'bill',          -- bill | poster
  language TEXT DEFAULT 'lao+eng',
  status TEXT DEFAULT 'uploaded',
  error_message TEXT, created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE extractions (
  id UUID PRIMARY KEY, document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
  raw_text TEXT, vendor TEXT, invoice_no TEXT, invoice_date DATE,
  currency TEXT, subtotal NUMERIC(14,2), tax NUMERIC(14,2), total NUMERIC(14,2),
  confidence NUMERIC(4,3), approved BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE line_items (
  id UUID PRIMARY KEY, extraction_id UUID REFERENCES extractions(id) ON DELETE CASCADE,
  description TEXT, quantity NUMERIC(12,3), unit_price NUMERIC(14,2),
  amount NUMERIC(14,2), confidence NUMERIC(4,3)
);

CREATE TABLE audit_log (
  id BIGSERIAL PRIMARY KEY, user_id UUID, action TEXT, entity TEXT,
  entity_id UUID, ip INET, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX ON documents(user_id, created_at DESC);
```

## REST API (prefix `/api/v1`)
| Method | Path | Description |
|---|---|---|
| POST | /auth/register | Create account |
| POST | /auth/login | Returns JWT (access + refresh) |
| POST | /documents | Upload file(s), returns ids |
| GET | /documents | List own documents (paginated) |
| GET | /documents/{id} | Status + extraction |
| PUT | /documents/{id}/extraction | Save user corrections |
| POST | /documents/{id}/approve | Approve |
| GET | /documents/{id}/export?format=xlsx | Download Excel/CSV |
| POST | /documents/export | Bulk export (ids in body) |
| DELETE | /documents/{id} | Delete file and data |

## Example Response: GET /documents/{id}
```json
{
  "id": "uuid", "status": "review",
  "extraction": {
    "vendor": "ຮ້ານ ສະບາຍດີ", "invoice_date": "2026-10-20",
    "currency": "LAK", "total": 245000,
    "line_items": [
      {"description": "Coffee", "quantity": 2, "unit_price": 25000, "amount": 50000}
    ],
    "confidence": 0.87
  }
}
```

## Error Format
```json
{"error": {"code": "FILE_TOO_LARGE", "message": "Max 10 MB", "request_id": "..."}}
```

## Excel Layout
- Sheet "Summary": one row per document (file, vendor, date, currency, total)
- Sheet "Items": one row per line item with document reference
- Sheet "Raw Text": OCR text for audit
