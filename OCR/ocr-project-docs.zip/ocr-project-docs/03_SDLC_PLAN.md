# 03 - SDLC Plan (Software Development Life Cycle)

Model: **Agile (Scrum-lite), 2-week sprints**, suitable for a solo developer or small team.

## Phase 1 - Planning
- Define goals, scope, budget, risks
- Output: Project overview, roadmap (docs 01, 14)

## Phase 2 - Requirements Analysis
- Gather sample bills (50-200, Lao + English)
- Write SRS and user stories (doc 02)
- Output: Backlog with priorities (MoSCoW)

## Phase 3 - Design
- Architecture, DB schema, API contract, UI wireframes (docs 04, 06)
- Threat modeling (doc 11)
- Output: Design docs, wireframes

## Phase 4 - Implementation
- Feature branches, code review, conventional commits
- Output: Working increments each sprint

## Phase 5 - Testing (STLC runs in parallel, see doc 09)
- Unit, integration, system, security, UAT

## Phase 6 - Deployment
- CI/CD pipeline, staging then production (doc 13)

## Phase 7 - Maintenance
- Monitor errors, collect user corrections, retrain/tune OCR, patch dependencies

## Sprint Plan (MVP, 8 weeks)
| Sprint | Goal | Deliverables |
|---|---|---|
| 0 (week 0) | Setup | Repo, CI, sample dataset, OCR benchmark |
| 1 (wk 1-2) | Upload + preprocessing | Upload API, OpenCV pipeline |
| 2 (wk 3-4) | OCR + extraction | Lao/English OCR, LLM/regex extraction |
| 3 (wk 5-6) | Review UI + Excel export | React UI, openpyxl export |
| 4 (wk 7-8) | Hardening | Security, tests, deployment, UAT |

## Git Workflow
- `main` (production), `develop` (integration), `feature/*`, `hotfix/*`
- PRs require 1 review + passing CI

## Definition of Done
- Code reviewed, tests written and passing, docs updated, no high security findings, deployed to staging.

## Risk Register
| Risk | Impact | Mitigation |
|---|---|---|
| Poor Lao OCR accuracy | High | Benchmark multiple engines; LLM vision fallback; review UI |
| Low-quality photos | Med | Preprocessing, capture guidance in UI |
| Data privacy leak | High | Encryption, retention limits (doc 11) |
| API cost overrun | Med | Caching, rate limits, local OCR first |
| Scope creep | Med | Strict MVP, backlog grooming |
