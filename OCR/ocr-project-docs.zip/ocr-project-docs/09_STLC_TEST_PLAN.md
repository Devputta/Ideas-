# 09 - STLC (Software Testing Life Cycle) and Test Plan

## STLC Phases
| Phase | Entry | Activities | Exit / Output |
|---|---|---|---|
| 1. Requirement Analysis | SRS approved | Identify testable requirements, define OCR accuracy targets | RTM (traceability matrix) |
| 2. Test Planning | Requirements clear | Scope, strategy, tools, schedule, risks, effort | This test plan |
| 3. Test Case Development | Plan approved | Write cases, prepare dataset and test data | Test cases (doc 10), golden dataset |
| 4. Test Environment Setup | Build available | Docker staging, seeded DB, mock services | Ready environment, smoke test passed |
| 5. Test Execution | Env ready | Run tests, log defects, retest | Execution report, bug list |
| 6. Test Closure | Exit criteria met | Metrics, lessons learned, sign-off | Closure report |

## Test Levels
- **Unit**: preprocessing functions, parsers, validators (pytest, Jest)
- **Integration**: API <-> DB <-> queue <-> storage
- **System / E2E**: upload to Excel download (Playwright/Cypress)
- **OCR accuracy testing**: golden dataset, CER/WER, field accuracy
- **Performance**: Locust/k6 (50 concurrent users)
- **Security**: SAST, DAST, dependency scan (doc 11)
- **Usability / UAT**: real users with real bills
- **Regression**: automated suite on every PR

## Test Types
Functional, non-functional, compatibility (Chrome/Firefox/Safari, Android/iOS), accessibility, localization (Lao rendering), recovery/failure.

## Tools
| Purpose | Tool |
|---|---|
| Unit (Py) | pytest, pytest-cov |
| Unit (JS) | Vitest/Jest |
| E2E | Playwright |
| API | Postman/Newman, pytest + httpx |
| Load | Locust or k6 |
| SAST | Bandit, Semgrep |
| Dependency scan | pip-audit, npm audit, Trivy |
| DAST | OWASP ZAP |
| Bug tracking | GitHub Issues / Jira |

## Entry Criteria
Build deployed to staging, smoke tests pass, test data ready.

## Exit Criteria
- 100% critical and high test cases executed
- 0 open critical/high defects
- >= 80% unit coverage on core services
- OCR field accuracy meets targets (>= 90% clean, >= 80% phone photos)
- Security scan: no high/critical findings

## Defect Severity
| Level | Definition | SLA |
|---|---|---|
| S1 Critical | Data loss, security breach, system down | Fix < 24h |
| S2 High | Core feature broken, wrong totals exported | < 3 days |
| S3 Medium | Feature partially broken, workaround exists | Next sprint |
| S4 Low | Cosmetic | Backlog |

## Defect Lifecycle
New -> Assigned -> In Progress -> Fixed -> Retest -> Closed (or Reopened)

## Requirements Traceability (sample)
| Req | Test cases |
|---|---|
| FR-01 | TC-UP-01..06 |
| FR-03 | TC-OCR-01..08 |
| FR-04 | TC-EXT-01..06 |
| FR-06 | TC-EXP-01..04 |

## Test Data
- Golden set: 100+ labeled bills (clean, blurry, rotated, dark, thermal faded, Lao-only, mixed, English-only)
- Edge: empty page, rotated 180, multi-page PDF, huge file, corrupted file, non-bill image

## CI Pipeline Testing Gates
lint -> unit -> SAST -> build -> integration -> E2E (staging) -> dependency scan -> deploy
