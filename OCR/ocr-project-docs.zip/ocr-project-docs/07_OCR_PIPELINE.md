# 07 - OCR Pipeline

## Stages
1. **Ingest**: PDF -> images (300 DPI); fix EXIF rotation
2. **Preprocess**: grayscale, denoise, deskew, perspective correction, adaptive threshold, upscale small text
3. **Layout detection**: find text regions, tables, header/footer
4. **OCR**: run engine(s), get text + boxes + confidence
5. **Extraction**: rules/regex and/or LLM -> structured JSON
6. **Validation**: arithmetic and format checks
7. **Review**: user corrections -> saved as training/eval data

## Preprocessing Code (OpenCV)
```python
import cv2, numpy as np

def preprocess(path):
    img = cv2.imread(path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
    # deskew
    coords = np.column_stack(np.where(gray < 200))
    angle = cv2.minAreaRect(coords)[-1]
    angle = -(90 + angle) if angle < -45 else -angle
    h, w = gray.shape
    M = cv2.getRotationMatrix2D((w//2, h//2), angle, 1.0)
    gray = cv2.warpAffine(gray, M, (w, h), flags=cv2.INTER_CUBIC,
                          borderMode=cv2.BORDER_REPLICATE)
    return cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                 cv2.THRESH_BINARY, 31, 15)
```

## Engine Comparison (benchmark on YOUR data)
| Engine | Lao | Cost | Notes |
|---|---|---|---|
| Tesseract (lao) | Fair | Free | Needs clean input; use `--psm 6` for receipts |
| PaddleOCR | Limited/needs check | Free | Strong layout; verify Lao model availability |
| Google Vision / Document AI | Good | Paid | Strong baseline |
| Vision LLM | Good-Very good | Paid per call | Best on messy layouts; always verify |
| Custom fine-tuned model | Best potential | Dev effort | Needs labeled Lao data |

## Recommended Strategy: Hybrid
1. Run local OCR first (cheap).
2. If confidence < threshold or validation fails -> fallback to vision LLM.
3. User corrections feed an evaluation set (and later fine-tuning).

## Tesseract Example
```python
import pytesseract
text = pytesseract.image_to_string(img, lang="lao+eng", config="--oem 1 --psm 6")
data = pytesseract.image_to_data(img, lang="lao+eng", output_type=pytesseract.Output.DICT)
```

## Validation Rules
- sum(line amounts) ~= subtotal (tolerance 1%)
- subtotal + tax ~= total
- date within plausible range, parsed in multiple formats (DD/MM/YYYY common in Laos)
- currency in {LAK, THB, USD}; numbers use `,` thousands separators
- Flag fields failing checks as `needs_review`

## Posters (Phase 2)
- Use text detection (PaddleOCR/EAST) for scattered text
- Output fields: title, date/time, venue, contact, URLs, free text blocks
- Vision LLM preferred for decorative fonts

## Evaluation Metrics
- Character Error Rate (CER), Word Error Rate (WER)
- Field-level accuracy (exact match for vendor/date/total)
- Line-item F1
- End-to-end latency, cost per document
