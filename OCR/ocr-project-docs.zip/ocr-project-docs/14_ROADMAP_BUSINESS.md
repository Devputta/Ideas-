# 14 - Roadmap, Business and Portfolio Plan

## Roadmap
| Phase | Timeline | Scope |
|---|---|---|
| MVP | Weeks 1-8 | Upload, Lao+English OCR, extraction, review, Excel export |
| v1.0 | Months 3-4 | Accounts, history, batch upload, expense categories, dashboard |
| v1.5 | Months 5-6 | Poster extraction, API keys, mobile-friendly camera capture |
| v2.0 | Months 7-12 | Fine-tuned Lao model, accounting export (QuickBooks/CSV), team workspaces, mobile app |

## Competitive Landscape
Google Document AI, AWS Textract, Azure Document Intelligence, Veryfi, Nanonets, Mindee.
**Your edge:** Lao-first accuracy, LAK/local formats, Lao UI, local pricing, local support.

## Pricing Ideas
| Plan | Price | Limits |
|---|---|---|
| Free | $0 | 20 pages / month |
| Starter | ~$5 / month | 300 pages |
| Business | ~$20 / month | 2,000 pages, API, team |
| Pay-as-you-go | per page | For accountants |
(Adjust to local purchasing power; accept local payment methods.)

## Unit Economics (estimate carefully)
- Local OCR cost per page ~ near zero (server only)
- LLM fallback cost per page: check current provider pricing
- Target gross margin > 70%

## Go-To-Market
1. Pilot with 5-10 local shops/accountants (free, gather feedback + data)
2. Facebook/WhatsApp groups, local business communities
3. Partner with accounting firms
4. Offer onboarding in Lao

## Portfolio Presentation Tips
- Public GitHub repo with clean README, architecture diagram, demo GIF
- Live demo link + sample bills
- Publish accuracy benchmark table (Tesseract vs PaddleOCR vs LLM)
- Include docs from this pack (SDLC, STLC, security) to show engineering maturity
- Write a short blog post: "Building Lao OCR for bills"

## KPIs
Activation (first successful export), field accuracy, correction rate, weekly active users, cost per page, churn.

## Risks and Mitigation
| Risk | Mitigation |
|---|---|
| Accuracy not good enough | Review UI, hybrid OCR, collect corrections |
| Privacy concerns | Clear policy, deletion, local processing option |
| Competitors add Lao | Move fast, niche features, local relationships |
| Small market | Expand to Thai/Khmer/Vietnamese-adjacent markets later |

## Legal Notes (not legal advice)
Check local data-protection rules, terms of service, privacy policy, and consent for using user data to improve models. Consult a lawyer before launching commercially.
