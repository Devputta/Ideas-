# 04 - Architecture and Design

## High-Level Architecture
```
[Browser / React UI]
        |  HTTPS
        v
[Nginx / Reverse Proxy] --> [FastAPI Backend] --> [PostgreSQL]
                                  |                    
                                  v                    
                           [Redis Queue] --> [OCR Workers (Celery)]
                                                  |
                         +------------------------+-----------------+
                         v                        v                 v
                  [OpenCV preprocess]   [OCR engine(s)]     [LLM extractor]
                                                  |
                                                  v
                                       [Object Storage: S3/MinIO]
```

## Components
| Component | Responsibility |
|---|---|
| Frontend (React) | Upload, progress, review/edit table, download |
| API (FastAPI) | Auth, validation, job creation, results, export |
| Queue (Redis + Celery) | Async processing so uploads do not block |
| Worker | Preprocess -> OCR -> extract -> save |
| DB (PostgreSQL) | Users, documents, extracted fields, audit log |
| Storage (S3/MinIO) | Original and processed files (encrypted) |
| Export service | Build .xlsx/.csv with openpyxl/pandas |

## Processing Flow
1. User uploads file -> API validates type/size, stores file, creates `document` row (status=queued)
2. API enqueues job, returns `document_id`
3. Worker preprocesses image, runs OCR, extracts fields
4. Worker saves results (status=review)
5. UI polls (or WebSocket) and shows review screen
6. User confirms -> status=approved -> export available

## Design Principles
- Stateless API, async workers
- OCR engine behind an interface (swap Tesseract / PaddleOCR / cloud / LLM)
- Every extracted field stores a confidence score
- Original file never modified; processed copy stored separately

## OCR Engine Interface (Python)
```python
class OCREngine(Protocol):
    def extract(self, image_path: str, langs: list[str]) -> OCRResult: ...
```

## Document Status State Machine
`uploaded -> queued -> processing -> review -> approved -> exported`
Failure path: `processing -> failed` (with error reason and retry count)

## UI Wireframe Notes
1. **Upload page**: drag-drop, camera capture on mobile, language selector
2. **Processing**: progress indicator
3. **Review page**: image on left with highlighted boxes, editable table on right
4. **History**: list, filter by date/vendor, bulk export
