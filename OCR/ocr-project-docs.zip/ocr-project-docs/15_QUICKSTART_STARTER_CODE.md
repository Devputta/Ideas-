# 15 - Quickstart and Starter Code

A minimal working backend prototype: upload image -> OCR -> extract -> Excel.

## 1. Install
```bash
sudo apt install tesseract-ocr tesseract-ocr-lao tesseract-ocr-eng
pip install fastapi uvicorn python-multipart pytesseract pillow opencv-python openpyxl python-magic
```

## 2. app.py
```python
import io, re, uuid, unicodedata
import cv2, numpy as np, pytesseract, magic
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
from openpyxl import Workbook
from PIL import Image

Image.MAX_IMAGE_PIXELS = 50_000_000  # decompression-bomb guard
app = FastAPI(title="Bill OCR MVP")

ALLOWED = {"image/jpeg", "image/png"}
MAX_BYTES = 10 * 1024 * 1024
LAO_DIGITS = str.maketrans("໐໑໒໓໔໕໖໗໘໙", "0123456789")

def preprocess(data: bytes):
    arr = np.frombuffer(data, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise HTTPException(400, "Invalid image")
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
    return cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                 cv2.THRESH_BINARY, 31, 15)

def ocr(img) -> str:
    text = pytesseract.image_to_string(img, lang="lao+eng", config="--oem 1 --psm 6")
    return unicodedata.normalize("NFC", text).translate(LAO_DIGITS)

def extract(text: str) -> dict:
    date = re.search(r"(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2})", text)
    amounts = [float(a.replace(",", "")) for a in re.findall(r"\d[\d,]*\.?\d*", text)
               if len(a.replace(",", "")) >= 3]
    total_line = re.search(r"(?:total|ລວມ|ຍອດ)[^\d]*([\d,]+\.?\d*)", text, re.I)
    total = float(total_line.group(1).replace(",", "")) if total_line else (max(amounts) if amounts else None)
    return {"date": date.group(1) if date else None, "total": total,
            "vendor": text.strip().split("\n")[0][:80] if text.strip() else None}

def safe_cell(v):
    s = "" if v is None else str(v)
    return "'" + s if s[:1] in ("=", "+", "-", "@") else s

@app.post("/extract")
async def extract_bill(file: UploadFile = File(...)):
    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "File too large")
    if magic.from_buffer(data, mime=True) not in ALLOWED:
        raise HTTPException(400, "Only JPG/PNG allowed")
    text = ocr(preprocess(data))
    return {"id": str(uuid.uuid4()), "fields": extract(text), "raw_text": text}

@app.post("/export")
async def export_excel(file: UploadFile = File(...)):
    data = await file.read()
    if len(data) > MAX_BYTES or magic.from_buffer(data, mime=True) not in ALLOWED:
        raise HTTPException(400, "Invalid file")
    text = ocr(preprocess(data))
    f = extract(text)
    wb = Workbook(); ws = wb.active; ws.title = "Summary"
    ws.append(["Vendor", "Date", "Total"])
    ws.append([safe_cell(f["vendor"]), safe_cell(f["date"]), f["total"]])
    raw = wb.create_sheet("Raw Text")
    for line in text.splitlines():
        raw.append([safe_cell(line)])
    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return StreamingResponse(buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=bill.xlsx"})
```

## 3. Run and Test
```bash
uvicorn app:app --reload
curl -F "file=@bill.jpg" http://127.0.0.1:8000/extract
curl -F "file=@bill.jpg" http://127.0.0.1:8000/export -o bill.xlsx
```

## 4. Minimal React Upload Snippet
```jsx
function Upload() {
  const send = async (e) => {
    const fd = new FormData(); fd.append("file", e.target.files[0]);
    const r = await fetch("http://127.0.0.1:8000/export", {method: "POST", body: fd});
    const url = URL.createObjectURL(await r.blob());
    Object.assign(document.createElement("a"), {href: url, download: "bill.xlsx"}).click();
  };
  return <input type="file" accept="image/*" capture="environment" onChange={send} />;
}
```

## 5. Next Steps (in order)
1. Collect 50 sample bills, benchmark engines (doc 07)
2. Replace regex with vision-LLM extraction (doc 12, A1)
3. Add DB + auth + review screen (docs 04, 06)
4. Add tests (docs 09, 10) and security controls (doc 11)
5. Dockerize and deploy (doc 13)

## Troubleshooting
| Problem | Fix |
|---|---|
| `lao.traineddata` not found | `sudo apt install tesseract-ocr-lao` |
| Lao shows as boxes in Excel | Set font to Noto Sans Lao / Phetsarath OT |
| Poor accuracy on photos | Add deskew/perspective correction; use LLM fallback |
| `magic` import error | `sudo apt install libmagic1` |
