# 02 - Software Requirements Specification (SRS)

## 1. Functional Requirements
| ID | Requirement | Priority |
|---|---|---|
| FR-01 | User can upload JPG/PNG/PDF up to 10 MB | Must |
| FR-02 | System preprocesses image (rotate, deskew, denoise) | Must |
| FR-03 | System extracts text in Lao and English | Must |
| FR-04 | System extracts structured fields (vendor, date, items, totals) | Must |
| FR-05 | User can review and edit extracted data | Must |
| FR-06 | User can export to .xlsx and .csv | Must |
| FR-07 | User can upload multiple files (batch) | Should |
| FR-08 | User registration/login | Should |
| FR-09 | History of past uploads | Should |
| FR-10 | Expense category auto-tagging | Could |
| FR-11 | Poster text extraction | Could |
| FR-12 | REST API with API keys | Could |

## 2. Non-Functional Requirements
| ID | Requirement |
|---|---|
| NFR-01 | Performance: < 10 s per single-page image |
| NFR-02 | Availability: 99% for MVP |
| NFR-03 | Security: HTTPS, encrypted storage, OWASP Top 10 compliant |
| NFR-04 | Usability: works on mobile browsers |
| NFR-05 | Scalability: queue-based workers, horizontally scalable |
| NFR-06 | Accessibility: WCAG 2.1 AA basics |
| NFR-07 | Localization: Lao and English UI |
| NFR-08 | Privacy: user can delete files and data at any time |

## 3. User Stories
- As a shop owner, I upload a receipt so I don't type it manually.
- As an accountant, I upload 50 bills and download one Excel file.
- As a user, I fix a wrong total before exporting.
- As a user, I delete my data permanently.

## 4. Acceptance Criteria (example, FR-04)
- Given a clear Lao/English receipt, when processed, then vendor, date, and total are correctly extracted in >= 90% of test samples.

## 5. Constraints and Assumptions
- Limited budget: prefer open-source OCR first.
- Lao training data is scarce; the team must collect sample bills.
- Users may photograph bills with phones.

## 6. Out of Scope (MVP)
Handwriting recognition, real-time video OCR, accounting integrations.
