# 10 - Test Cases

## Upload (FR-01)
| ID | Scenario | Steps | Expected |
|---|---|---|---|
| TC-UP-01 | Valid JPG | Upload 2 MB jpg | 201, status queued |
| TC-UP-02 | Valid PDF | Upload 3-page PDF | Pages processed |
| TC-UP-03 | Oversize | Upload 25 MB | 413 FILE_TOO_LARGE |
| TC-UP-04 | Wrong type | Upload .exe renamed .jpg | Rejected (magic-byte check) |
| TC-UP-05 | Corrupted image | Upload truncated file | status failed, clear message |
| TC-UP-06 | Unauthenticated | No token | 401 |

## Preprocessing / OCR (FR-02, FR-03)
| ID | Scenario | Expected |
|---|---|---|
| TC-OCR-01 | Clean English receipt | CER < 3% |
| TC-OCR-02 | Clean Lao receipt | CER < 10% |
| TC-OCR-03 | Mixed Lao + English | Both scripts captured |
| TC-OCR-04 | Rotated 15 degrees | Deskewed, accuracy within 5% of upright |
| TC-OCR-05 | Rotated 180 degrees | Auto-corrected |
| TC-OCR-06 | Low light / shadow | Field accuracy >= 80% |
| TC-OCR-07 | Faded thermal paper | Fallback triggered |
| TC-OCR-08 | Lao digits | Converted to Arabic digits |

## Extraction (FR-04)
| ID | Scenario | Expected |
|---|---|---|
| TC-EXT-01 | Total detection | Matches printed total |
| TC-EXT-02 | Date formats | DD/MM/YYYY, YYYY-MM-DD, Lao month names parsed |
| TC-EXT-03 | Multiple line items | All items, qty, price extracted |
| TC-EXT-04 | Math validation | Mismatched sum flagged needs_review |
| TC-EXT-05 | Currency LAK/THB/USD | Correct code |
| TC-EXT-06 | Not a bill (photo of cat) | Returns "no bill detected", no crash |

## Review and Export (FR-05, FR-06)
| ID | Scenario | Expected |
|---|---|---|
| TC-EXP-01 | Edit total then export | Excel shows edited value |
| TC-EXP-02 | Lao text in Excel | Renders correctly, UTF-8 |
| TC-EXP-03 | Bulk export 50 docs | One workbook, 50 summary rows |
| TC-EXP-04 | Formula injection | Cell `=cmd|...` is escaped (prefixed with `'`) |

## Security
| ID | Scenario | Expected |
|---|---|---|
| TC-SEC-01 | Access another user's document | 403/404 |
| TC-SEC-02 | SQL injection in search | No error leak, no injection |
| TC-SEC-03 | XSS in vendor name `<script>` | Escaped on render |
| TC-SEC-04 | Brute-force login | Rate-limited / lockout |
| TC-SEC-05 | Expired JWT | 401 |
| TC-SEC-06 | Path traversal filename `../../etc/passwd` | Sanitized |
| TC-SEC-07 | Decompression bomb image | Rejected by pixel limit |
| TC-SEC-08 | Delete account | All files and data removed |

## Performance
| ID | Scenario | Expected |
|---|---|---|
| TC-PERF-01 | Single image | < 10 s |
| TC-PERF-02 | 50 concurrent uploads | No failures, queue drains |
| TC-PERF-03 | 100-page batch | Completes without memory leak |

## Automation Example (pytest)
```python
def test_upload_rejects_fake_image(client, auth_headers):
    r = client.post("/api/v1/documents",
                    files={"file": ("a.jpg", b"MZ\x90\x00fake", "image/jpeg")},
                    headers=auth_headers)
    assert r.status_code == 400
```

## Bug Report Template
```
Title:
Environment:
Steps to reproduce:
Expected:
Actual:
Severity/Priority:
Attachments (screenshot, sample file):
```
