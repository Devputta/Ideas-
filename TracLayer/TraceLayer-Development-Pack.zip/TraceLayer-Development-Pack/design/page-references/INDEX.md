# TraceLayer Page Reference Index

All PNGs are 1440 × 900 design reference images using the same graphite/amber design system.

| Image | Page | Primary implementation focus |
|---|---|---|
| `01-overview.png` | Overview | Empty states, recent activity, quick actions |
| `02-request-lab.png` | Request Lab | Request editor, tabs, execution and response panel |
| `03-collections.png` | Collections | Collection navigation and saved request list |
| `04-history.png` | History | Filters, execution table and empty state |
| `05-execution-detail.png` | Execution Detail | Recorded request/response evidence |
| `06-failure-capsules.png` | Failure Capsules | Search, tags, import and capsule list |
| `07-capsule-detail.png` | Capsule Detail | Sanitized request, response evidence and safe replay |
| `08-compare.png` | Compare | Two-run comparison and changed-path summary |
| `09-assertions.png` | Assertions | Reusable checks and results |
| `10-settings.png` | Settings | Retention, redaction, access and appearance |
| `11-authentication.png` | Authentication | Sign-in form and secure-session notes |

The page images show planned layout and sample empty states. They are not evidence that the product has been implemented.
