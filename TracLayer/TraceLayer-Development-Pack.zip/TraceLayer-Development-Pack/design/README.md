# Page Reference Images

The PNGs in `page-references/` are custom-built visual references for implementing TraceLayer's main screens. They are not screenshots of a working application and they do not represent existing functionality.

Use them to reproduce:
- page hierarchy and layout
- navigation and panel proportions
- component density
- typography and restrained accent usage
- request/response workspace structure

Use the page specifications and design system for behavior, validation, and responsive details. Implement the actual application separately.
