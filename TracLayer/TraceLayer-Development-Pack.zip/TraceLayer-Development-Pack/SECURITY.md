# Security Policy

## Supported versions

Until the first stable release, security fixes are developed against the latest main branch. Published releases should list supported versions here.

## Reporting a vulnerability

Do not publish exploit details or sensitive data in a public issue. Contact the project maintainer through a private channel listed in the repository profile, and include:
- A concise impact description.
- Reproduction steps in a safe test environment.
- Affected version or commit.
- Suggested mitigation, if known.

Do not test against systems you do not own or have permission to assess.

## Security priorities

- SSRF and outbound network restrictions.
- Authentication and authorization bypass.
- Secret leakage.
- Unsafe capsule import/replay.
- Denial of service and resource exhaustion.
- Dependency and deployment misconfiguration.

## Response process

Acknowledge reports, validate impact, prepare a fix, add regression tests, and publish remediation details after a fix is available. Do not include secrets or personal data in public advisories.
