# Contributing

## Before opening a change
- Read `docs/engineering-rules.md` and `SECURITY.md`.
- Check existing issues and avoid duplicating work.
- Keep changes focused and document behavior changes.

## Development workflow
1. Create a branch for one feature or fix.
2. Add or update tests.
3. Run formatting, linting, type checks, and relevant test suites.
4. Update documentation and page references if UI behavior changes.
5. Open a pull request describing behavior, security implications, and verification steps.

## UI contributions
Use the design tokens and shared components. Include empty, loading, success, and error states. Do not add fake metrics or nonfunctional controls.

## Security contributions
Do not include real credentials, production request bodies, or private target URLs in fixtures. Report vulnerabilities privately as described in `SECURITY.md`.
