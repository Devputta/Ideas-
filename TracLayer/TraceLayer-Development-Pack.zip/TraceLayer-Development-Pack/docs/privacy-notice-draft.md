# Privacy Notice — Draft

This is a drafting aid and is not legal advice. Review and adapt it to the actual deployed product, hosting providers, jurisdictions, and data practices before publication.

## Data processed
TraceLayer may process account information, workspace metadata, saved request definitions, execution metadata, response content, notes, and diagnostic logs depending on enabled features.

## Sensitive content
HTTP requests can contain credentials and personal information. TraceLayer should redact sensitive headers by default and minimize collection. Users should avoid sending sensitive production data unless the deployment's controls and policies have been reviewed.

## Purpose
Data is processed to execute user-requested HTTP requests, save history, reproduce failures, provide comparisons, and maintain service security.

## Retention and deletion
The deployed service must publish concrete retention periods and explain how users can export or delete their data. Do not publish this draft until these behaviors are implemented and verified.

## Third parties
List actual hosting, database, authentication, telemetry, and AI providers before release. Do not claim that no third party receives data unless that has been verified.

## Contact
Add a monitored privacy contact before release.
