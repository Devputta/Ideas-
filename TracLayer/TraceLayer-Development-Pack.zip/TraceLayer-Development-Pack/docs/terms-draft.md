# Terms of Use — Draft

This is a product-planning draft, not legal advice. It must be reviewed and adapted before public release.

## Authorized use
Use TraceLayer only to test systems you own or have explicit permission to assess.

## User responsibilities
Users are responsible for the destinations they request, the data they submit, and confirming that their use complies with applicable law and service agreements.

## Service limits
The deployed service should document execution quotas, response limits, retention, and supported protocols.

## No guarantee of remote behavior
Replaying a request may produce a different result because the remote service, data, network, or environment has changed.

## Security controls
Users must not attempt to bypass network restrictions, access internal infrastructure, or use the service to abuse third-party systems.

## Availability and changes
Describe the actual service availability and support policy before publication.

## Contact
Add a valid project contact before release.
