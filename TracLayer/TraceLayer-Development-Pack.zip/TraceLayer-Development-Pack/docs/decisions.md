# Architecture Decision Records

## ADR-001: Use a conventional client/API/database architecture
**Status:** Accepted for MVP.

**Context:** The product needs interactive request authoring, backend HTTP execution, persistent history, and authorization.

**Decision:** Use React + TypeScript, FastAPI + HTTPX, and PostgreSQL.

**Consequences:** Clear boundaries and a familiar stack; requires API contracts and deployment of separate services.

## ADR-002: Do not execute outbound requests directly from the browser
**Status:** Accepted.

**Context:** Browser networking has CORS restrictions and cannot reliably enforce server-side safety controls.

**Decision:** Route requests through a backend execution service with explicit egress restrictions.

**Consequences:** Enables persistence and policy enforcement, but creates SSRF and resource-exhaustion risks that must be mitigated.

## ADR-003: Failure Capsules are versioned, sanitized artifacts
**Status:** Accepted.

**Context:** Cases must be shareable without exposing credentials and must survive schema changes.

**Decision:** Use versioned JSON with schema validation and secret redaction. Import never executes a request automatically.

**Consequences:** Exports are portable; migrations and backward-compatibility policy are required.

## ADR-004: AI is optional and evidence-bound
**Status:** Accepted.

**Context:** AI can help interpret failures but can also hallucinate or receive sensitive content.

**Decision:** AI features are opt-in, use sanitized context, and are visually distinguished from verified execution results.

**Consequences:** The product remains useful without an AI provider and can communicate uncertainty honestly.
