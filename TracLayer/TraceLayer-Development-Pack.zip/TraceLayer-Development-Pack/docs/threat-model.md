# Threat Model

## Assets
- User identity and session data.
- Workspace contents and saved requests.
- API tokens and cookies entered by users.
- Captured request and response bodies.
- Capsule exports and execution history.
- Backend availability and outbound network access.

## Adversaries
- Unauthenticated internet users.
- A legitimate user attempting cross-workspace access.
- A user entering a malicious URL.
- A malicious or compromised remote API.
- A crafted imported capsule.
- An AI prompt-injection payload embedded in a response body.

## Principal threats and mitigations

| Threat | Mitigation |
|---|---|
| SSRF to cloud metadata or internal services | Strict egress allow/deny policy, DNS/IP validation, redirect checks, controlled networking |
| DNS rebinding | Pin validated destinations or route through an egress proxy |
| Cross-tenant access | Server-side workspace authorization and negative tests |
| Secret leakage in history | Default redaction, minimization, explicit opt-in for sensitive capture |
| Response memory exhaustion | Response-byte and decompression limits, deadlines |
| Malicious capsule import | Strict schema, size limit, no automatic execution |
| Unsafe replay of DELETE/POST | Confirmation, host/method preview, revalidation |
| Stored XSS in response viewer | Render response content as text; sanitize any supported rich rendering |
| AI prompt injection in API body | Treat body as untrusted data, isolate instructions, do not execute model recommendations |
| Log injection | Structured logs and field normalization |
| Brute force or execution abuse | Rate limits, quotas, concurrency limits |

## Residual risk

Network safety is difficult to guarantee with URL checks alone. Production deployment should enforce egress restrictions at infrastructure level, not rely exclusively on application validation.
