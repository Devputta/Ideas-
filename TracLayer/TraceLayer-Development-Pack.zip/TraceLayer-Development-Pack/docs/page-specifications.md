# Page Specifications

These requirements accompany the PNG page references in `design/page-references/`. The images are layout and styling references, not production screenshots.

## 1. Overview
Purpose: show useful entry points and recent real activity.
Components: workspace switcher, navigation, quick action, recent executions, recent capsules, request method/status summaries.
Rules: if there is no history, show an honest empty state. Never invent request counts, success rates, or uptime.

## 2. Request Lab
Purpose: author and execute one HTTP request.
Components: method selector, URL field, Send button, Params, Headers, Auth, Body tabs, response pane, status, duration, response headers/body.
Rules: show a clear pending state during execution. Disable duplicate submission or make concurrency explicit. Display network and validation errors without losing the draft.

## 3. Collections
Purpose: organize saved request definitions.
Components: collection list, request rows, create/rename/delete controls, method badges, search.
Rules: deleting a collection must explain whether requests will be deleted or moved. Empty state offers “Create collection.”

## 4. History
Purpose: inspect prior executions.
Components: filter bar, date range, method/status filters, table, pagination, detail link.
Rules: history contains real recorded executions only. Show retention limits when applicable.

## 5. Execution Detail
Purpose: inspect one execution record.
Components: request summary, response status, elapsed time, headers, body, assertions, “Create Failure Capsule” action.
Rules: redact secrets. Clearly indicate if body content was truncated.

## 6. Failure Capsules
Purpose: find saved debugging cases.
Components: search, status, tags, collection, updated time, create/import actions.
Rules: display capsule state and last replay result only when backed by stored records.

## 7. Capsule Detail
Purpose: understand and reproduce one failure.
Components: title, summary, sanitized request, recorded response, notes, assertions, replay action, export.
Rules: replay shows target host and method, checks network policy, and warns for potentially destructive methods.

## 8. Compare
Purpose: understand differences between two executions.
Components: left and right execution selectors, summary, JSON tree or text diff, changed-path list.
Rules: distinguish missing values from explicit null. Avoid claiming equivalence if bodies were truncated.

## 9. Assertions
Purpose: define reusable deterministic checks.
Components: assertion list, type selector, expected value, target JSON path, run result.
Rules: every result includes the actual value or a clear reason the assertion could not run.

## 10. Settings
Purpose: manage personal/workspace preferences and data safety.
Components: profile, workspace membership, retention, redaction, appearance, export/delete data.
Rules: security-sensitive changes require server-side authorization and clear confirmation.

## 11. Authentication
Purpose: sign in and establish a secure session.
Components: email, password or configured identity provider, validation, recovery link.
Rules: do not reveal whether an email is registered. Use secure, rate-limited authentication and generic errors.

## Shared UI states
- Loading skeletons only while data is actually loading.
- Empty states explain what action creates the first record.
- Error states provide a retry action when retry is safe.
- Toasts confirm completed actions, not merely clicked buttons.
- Tables remain usable on mobile through responsive columns or detail views.
