# Security Model

## Security objectives

- Prevent TraceLayer from becoming a server-side request forgery proxy.
- Prevent cross-workspace data exposure.
- Minimize secret collection, persistence, and export.
- Limit resource exhaustion from untrusted URLs and responses.
- Keep AI providers from receiving secrets or unrelated workspace data.

## Required controls

### Outbound request protection
- Permit only `http` and `https`.
- Reject URL user-info credentials and malformed URLs.
- Resolve DNS and reject private, loopback, link-local, multicast, reserved, and metadata-service addresses.
- Defend against DNS rebinding by connecting only to a validated destination or by using a controlled egress proxy.
- Revalidate every redirect target; safest MVP behavior is to disable redirects by default.
- Apply connection, read, write, and total deadlines.
- Limit response bytes, decompression expansion, header size, and concurrency.
- Deny internal network ranges by default.
- Keep local-machine access out of the hosted service. A future local agent must be an explicit separate trust model.

### Authentication and authorization
- Authenticate every private API route.
- Check workspace membership and role on every resource access.
- Use secure, HttpOnly, SameSite cookies if using cookie sessions; implement CSRF protection where applicable.
- Rate-limit login and expensive execution endpoints.
- Keep secrets in a managed secret store or encrypted credential vault if credential storage is added.

### Data protection
- Redact `Authorization`, `Proxy-Authorization`, `Cookie`, `Set-Cookie`, and configurable sensitive headers.
- Redact configured JSON paths and common secret patterns.
- Never include secrets in logs, exception messages, analytics, or AI prompts.
- Make retention and deletion behavior explicit.
- Encrypt traffic in transit and use managed database encryption at rest.

### Import/export
- Validate capsule schema, version, and size.
- Reject path traversal, unexpected fields, and unsupported serialization formats.
- Treat imported URL and body values as untrusted.
- Reapply all network checks when replaying imported cases.

### AI integration
- Off by default until configured.
- Send only the minimum sanitized context needed.
- Clearly label AI output as a suggestion.
- Do not let model output execute requests or modify saved data without explicit user action.

## Security acceptance tests

- Private IP and loopback destinations are blocked.
- Redirects to prohibited addresses are blocked.
- DNS resolution changes cannot bypass egress policy.
- Oversized responses stop at the configured limit.
- Workspace A cannot read Workspace B resources by changing IDs.
- Authorization and cookie values do not appear in stored history or logs.
- Malformed or oversized imported capsules are rejected.
