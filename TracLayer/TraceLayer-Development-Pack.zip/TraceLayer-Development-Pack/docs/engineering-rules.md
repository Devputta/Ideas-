# Engineering Rules

1. Do not fake functionality. A control must work or be explicitly disabled with an explanation.
2. Never present sample values as live execution results.
3. No secret values in source code, commits, screenshots, logs, exports, or AI prompts.
4. Every API route validates input and enforces authorization.
5. Every outbound request passes the same safety gate, including replay and redirects.
6. Use typed contracts and consistent error envelopes.
7. Database changes require migrations.
8. Keep components focused; do not build one giant page component.
9. Avoid unnecessary dependencies and abstractions.
10. Preserve existing working behavior when modifying code.
11. Add regression tests for bug fixes.
12. Handle loading, empty, validation, error, and success states.
13. Use accessible labels and keyboard focus states.
14. Keep responsive behavior intentional, not an afterthought.
15. Do not claim a build, test, deployment, or integration succeeded without verifying it.
16. Keep documentation aligned with the implemented product.
17. AI suggestions are not test results and are not automatically trusted.
18. Review dependencies and licenses before adding them.
