# Known Limitations and Open Questions

This document describes planned constraints, not verified behavior of an implemented application.

- The current archive contains specifications and page reference images only.
- Network policy needs infrastructure-level enforcement in addition to application validation.
- Exact behavior for cookies, OAuth, client certificates, and secret storage must be decided before supporting them.
- Request replay cannot guarantee identical results when the remote service, data, or environment has changed.
- Response comparisons can be misleading if either response is truncated; the UI must surface this condition.
- AI explanations can be incorrect and must not be presented as verified findings.
- Multi-user sharing, role management, and audit retention need explicit product decisions before a public launch.
- A local agent is a separate security boundary and is not part of the first release.
