# Design System

## Design intent

TraceLayer should look like a focused engineering application: dense enough for daily use, calm under failure, and consistent across pages. Avoid a generic AI startup aesthetic.

## Color tokens

| Token | Value | Use |
|---|---|---|
| `bg-canvas` | `#101214` | Main background |
| `bg-panel` | `#171A1D` | Sidebar and cards |
| `bg-raised` | `#202428` | Inputs, selected rows |
| `border-subtle` | `#30363B` | Dividers and outlines |
| `text-primary` | `#E8EAEC` | Primary text |
| `text-secondary` | `#9AA3AA` | Supporting text |
| `accent-amber` | `#D6A35D` | Primary action and selected state |
| `status-success` | `#67B58A` | Success |
| `status-warning` | `#D6A35D` | Warning |
| `status-danger` | `#E47777` | Failure |
| `status-info` | `#7FA8D8` | Informational state |

## Typography

- UI: Inter, system UI, or another highly readable sans-serif.
- HTTP methods, JSON, IDs, timing and code: JetBrains Mono or a system monospace.
- Use a small, consistent type scale. Avoid oversized marketing headlines inside the app.

## Spacing and shape

- Base spacing unit: 4px.
- Common gaps: 8, 12, 16, 20, 24px.
- Inputs: 8px radius.
- Panels: 10–12px radius.
- Buttons: 8px radius.
- Borders should be visible but quiet. Avoid heavy shadows and glass effects.

## Component rules

- Buttons: primary, secondary, quiet, destructive.
- Inputs: visible label, helper/error text, keyboard focus ring.
- Status badges: icon or text plus color; never color alone.
- Tables: compact rows, clear column labels, hover and keyboard focus states.
- Code/JSON viewer: preserve whitespace, allow copy, indicate truncation.
- Tabs: show active underline or surface; maintain URL state where useful.
- Dialogs: focus trap, Escape handling, clear action labels.
- Toasts: only after the operation has succeeded or failed.
- Empty states: explain what is missing and how to create it.

## Motion

Use 120–180ms transitions for hover, selection, and panel changes. Respect `prefers-reduced-motion`. No cursor-following backgrounds, perpetual particles, or animation that competes with debugging.

## Responsive behavior

- Desktop: persistent sidebar and split request/response workspace.
- Tablet: collapsible sidebar and adjustable split panes.
- Mobile: drawer navigation; request and response shown as separate tabs or stacked panels.
- Do not shrink code text to illegible sizes; allow horizontal scrolling in code areas.

## Avoid

- Fake real-time charts.
- Random gradients and glowing borders.
- Repeated decorative KPI cards.
- Fake terminal logs.
- Unnecessary 3D elements.
- Unlabeled icons and nonfunctional controls.
