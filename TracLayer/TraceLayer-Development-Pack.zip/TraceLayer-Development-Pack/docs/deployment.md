# Deployment Guide

## Deployment components
- Frontend static build: Vercel or equivalent.
- FastAPI backend: Render or equivalent container/Python host.
- PostgreSQL: managed database.
- Secrets: hosting provider's secret configuration, never committed files.

## Environment configuration
See `.env.example`. Set production values in the hosting dashboard. Do not use the example values in production.

## Build and release checklist
1. Run frontend lint, type checks, tests, and production build.
2. Run backend tests and security regression tests.
3. Apply database migrations as a controlled release step.
4. Configure allowed origins and secure cookie settings.
5. Confirm outbound network restrictions at infrastructure level.
6. Verify health checks expose no secrets or detailed infrastructure information.
7. Run a smoke test using a controlled public test endpoint.
8. Confirm logs redact tokens and response secrets.
9. Confirm backups and retention policies.
10. Verify rollback steps before release.

## Operational monitoring
Record request counts, latency buckets, error categories, and worker saturation without storing secrets or response bodies in metrics. Use structured logs with request IDs. Document retention and access to logs.

## Not production-ready until
- Authentication and workspace authorization are implemented.
- SSRF controls are tested and enforced by network policy.
- Secret redaction and retention are implemented.
- Database backups and migration rollback strategy are understood.
- Rate limits, response-size limits and execution quotas are active.
