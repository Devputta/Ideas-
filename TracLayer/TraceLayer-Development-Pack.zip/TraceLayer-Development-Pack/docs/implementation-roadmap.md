# Implementation Roadmap

## Phase 0 — Repository foundation
Deliverables: frontend/backend skeleton, formatting/linting, environment validation, CI, initial schema, design tokens.
Exit criteria: local setup works from documented instructions.

## Phase 1 — Request execution
Deliverables: request editor, HTTP execution endpoint, response viewer, safe outbound-request gate.
Exit criteria: real requests run against a controlled permitted endpoint; response metadata is accurate; timeout and blocked-target tests pass.

## Phase 2 — Persistence and history
Deliverables: workspaces, collections, saved requests, execution history, filters.
Exit criteria: data survives reload; access checks and pagination work.

## Phase 3 — Failure Capsules
Deliverables: create, view, annotate, export/import, safe replay.
Exit criteria: capsule schema is versioned; secrets are redacted; import never auto-executes.

## Phase 4 — Diff and assertions
Deliverables: structural JSON diff, text diff, assertion definitions, results.
Exit criteria: deterministic test coverage includes edge cases and truncation.

## Phase 5 — UX hardening
Deliverables: responsive layout, accessibility, keyboard interactions, empty/error states, performance pass.
Exit criteria: core paths work at mobile and desktop sizes.

## Phase 6 — Optional AI and telemetry
Deliverables: provider adapter, sanitized context pipeline, evidence-linked explanations; later OpenTelemetry ingestion.
Exit criteria: AI is opt-in and never fabricates execution state; telemetry integrations are tested against actual sources.

## Phase 7 — Public release
Deliverables: deployment, docs, privacy/terms review, security review, demo environment.
Exit criteria: production checklist passes and all demo data is labeled honestly.
