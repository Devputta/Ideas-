# Testing Strategy

## Backend unit tests
- URL parsing and destination classification.
- Header and body redaction.
- Assertion evaluation.
- JSON diff behavior, including missing vs null.
- Capsule schema and version validation.
- Error-envelope consistency.

## Backend integration tests
- Request execution against a controlled local test server.
- Timeouts, redirects, oversized responses, malformed bodies.
- Database persistence and migrations.
- Workspace membership and role enforcement.
- Capsule export/import and replay validation.

## Frontend tests
- Request method and URL validation.
- Request draft survives a failed execution.
- Loading, empty, error and success states.
- Response tab navigation and copy controls.
- Diff selectors and changed-path rendering.
- Capsule confirmation dialogs and import errors.

## End-to-end critical paths
1. Sign in and create a workspace.
2. Create and save a request.
3. Execute it against an allowed test endpoint.
4. Inspect response and execution history.
5. Create a capsule from an execution.
6. Export and import the capsule.
7. Compare two runs and evaluate assertions.
8. Verify a user cannot access another workspace's data.

## Quality gates
- Lint and type check.
- Backend unit and integration tests.
- Frontend unit tests.
- Production build.
- End-to-end smoke test.
- Dependency and secret scanning.
- Security regression suite for outbound request restrictions.

Do not mark a check as passing unless it was run and its result recorded.
