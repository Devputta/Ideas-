# API Contract (Initial Draft)

Base path: `/api/v1`

All requests and responses use JSON except where explicitly documented. This is a proposed contract; endpoints are not implemented by this documentation pack.

## Error envelope

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "The request could not be validated.",
    "request_id": "server-generated-id",
    "details": []
  }
}
```

Do not include stack traces, secrets, internal hostnames, or credential values in client errors.

## Endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Basic service health; no sensitive details |
| GET | `/workspaces` | List authorized workspaces |
| POST | `/workspaces` | Create workspace |
| GET | `/collections` | List collections in current workspace |
| POST | `/collections` | Create collection |
| GET | `/requests/{id}` | Read saved request |
| POST | `/requests` | Create saved request |
| PATCH | `/requests/{id}` | Update saved request |
| POST | `/executions` | Validate and execute HTTP request |
| GET | `/executions` | Search execution history |
| GET | `/executions/{id}` | Read execution detail |
| POST | `/capsules` | Create capsule |
| GET | `/capsules` | Search capsules |
| GET | `/capsules/{id}` | Read capsule |
| POST | `/capsules/{id}/replay` | Revalidate and replay capsule request |
| POST | `/capsules/import` | Import validated capsule JSON |
| GET | `/capsules/{id}/export` | Export sanitized capsule JSON |
| POST | `/compare` | Compare two authorized execution IDs |
| POST | `/assertions/run` | Run assertions against an execution |

## Execution request example

```json
{
  "method": "GET",
  "url": "https://example.com/health",
  "query_params": [],
  "headers": [],
  "body": null,
  "timeout_ms": 5000
}
```

The backend must validate the URL, resolve the destination, enforce network policy, limit body sizes, and redact sensitive data. The client cannot override server security limits.

## Execution response example

```json
{
  "execution_id": "uuid",
  "outcome": "success",
  "status_code": 200,
  "duration_ms": 124,
  "response_headers": {
    "content-type": "application/json"
  },
  "body": "{"status":"ok"}",
  "body_truncated": false
}
```

Example values are illustrative. A real API must populate them from the actual execution.

## Pagination and filtering

Use bounded page sizes. Validate filter values and sort keys. Never accept arbitrary SQL fragments or raw ORM expressions from clients.

## Idempotency

Consider an idempotency key for capsule creation/import and other retry-sensitive writes. Do not assume HTTP replay itself is idempotent.
