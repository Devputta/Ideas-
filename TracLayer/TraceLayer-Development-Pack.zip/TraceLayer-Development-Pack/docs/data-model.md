# Data Model

## Core entities

### users
- `id` UUID primary key
- `email` unique, normalized
- `display_name`
- `created_at`, `updated_at`

### workspaces
- `id` UUID
- `name`
- `owner_user_id` foreign key
- `created_at`, `updated_at`

### workspace_members
- `workspace_id`, `user_id`
- `role` enum: owner, editor, viewer
- unique constraint on workspace/user

### collections
- `id` UUID
- `workspace_id`
- `name`, `description`
- `created_by`, timestamps

### saved_requests
- `id` UUID
- `collection_id`
- `name`, `method`, `url_template`
- `query_params_json`, `headers_json`, `body_text`
- `auth_reference_id` nullable; never raw secrets
- timestamps

### executions
- `id` UUID
- `workspace_id`, `saved_request_id` nullable
- `method`, sanitized URL
- `status_code` nullable
- `duration_ms`
- `response_headers_json`
- `response_body_text` nullable
- `response_truncated` boolean
- `outcome` enum: success, http_error, network_error, timeout, blocked
- `error_code` nullable
- `executed_by`, `created_at`

### capsules
- `id` UUID
- `workspace_id`
- `title`, `summary`, `notes`
- `execution_id` nullable
- `sanitized_request_json`
- `recorded_response_json` nullable
- `tags_json`
- `created_by`, timestamps

### assertions
- `id` UUID
- `workspace_id`
- `name`, `assertion_type`, `config_json`
- `created_by`, timestamps

### assertion_results
- `id` UUID
- `execution_id`
- `assertion_id` nullable
- `assertion_name_snapshot`
- `passed` boolean
- `expected_json`, `actual_json`
- `message`, `created_at`

### audit_events
- `id` UUID
- `workspace_id`, `actor_user_id`
- `action`, `resource_type`, `resource_id`
- `metadata_json` sanitized
- `created_at`

## Data integrity

- Use UUIDs or another non-guessable public identifier.
- Enforce workspace ownership and membership in the backend.
- Add foreign keys and appropriate indexes.
- Use UTC timestamps in storage and display local time in the client.
- Treat imported JSON and all stored body content as untrusted.
- Apply retention policies to execution bodies and audit records.
- Avoid storing passwords, API tokens, cookies, or authorization values in execution records.
