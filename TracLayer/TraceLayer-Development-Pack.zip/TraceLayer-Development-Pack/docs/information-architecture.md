# Information Architecture

## Primary navigation

1. **Overview** — workspace summary, recent executions, shortcuts.
2. **Request Lab** — create and execute HTTP requests.
3. **Collections** — organize saved request definitions.
4. **History** — browse actual executions.
5. **Failure Capsules** — preserve reproducible debugging cases.
6. **Compare** — compare two saved responses.
7. **Assertions** — reusable checks and run results.
8. **Settings** — profile, workspace, retention, security, appearance.

## Routes

| Route | Purpose |
|---|---|
| `/login` | Sign in |
| `/register` | Create account, if public registration is enabled |
| `/app/overview` | Overview |
| `/app/requests/new` | New request |
| `/app/requests/:requestId` | Request editor |
| `/app/collections` | Collections |
| `/app/history` | Execution history |
| `/app/history/:executionId` | Execution detail |
| `/app/capsules` | Capsule list |
| `/app/capsules/new` | Create capsule |
| `/app/capsules/:capsuleId` | Capsule detail and replay |
| `/app/compare` | Response comparison |
| `/app/assertions` | Assertion library |
| `/app/settings/profile` | Profile settings |
| `/app/settings/workspace` | Workspace settings |
| `/app/settings/security` | Security and retention settings |

## Global interaction rules

- Persistent sidebar on desktop; accessible drawer on small screens.
- Active navigation state is visible and keyboard accessible.
- Avoid navigation that unexpectedly scrolls the current page.
- Destructive actions require confirmation and clear scope.
- Unsaved request changes show a dirty-state indicator.
- All lists have loading, empty, error, and populated states.
- Deep links must work after a browser refresh.
