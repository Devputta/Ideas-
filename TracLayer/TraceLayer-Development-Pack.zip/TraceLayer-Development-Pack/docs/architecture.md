# Architecture

## Overview

TraceLayer uses a React client, a FastAPI service, PostgreSQL persistence, and HTTPX for outbound HTTP requests.

```mermaid
flowchart TD
    U[Developer] --> FE[React + TypeScript UI]
    FE --> API[FastAPI REST API]
    API --> AUTH[Authentication and Authorization]
    API --> SAFE[Outbound Request Safety Gate]
    SAFE --> HTTPX[HTTPX Execution Worker]
    API --> DB[(PostgreSQL)]
    HTTPX --> REC[Execution Recorder]
    REC --> DB
    API --> CAP[Capsule Service]
    CAP --> DB
    API --> DIFF[Response Diff Service]
    API --> ASSERT[Assertion Runner]
```

## Components

### Frontend
- Request editor and response viewer.
- Collections, history, capsule list/detail, diff viewer, assertion editor, settings.
- API client with typed response contracts.
- No secrets embedded in frontend build variables.

### API service
- Validates requests and payload sizes.
- Authorizes each resource access.
- Applies rate limits and execution quotas.
- Coordinates request execution and persists sanitized results.
- Returns consistent error envelopes.

### Execution layer
- Uses explicit connect/read/write/pool timeouts.
- Restricts protocols to HTTP and HTTPS.
- Validates target addresses and every redirect.
- Blocks loopback, private, link-local, multicast, reserved, and cloud metadata destinations unless an explicitly isolated local agent is used.
- Limits response bytes and supported decompression behavior.
- Records elapsed duration using a monotonic clock.

### Persistence
- PostgreSQL stores users, workspaces, collections, requests, executions, capsules, assertions, and audit events.
- Alembic migrations are the source of truth for schema evolution.
- Do not store raw credentials in request history.

## Request lifecycle

1. Client submits a request definition.
2. API validates method, URL, headers, body size, and authorization.
3. Safety gate resolves and validates the destination and checks redirect policy.
4. HTTPX executes with limits.
5. Recorder redacts sensitive fields and persists result metadata.
6. API returns the result to the client.
7. UI renders status, duration, headers, body, and any errors.

## Trust boundaries

- Browser to API: authenticated, validated JSON.
- API to outbound target: untrusted network boundary.
- API to database: service credentials and least privilege.
- AI provider (optional): only explicitly approved, sanitized context.
- Imported capsule: untrusted file requiring schema and size validation.

## Deployment shape

For a small first release, deploy frontend and API separately and use a managed PostgreSQL service. Keep outbound execution behind a dedicated safety module. Add a queue only when measured latency, concurrency, or retry requirements justify it.
