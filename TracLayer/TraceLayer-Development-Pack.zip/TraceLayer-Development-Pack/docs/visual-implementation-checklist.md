# Visual Implementation Checklist

Use this checklist while recreating the supplied page reference PNGs.

## Global shell
- Header height approximately 62px on desktop.
- Sidebar width approximately 228px on desktop.
- Main content left padding approximately 32px.
- Graphite canvas, raised panels, subtle borders, amber action color.
- Use shared tokens from `design/design-system.md`.
- Keep navigation state consistent across all authenticated pages.

## Page image mapping
- Overview: `design/page-references/01-overview.png`
- Request Lab: `design/page-references/02-request-lab.png`
- Collections: `design/page-references/03-collections.png`
- History: `design/page-references/04-history.png`
- Execution Detail: `design/page-references/05-execution-detail.png`
- Failure Capsules: `design/page-references/06-failure-capsules.png`
- Capsule Detail: `design/page-references/07-capsule-detail.png`
- Compare: `design/page-references/08-compare.png`
- Assertions: `design/page-references/09-assertions.png`
- Settings: `design/page-references/10-settings.png`
- Authentication: `design/page-references/11-authentication.png`

## Pixel-level guidance
Treat the reference as a hierarchy guide rather than a requirement to hardcode every coordinate. Use a responsive layout system and shared components. At narrow widths, collapse the sidebar and stack panels. Avoid fixed widths that cause horizontal overflow.

## Acceptance
- Main page hierarchy matches the reference.
- Text remains readable at 100% zoom.
- All navigation and controls work with mouse and keyboard.
- Each page has realistic loading, empty, error, and populated states.
- No placeholder data is presented as a real execution.
