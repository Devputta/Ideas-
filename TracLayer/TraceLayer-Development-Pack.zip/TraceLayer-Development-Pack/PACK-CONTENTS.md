# TraceLayer Development Pack Contents

This archive contains planning documents and visual page references. It does not contain an implemented frontend or backend application.

## Markdown files (24 total, including this inventory)
- `CONTRIBUTING.md`
- `README.md`
- `SECURITY.md`
- `design/README.md`
- `design/page-references/INDEX.md`
- `docs/api-contract.md`
- `docs/architecture.md`
- `docs/data-model.md`
- `docs/decisions.md`
- `docs/deployment.md`
- `docs/design-system.md`
- `docs/engineering-rules.md`
- `docs/implementation-roadmap.md`
- `docs/information-architecture.md`
- `docs/known-limitations.md`
- `docs/page-specifications.md`
- `docs/privacy-notice-draft.md`
- `docs/product-requirements.md`
- `docs/security-model.md`
- `docs/terms-draft.md`
- `docs/testing-strategy.md`
- `docs/threat-model.md`
- `docs/visual-implementation-checklist.md`

## Page reference images
- `design/page-references/01-overview.png`
- `design/page-references/02-request-lab.png`
- `design/page-references/03-collections.png`
- `design/page-references/04-history.png`
- `design/page-references/05-execution-detail.png`
- `design/page-references/06-failure-capsules.png`
- `design/page-references/07-capsule-detail.png`
- `design/page-references/08-compare.png`
- `design/page-references/09-assertions.png`
- `design/page-references/10-settings.png`
- `design/page-references/11-authentication.png`
